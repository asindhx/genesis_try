import argparse
import csv
import json
import math
from pathlib import Path

import genesis as gs
import numpy as np

from config import (
    ACTIVE_TARGET_NAME,
    ENDOSCOPE,
    GUIDE_BLOCK_COLOR,
    GUIDE_BLOCKS,
    PLANE_SIZE,
    START_CLAMPS,
    TARGET_HEIGHT,
    TARGET_POSITION,
    TARGET_SIZE,
    TARGETS,
    USED_GUIDE_BLOCK_NAMES,
    WAYPOINTS,
    active_target,
    experiment_level_label,
)


class EndoscopeSegment:
    def __init__(self, entity, length, material, bend_compliance):
        self.entity = entity
        self.length = length
        self.material = material
        self.bend_compliance = bend_compliance


def make_regular_polygon_obj(path: Path, sides: int, radius: float, height: float) -> None:
    """Create a simple prism mesh for shapes Genesis may not provide directly."""
    vertices: list[tuple[float, float, float]] = []
    for z in (-height / 2.0, height / 2.0):
        for i in range(sides):
            angle = 2.0 * math.pi * i / sides + math.pi / 2.0
            vertices.append((radius * math.cos(angle), radius * math.sin(angle), z))

    bottom_center = len(vertices) + 1
    vertices.append((0.0, 0.0, -height / 2.0))
    top_center = len(vertices) + 1
    vertices.append((0.0, 0.0, height / 2.0))

    faces: list[tuple[int, ...]] = []
    for i in range(sides):
        j = (i + 1) % sides
        faces.append((i + 1, j + 1, sides + j + 1, sides + i + 1))
        faces.append((bottom_center, j + 1, i + 1))
        faces.append((top_center, sides + i + 1, sides + j + 1))

    with path.open("w", encoding="utf-8") as f:
        for v in vertices:
            f.write(f"v {v[0]:.8f} {v[1]:.8f} {v[2]:.8f}\n")
        for face in faces:
            f.write("f " + " ".join(str(idx) for idx in face) + "\n")


def make_slotted_cylinder_obj(
    path: Path,
    outer_radius: float,
    channel_half_width: float,
    height: float,
    samples: int = 48,
) -> None:
    """Create a cylinder with a straight through-channel along the x axis."""
    channel_half_width = min(channel_half_width, outer_radius * 0.75)
    vertices: list[tuple[float, float, float]] = []
    loops: list[list[int]] = []

    for sign in (-1.0, 1.0):
        y = sign * channel_half_width
        x_extent = math.sqrt(max(outer_radius * outer_radius - y * y, 1e-8))
        loop: list[tuple[float, float]] = [(-x_extent, y), (x_extent, y)]
        if sign > 0:
            angles = np.linspace(math.asin(y / outer_radius), math.pi - math.asin(y / outer_radius), samples // 2)
        else:
            angles = np.linspace(math.pi - math.asin(abs(y) / outer_radius), 2.0 * math.pi + math.asin(abs(y) / outer_radius), samples // 2)
        loop.extend((outer_radius * math.cos(float(a)), outer_radius * math.sin(float(a))) for a in angles)
        loop_indices: list[int] = []
        for z in (-height / 2.0, height / 2.0):
            for x, yy in loop:
                vertices.append((x, yy, z))
                loop_indices.append(len(vertices))
        loops.append(loop_indices)

    faces: list[tuple[int, ...]] = []
    for loop in loops:
        n = len(loop) // 2
        bottom = loop[:n]
        top = loop[n:]
        for i in range(n):
            j = (i + 1) % n
            faces.append((bottom[i], bottom[j], top[j], top[i]))
        faces.append(tuple(reversed(bottom)))
        faces.append(tuple(top))

    with path.open("w", encoding="utf-8") as f:
        for v in vertices:
            f.write(f"v {v[0]:.8f} {v[1]:.8f} {v[2]:.8f}\n")
        for face in faces:
            f.write("f " + " ".join(str(idx) for idx in face) + "\n")


def add_box(scene, pos, size, color, fixed=True, collision=True):
    return scene.add_entity(
        morph=gs.morphs.Box(
            pos=pos,
            size=size,
            fixed=fixed,
            collision=collision,
        ),
        surface=gs.surfaces.Default(color=color),
    )


def add_cylinder(scene, pos, radius, height, color, fixed=True, collision=True):
    return scene.add_entity(
        morph=gs.morphs.Cylinder(
            pos=pos,
            radius=radius,
            height=height,
            fixed=fixed,
            collision=collision,
        ),
        surface=gs.surfaces.Default(color=color),
    )


def add_mesh(scene, mesh_path, pos, color, fixed=True, collision=False):
    try:
        morph = gs.morphs.Mesh(
            file=str(mesh_path),
            pos=pos,
            fixed=fixed,
            collision=collision,
        )
    except TypeError:
        morph = gs.morphs.Mesh(
            file=str(mesh_path),
            pos=pos,
            fixed=fixed,
        )
    return scene.add_entity(
        morph=morph,
        surface=gs.surfaces.Default(color=color),
    )


def quat_mul_wxyz(q1, q2):
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2
    return (
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    )


def horizontal_cylinder_quat(heading):
    half_y = math.pi / 4.0
    half_z = heading / 2.0
    q_y = (math.cos(half_y), 0.0, math.sin(half_y), 0.0)
    q_z = (math.cos(half_z), 0.0, 0.0, math.sin(half_z))
    return quat_mul_wxyz(q_z, q_y)


def build_scene(show_viewer: bool, output_dir: Path, backend: str):
    backend_map = {
        "cpu": gs.cpu,
        "gpu": gs.gpu,
    }
    gs.init(backend=backend_map[backend])

    scene = gs.Scene(
        sim_options=gs.options.SimOptions(
            dt=0.01,
            substeps=4,
        ),
        viewer_options=gs.options.ViewerOptions(
            camera_pos=(1.9, -2.0, 1.55),
            camera_lookat=(0.0, 0.0, 0.0),
            camera_fov=45,
        ),
        show_viewer=show_viewer,
    )

    add_box(
        scene,
        pos=(0.0, 0.0, -0.018),
        size=(PLANE_SIZE[0], PLANE_SIZE[1], 0.024),
        color=(0.82, 0.84, 0.80, 1.0),
    )

    for block in GUIDE_BLOCKS:
        x, y = block.position
        z = block.height / 2.0
        collision = block.kind == "solid"
        if block.kind == "insertable":
            size_x, size_y = guide_block_size_xy(block)
            add_box(scene, (x, y, z), (size_x, size_y, block.height), block.color, collision=False)
        elif block.shape == "circle":
            add_cylinder(
                scene,
                (x, y, z),
                block.size,
                block.height,
                block.color,
                collision=collision,
            )
        elif block.shape in ("square", "rectangle"):
            size_x, size_y = guide_block_size_xy(block)
            add_box(
                scene,
                (x, y, z),
                (size_x, size_y, block.height),
                block.color,
                collision=collision,
            )
        else:
            raise ValueError(f"Unsupported guide shape: {block.shape}")

    for target in TARGETS:
        target_mesh = output_dir / f"{target.name}_pentagon.obj"
        make_regular_polygon_obj(target_mesh, sides=5, radius=target.size, height=target.height)
        add_mesh(
            scene,
            target_mesh,
            pos=(target.position[0], target.position[1], target.height / 2.0),
            color=target.color,
        )

    endoscope_segments = []
    base_x, base_y, base_z = ENDOSCOPE.base_position
    cursor_x = base_x
    for section in ENDOSCOPE.sections:
        segment_length = section.length / section.segment_count
        for _ in range(section.segment_count):
            segment = add_cylinder(
                scene,
                pos=(cursor_x, base_y, base_z),
                radius=section.radius,
                height=segment_length,
                color=section.color,
                fixed=False,
                collision=True,
            )
            endoscope_segments.append(
                EndoscopeSegment(
                    entity=segment,
                    length=segment_length,
                    material=section.material,
                    bend_compliance=section.bend_compliance,
                )
            )
            cursor_x += segment_length

    scene.build()
    return scene, endoscope_segments


def interpolate_path(waypoints, speed, dt):
    points = [np.array([x, y], dtype=np.float32) for x, y in waypoints]
    current = points[0].copy()
    yield current
    for target in points[1:]:
        delta = target - current
        distance = float(np.linalg.norm(delta))
        if distance < 1e-6:
            continue
        direction = delta / distance
        steps = max(1, int(distance / max(speed * dt, 1e-6)))
        for step in range(1, steps + 1):
            alpha = step / steps
            yield current * (1.0 - alpha) + target * alpha
        current = target.copy()


def update_endoscope_pose(segments, tip_xy, heading):
    current_xy = np.array(tip_xy, dtype=np.float32)
    current_heading = heading
    centerline = [tuple(map(float, tip_xy))]

    for segment in reversed(segments):
        dx = math.cos(current_heading)
        dy = math.sin(current_heading)
        current_xy = current_xy - np.array([dx, dy], dtype=np.float32) * segment.length
        x = float(current_xy[0])
        y = float(current_xy[1])
        z = ENDOSCOPE.base_position[2]
        segment.entity.set_pos((x, y, z))
        segment.entity.set_quat(horizontal_cylinder_quat(current_heading))

        # Rubber sections lag behind heading changes more than metal sections,
        # giving this kinematic prototype a visible bend hierarchy.
        current_heading *= 1.0 - segment.bend_compliance * 0.08
        centerline.append((x, y))

    return centerline


def world_to_pixel(xy, image_size, margin=48):
    width, height = image_size
    plane_w, plane_h = PLANE_SIZE
    x, y = xy
    px = margin + (x + plane_w / 2.0) / plane_w * (width - 2 * margin)
    py = height - (margin + (y + plane_h / 2.0) / plane_h * (height - 2 * margin))
    return int(round(px)), int(round(py))


def world_radius_to_pixels(radius, image_size, margin=48):
    width, height = image_size
    plane_w, plane_h = PLANE_SIZE
    sx = (width - 2 * margin) / plane_w
    sy = (height - 2 * margin) / plane_h
    return max(1, int(round(radius * min(sx, sy))))


def guide_block_size_xy(block):
    if block.shape == "circle":
        diameter = block.size * 2.0
        return diameter, diameter
    return block.size_x or block.size, block.size_y or block.size


def color_to_u8(color):
    return tuple(int(max(0.0, min(1.0, c)) * 255) for c in color[:3])


def polygon_pixels(center_xy, sides, radius, image_size):
    cx, cy = center_xy
    points = []
    for i in range(sides):
        angle = 2.0 * math.pi * i / sides + math.pi / 2.0
        point = (cx + radius * math.cos(angle), cy + radius * math.sin(angle))
        points.append(world_to_pixel(point, image_size))
    return points


def draw_training_frame(image_path, tip_xy, heading, centerline, frame_idx, image_size):
    from PIL import Image, ImageDraw

    width, height = image_size
    image = Image.new("RGB", image_size, (222, 225, 218))
    draw = ImageDraw.Draw(image)

    plane_min = world_to_pixel((-PLANE_SIZE[0] / 2.0, -PLANE_SIZE[1] / 2.0), image_size)
    plane_max = world_to_pixel((PLANE_SIZE[0] / 2.0, PLANE_SIZE[1] / 2.0), image_size)
    draw.rectangle(
        [plane_min[0], plane_max[1], plane_max[0], plane_min[1]],
        fill=(210, 214, 205),
        outline=(120, 126, 116),
        width=2,
    )

    for block in GUIDE_BLOCKS:
        x, y = block.position
        px, py = world_to_pixel(block.position, image_size)
        r = world_radius_to_pixels(block.size, image_size)
        size_x, size_y = guide_block_size_xy(block)
        half_w = world_radius_to_pixels(size_x / 2.0, image_size)
        half_h = world_radius_to_pixels(size_y / 2.0, image_size)
        color = color_to_u8(block.color)
        outline = (22, 24, 28) if block.kind == "solid" else (245, 245, 245)
        if block.kind == "insertable":
            channel_half = world_radius_to_pixels(max(ENDOSCOPE.sections[0].radius * 0.95, size_y * 0.12), image_size)
            draw.rectangle([px - half_w, py - half_h, px + half_w, py + half_h], fill=color, outline=outline, width=3)
            draw.rectangle(
                [px - int(half_w * 0.92), py - channel_half, px + int(half_w * 0.92), py + channel_half],
                outline=(18, 24, 32),
                width=2,
            )
        elif block.shape == "circle":
            draw.ellipse([px - r, py - r, px + r, py + r], fill=color, outline=outline, width=3)
        elif block.shape in ("square", "rectangle"):
            draw.rectangle([px - half_w, py - half_h, px + half_w, py + half_h], fill=color, outline=outline, width=3)
        draw.text((px + max(r, half_w) + 4, py - max(r, half_h)), block.name, fill=(25, 25, 25))

    for clamp in START_CLAMPS:
        px, py = world_to_pixel(clamp.position, image_size)
        half_w = world_radius_to_pixels(clamp.size[0] / 2.0, image_size)
        half_h = world_radius_to_pixels(clamp.size[1] / 2.0, image_size)
        draw.rectangle(
            [px - half_w, py - half_h, px + half_w, py + half_h],
            fill=color_to_u8(clamp.color),
            outline=(20, 20, 20),
            width=2,
        )

    for target in TARGETS:
        target_points = polygon_pixels(target.position, 5, target.size, image_size)
        draw.polygon(target_points, fill=color_to_u8(target.color), outline=(35, 20, 38))

    if len(centerline) >= 2:
        pixels = [world_to_pixel(point, image_size) for point in centerline]
        draw.line(pixels, fill=(10, 13, 16), width=world_radius_to_pixels(ENDOSCOPE.sections[-1].radius * 2.0, image_size))
        draw.line(pixels[:7], fill=(52, 56, 60), width=world_radius_to_pixels(ENDOSCOPE.sections[0].radius * 2.1, image_size))

    tip_px = world_to_pixel(tip_xy, image_size)
    tip_r = world_radius_to_pixels(0.055, image_size)
    draw.ellipse(
        [tip_px[0] - tip_r, tip_px[1] - tip_r, tip_px[0] + tip_r, tip_px[1] + tip_r],
        fill=(236, 238, 240),
        outline=(20, 20, 20),
        width=2,
    )
    draw.text((12, 12), f"frame={frame_idx} level={experiment_level_label()}", fill=(10, 10, 10))
    image.save(image_path)


def build_frame_annotation(frame_idx, tip_xy, heading, centerline, image_size=(1280, 848)):
    current_target = active_target()

    def pixel_point(world_xy):
        x, y = world_to_pixel(world_xy, image_size)
        return [int(x), int(y)]

    def pixel_bbox(center_xy, radius):
        cx, cy = world_to_pixel(center_xy, image_size)
        r = world_radius_to_pixels(radius, image_size)
        return [int(cx - r), int(cy - r), int(cx + r), int(cy + r)]

    def block_pixel_bbox(block):
        if block.shape == "circle":
            return pixel_bbox(block.position, block.size)
        cx, cy = world_to_pixel(block.position, image_size)
        size_x, size_y = guide_block_size_xy(block)
        half_w = world_radius_to_pixels(size_x / 2.0, image_size)
        half_h = world_radius_to_pixels(size_y / 2.0, image_size)
        return [int(cx - half_w), int(cy - half_h), int(cx + half_w), int(cy + half_h)]

    def clamp_pixel_bbox(clamp):
        cx, cy = world_to_pixel(clamp.position, image_size)
        half_w = world_radius_to_pixels(clamp.size[0] / 2.0, image_size)
        half_h = world_radius_to_pixels(clamp.size[1] / 2.0, image_size)
        return [int(cx - half_w), int(cy - half_h), int(cx + half_w), int(cy + half_h)]

    active_targets = []
    inactive_target_blocks = []
    for target in TARGETS:
        item = {
            "id": target.name,
            "shape": target.shape,
            "center_world": list(target.position),
            "center_pixel": pixel_point(target.position),
            "bbox_pixel": pixel_bbox(target.position, target.size),
            "size": target.size,
            "height": target.height,
            "color_rgba": list(target.color),
            "active_for_episode": target.name == ACTIVE_TARGET_NAME,
        }
        if target.name == ACTIVE_TARGET_NAME:
            active_targets.append(item)
        else:
            inactive_target_blocks.append(
                {
                    **item,
                    "kind": "inactive_target_as_block",
                    "used_for_path": False,
                }
            )

    return {
        "frame": frame_idx,
        "level": experiment_level_label(),
        "image_size": [int(image_size[0]), int(image_size[1])],
        "used_guide_blocks": list(USED_GUIDE_BLOCK_NAMES),
        "blocks": [
            {
                "id": block.name,
                "shape": block.shape,
                "kind": block.kind,
                "center_world": list(block.position),
                "center_pixel": pixel_point(block.position),
                "bbox_pixel": block_pixel_bbox(block),
                "size": block.size,
                "size_xy": list(guide_block_size_xy(block)),
                "height": block.height,
                "color_rgba": list(block.color),
                "used_for_path": block.name in USED_GUIDE_BLOCK_NAMES,
            }
            for block in GUIDE_BLOCKS
        ] + inactive_target_blocks,
        "start_clamps": [
            {
                "id": clamp.name,
                "center_world": list(clamp.position),
                "center_pixel": pixel_point(clamp.position),
                "bbox_pixel": clamp_pixel_bbox(clamp),
                "size": list(clamp.size),
                "height": clamp.height,
                "color_rgba": list(clamp.color),
            }
            for clamp in START_CLAMPS
        ],
        "targets": active_targets,
        "target": {
            "id": current_target.name,
            "shape": current_target.shape,
            "center_world": list(current_target.position),
            "center_pixel": pixel_point(current_target.position),
            "bbox_pixel": pixel_bbox(current_target.position, current_target.size),
            "size": current_target.size,
            "active_for_episode": True,
        },
        "endoscope": {
            "tip_world": [float(tip_xy[0]), float(tip_xy[1])],
            "tip_pixel": pixel_point(tip_xy),
            "heading": float(heading),
            "centerline_world": [[float(x), float(y)] for x, y in centerline],
            "centerline_pixel": [pixel_point(point) for point in centerline],
        },
    }


def write_video(frame_paths, video_path, fps):
    try:
        import imageio.v2 as imageio
    except Exception as exc:
        print(f"Video export skipped: imageio is unavailable ({exc})")
        return

    if not frame_paths:
        return
    frames = [imageio.imread(path) for path in frame_paths]
    imageio.mimsave(video_path, frames, fps=fps)


def run(args):
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    level_label = experiment_level_label()
    episode_dir = output_dir / f"episode_{args.episode_index:06d}" if args.record else output_dir
    episode_dir.mkdir(parents=True, exist_ok=True)
    frames_dir = episode_dir / "frames"
    if args.record:
        frames_dir.mkdir(parents=True, exist_ok=True)

    try:
        scene, segments = build_scene(args.viewer, episode_dir, args.backend)
    except RuntimeError as exc:
        message = str(exc)
        if "SM (120)" in message or "sm_120" in message or "fatbin" in message:
            print("")
            print("Genesis GPU kernel is not built for this RTX 50-series card.")
            print("This is an environment/kernel issue, not a scene-code issue.")
            print("")
            print("Run:")
            print("  python scripts/check_genesis_gpu.py")
            print("")
            print("Then rebuild the Genesis condition-kernel fatbin for sm_120")
            print("using the path reported by that script.")
            print("")
        raise

    samples = []
    annotations = []
    frame_paths = []
    path = list(interpolate_path(WAYPOINTS, speed=args.speed, dt=args.dt))
    previous = np.array(WAYPOINTS[0], dtype=np.float32)
    current_target = active_target()
    current_target_xy = np.array(current_target.position, dtype=np.float32)

    for step, tip_xy in enumerate(path[: args.max_steps]):
        delta = tip_xy - previous
        if float(np.linalg.norm(delta)) > 1e-6:
            heading = math.atan2(float(delta[1]), float(delta[0]))
        else:
            heading = 0.0

        centerline = update_endoscope_pose(segments, tip_xy, heading)
        scene.step()

        distance_to_target = float(np.linalg.norm(tip_xy - current_target_xy))
        samples.append(
            {
                "step": step,
                "level": level_label,
                "tip_x": float(tip_xy[0]),
                "tip_y": float(tip_xy[1]),
                "heading": float(heading),
                "distance_to_target": distance_to_target,
                "used_guide_blocks": "|".join(USED_GUIDE_BLOCK_NAMES),
            }
        )

        if args.record and step % args.frame_stride == 0:
            frame_idx = len(frame_paths)
            frame_path = frames_dir / f"{frame_idx:06d}.png"
            draw_training_frame(
                frame_path,
                tip_xy=tip_xy,
                heading=heading,
                centerline=centerline,
                frame_idx=frame_idx,
                image_size=(args.frame_width, args.frame_height),
            )
            frame_paths.append(frame_path)
            annotations.append(
                build_frame_annotation(
                    frame_idx,
                    tip_xy,
                    heading,
                    centerline,
                    image_size=(args.frame_width, args.frame_height),
                )
            )

        previous = tip_xy

        if distance_to_target <= args.success_radius:
            break

    csv_path = episode_dir / "trajectory.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "step",
                "level",
                "tip_x",
                "tip_y",
                "heading",
                "distance_to_target",
                "used_guide_blocks",
            ],
        )
        writer.writeheader()
        writer.writerows(samples)

    if args.record:
        metadata = {
            "episode_index": args.episode_index,
            "level": level_label,
            "used_guide_blocks": list(USED_GUIDE_BLOCK_NAMES),
            "active_target_name": current_target.name,
            "target_position": list(current_target.position),
            "targets": [
                {
                    "name": target.name,
                    "shape": target.shape,
                    "position": list(target.position),
                    "size": target.size,
                    "height": target.height,
                    "active_for_episode": target.name == ACTIVE_TARGET_NAME,
                }
                for target in TARGETS
            ],
            "success": bool(samples and samples[-1]["distance_to_target"] <= args.success_radius),
            "frame_count": len(frame_paths),
            "frame_stride": args.frame_stride,
            "image_size": [args.frame_width, args.frame_height],
        }
        (episode_dir / "metadata.json").write_text(
            json.dumps(metadata, indent=2),
            encoding="utf-8",
        )
        (episode_dir / "annotations.json").write_text(
            json.dumps(annotations, indent=2),
            encoding="utf-8",
        )
        if args.video:
            write_video(frame_paths, episode_dir / "video.mp4", fps=args.video_fps)

    print(f"Experiment level: {level_label}")
    print(f"Used guide blocks: {', '.join(USED_GUIDE_BLOCK_NAMES)}")
    print(f"Finished {len(samples)} simulation steps.")
    print(f"Trajectory saved to: {csv_path}")
    if args.record:
        print(f"Recorded frames: {frames_dir}")
        print(f"Annotations saved to: {episode_dir / 'annotations.json'}")


def parse_args():
    workspace_root = Path(__file__).resolve().parents[2]
    default_output_dir = workspace_root / "outputs" / "endoscope_genesis_sim"
    parser = argparse.ArgumentParser()
    parser.add_argument("--viewer", action="store_true", help="Show Genesis GUI viewer.")
    parser.add_argument(
        "--backend",
        choices=("gpu", "cpu"),
        default="gpu",
        help="Use gpu for normal Genesis simulation, or cpu to bypass CUDA issues.",
    )
    parser.add_argument("--output-dir", default=str(default_output_dir))
    parser.add_argument("--dt", type=float, default=0.01)
    parser.add_argument("--speed", type=float, default=0.22)
    parser.add_argument("--max-steps", type=int, default=5000)
    parser.add_argument("--success-radius", type=float, default=0.08)
    parser.add_argument("--record", action="store_true", help="Write frames and annotations.")
    parser.add_argument("--video", action="store_true", help="Export video.mp4 from recorded frames.")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--frame-stride", type=int, default=10)
    parser.add_argument("--frame-width", type=int, default=1280)
    parser.add_argument("--frame-height", type=int, default=840)
    parser.add_argument("--video-fps", type=int, default=24)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
