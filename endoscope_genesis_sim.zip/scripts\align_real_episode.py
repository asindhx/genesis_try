import argparse
import csv
import json
import math
from pathlib import Path


def read_rows(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def f(value: str, default: float | None = None) -> float | None:
    try:
        out = float(value)
    except (TypeError, ValueError):
        return default
    return out if math.isfinite(out) else default


def image_name(index: int) -> str:
    return f"{index + 1:04d}.jpg"


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as fobj:
        writer = csv.DictWriter(fobj, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def labels_for_frame(vlca: dict, name: str) -> list[dict]:
    return vlca.get("labels", {}).get(name, [])


def tip_for_frame(vlca: dict, name: str) -> dict:
    return vlca.get("tipPoints", {}).get(name, {})


def main() -> int:
    parser = argparse.ArgumentParser(description="Convert real endoscope collection data to the sim episode schema.")
    parser.add_argument("--real-dir", required=True, help="Folder containing data.csv, cam_ebv, cam_ev, and json/vlca.json.")
    parser.add_argument("--output-dir", required=True, help="Output episode folder.")
    args = parser.parse_args()

    real_dir = Path(args.real_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    data_csv = real_dir / "data.csv"
    vlca_path = real_dir / "json" / "vlca.json"
    rows = read_rows(data_csv)
    vlca = json.loads(vlca_path.read_text(encoding="utf-8"))
    ebv_images = sorted((real_dir / "cam_ebv").glob("*.jpg"))
    ev_images = sorted((real_dir / "cam_ev").glob("*.jpg"))

    trajectory_rows: list[dict] = []
    control_rows: list[dict] = []
    annotations: list[dict] = []

    previous_t = None
    previous_m3_pos = None
    for idx, row in enumerate(rows):
        name = image_name(idx)
        t = f(row.get("t_mono", ""), 0.0) or 0.0
        dt = max(t - previous_t, 1e-9) if previous_t is not None else 0.0
        m3_pos = f(row.get("m3_pos", ""), None)
        insertion_delta_raw = 0.0 if previous_m3_pos is None or m3_pos is None else m3_pos - previous_m3_pos
        insertion_velocity_raw = insertion_delta_raw / dt if dt > 0.0 else 0.0
        planning = vlca.get("framePlanningLists", {}).get(name, vlca.get("globalPlanningList", []))
        active_route_target = planning[0] if planning else ""
        motion_target = active_route_target
        tip = tip_for_frame(vlca, name)
        labels = labels_for_frame(vlca, name)
        blocks = [item for item in labels if item.get("displayName") == "block"]
        targets = [item for item in labels if item.get("displayName") == "target"]

        trajectory_rows.append(
            {
                "step": idx,
                "frame_id": row.get("frame_id", ""),
                "time_s": t,
                "ebv_image": f"cam_ebv/{name}",
                "ev_image": f"cam_ev/{name}",
                "active_route_target": active_route_target,
                "motion_target": motion_target,
                "route_plan": "|".join(planning),
                "tip_x_norm": tip.get("x", ""),
                "tip_y_norm": tip.get("y", ""),
                "tip_confidence": tip.get("confidence", ""),
                "block_count": len(blocks),
                "target_count": len(targets),
                "em_valid": row.get("em_valid", ""),
                "em_x": row.get("em_x", ""),
                "em_y": row.get("em_y", ""),
                "em_z": row.get("em_z", ""),
                "em_qw": row.get("em_qw", ""),
                "em_qx": row.get("em_qx", ""),
                "em_qy": row.get("em_qy", ""),
                "em_qz": row.get("em_qz", ""),
            }
        )
        control_rows.append(
            {
                "step": idx,
                "frame_id": row.get("frame_id", ""),
                "time_s": t,
                "active_route_target": active_route_target,
                "motion_target": motion_target,
                "forward_velocity_mps": "",
                "linear_velocity_mps": "",
                "lateral_velocity_mps": "",
                "angular_velocity_radps": "",
                "angular_velocity_degps": "",
                "cumulative_insertion_m": "",
                "joy_ud": row.get("joy_ud", ""),
                "joy_lr": row.get("joy_lr", ""),
                "forward_velocity_cmd": row.get("joy_ud", ""),
                "rotation_velocity_cmd": row.get("joy_lr", ""),
                "m1_spd": row.get("m1_spd", ""),
                "m2_spd": row.get("m2_spd", ""),
                "m3_spd": row.get("m3_spd", ""),
                "m4_spd": row.get("m4_spd", ""),
                "m1_pos": row.get("m1_pos", ""),
                "m2_pos": row.get("m2_pos", ""),
                "m3_pos": row.get("m3_pos", ""),
                "m4_pos": row.get("m4_pos", ""),
                "insertion_delta_raw": insertion_delta_raw,
                "insertion_velocity_raw_per_s": insertion_velocity_raw,
                "pwm_duty": row.get("pwm_duty", ""),
            }
        )
        annotations.append(
            {
                "frame_index": idx,
                "frame_id": row.get("frame_id", ""),
                "image": f"cam_ebv/{name}",
                "tip_view_image": f"cam_ev/{name}",
                "labels": labels,
                "route": {
                    "active_target": active_route_target,
                    "planning_list": planning,
                },
            }
        )
        previous_t = t
        previous_m3_pos = m3_pos

    write_csv(
        output_dir / "trajectory.csv",
        trajectory_rows,
        list(trajectory_rows[0].keys()) if trajectory_rows else [],
    )
    write_csv(
        output_dir / "control_commands.csv",
        control_rows,
        list(control_rows[0].keys()) if control_rows else [],
    )
    (output_dir / "annotations.json").write_text(json.dumps(annotations, indent=2), encoding="utf-8")
    metadata = {
        "mode": "real_endoscope_data_aligned_to_sim_schema",
        "source_dir": str(real_dir),
        "sample_count": len(rows),
        "ebv_frame_count": len(ebv_images),
        "ev_frame_count": len(ev_images),
        "csv_frame_count": len(rows),
        "unpaired_image_count": max(0, min(len(ebv_images), len(ev_images)) - len(rows)),
        "coord_system": vlca.get("coordSystem", "normalised_0_1_topleft"),
        "prompts": vlca.get("prompts", []),
        "global_planning_list": vlca.get("globalPlanningList", []),
        "guiding_config": vlca.get("guidingConfig", {}),
        "real_control_note": (
            "joy_ud/joy_lr and motor speeds are raw real controller signals. "
            "Metric m/s and rad/s fields are left blank unless calibration is provided."
        ),
        "schema_alignment": {
            "cam_ebv": "sim top-down/debug or 3D view",
            "cam_ev": "sim tip/endoscope view",
            "data.csv": "sim trajectory.csv plus control_commands.csv",
            "json/vlca.json": "sim annotations.json and VLCA labels",
        },
    }
    (output_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(f"Aligned real episode saved to: {output_dir}")
    print(f"Rows: {len(rows)}; EBV images: {len(ebv_images)}; EV images: {len(ev_images)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
