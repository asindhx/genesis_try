# Endoscope Genesis run commands

## Clone

```bash
cd /home/wu/Documents/genesis_projectxizi
git clone https://github.com/asindhx/genesis_try.git genesis_try_fresh
cd /home/wu/Documents/genesis_projectxizi/genesis_try_fresh/endoscope_genesis_sim
```

If the zip package is used instead of git clone, unzip it first, then `cd` into the extracted `endoscope_genesis_sim` folder.

## Build Docker image

```bash
docker build -t endoscope-genesis:cuda12.8-sm120 .
```

## Run one FEM-rod physical episode

```bash
mkdir -p "$PWD/outputs" "$PWD/single_gifs" && docker run --rm --gpus all -e PYOPENGL_PLATFORM=egl -e NVIDIA_DRIVER_CAPABILITIES=all -v "$PWD:/workspace/endoscope_genesis_sim" -v "$PWD/outputs:/outputs" endoscope-genesis:cuda12.8-sm120 python physical_main.py --backend gpu --record --video --output-dir /outputs/endoscope_single_checked
```

The default endoscope model is `--physics-model fem`: a planar finite-element rod/beam discretization. It is not a smooth continuum mesh; the endoscope is split into finite rod elements with element length, bending stiffness, clamp, and contact constraints.

## Make top-down GIF

```bash
docker run --rm -v "$PWD:/workspace/endoscope_genesis_sim" -v "$PWD/outputs:/outputs" endoscope-genesis:cuda12.8-sm120 python -c "from pathlib import Path; from PIL import Image; base=Path('/outputs/endoscope_single_checked/episode_000000/render_frames'); frames=sorted(base.glob('*.png')); print('frames',len(frames)); assert frames, 'no frames found in '+str(base); out=Path('/workspace/endoscope_genesis_sim/single_gifs/preview_single_checked.gif'); out.parent.mkdir(parents=True,exist_ok=True); step=max(1,len(frames)//140); imgs=[Image.open(p).convert('RGB').resize((640,424)) for p in frames[::step][:140]]; imgs[0].save(out,save_all=True,append_images=imgs[1:],duration=60,loop=0,optimize=True); print('saved',out)"
```

## Run no-Genesis self-check inside package

```bash
python scripts/selfcheck_no_genesis.py
```

Expected ending:

```text
SELF_CHECK_NO_GENESIS_PASSED
```

Slow full dry-run, including the no-render FEM rod simulation:

```bash
python scripts/selfcheck_no_genesis.py --full-fem
```

## Check quality after a run

```bash
python - <<'PY'
import json
from pathlib import Path
p = Path('outputs/endoscope_single_checked/episode_000000/metadata.json')
m = json.loads(p.read_text())
print('success:', m.get('success'))
print('quality passed:', m.get('quality', {}).get('passed'))
print('quality issues:', m.get('quality', {}).get('issues'))
print('native 3D frames:', m.get('render_3d_native_count'))
print('fallback frames:', m.get('render_fallback_count'))
PY
```
