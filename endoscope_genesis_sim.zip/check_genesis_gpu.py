import pathlib
import shutil
import subprocess
import sys


def run(command: list[str]) -> tuple[int, str]:
    try:
        completed = subprocess.run(
            command,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        return completed.returncode, completed.stdout.strip()
    except FileNotFoundError:
        return 127, f"Command not found: {command[0]}"


def main() -> int:
    print("== Genesis GPU environment check ==")
    print(f"Python: {sys.executable}")

    try:
        import genesis as gs
    except Exception as exc:
        print(f"Genesis import failed: {exc}")
        return 1

    genesis_root = pathlib.Path(gs.__file__).resolve().parent
    print(f"Genesis package: {genesis_root}")
    print(f"Genesis version: {getattr(gs, '__version__', 'unknown')}")

    nvcc = shutil.which("nvcc")
    if nvcc:
        code, out = run([nvcc, "--version"])
        print(f"nvcc: {nvcc}")
        print(out)
    else:
        print("nvcc: not found")
        print("Install CUDA Toolkit 12.8 or newer for RTX 50-series / sm_120 builds.")

    code, out = run(
        [
            sys.executable,
            "-c",
            "import torch; print(torch.__version__); "
            "print(torch.version.cuda); "
            "print(torch.cuda.is_available()); "
            "print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'no cuda'); "
            "print(torch.cuda.get_device_capability(0) if torch.cuda.is_available() else 'no capability')",
        ]
    )
    print("PyTorch CUDA:")
    print(out)

    site_packages = genesis_root.parents[0]
    candidates = list(site_packages.rglob("build_condition_kernel_fatbin.py"))
    if not candidates:
        candidates = list(genesis_root.rglob("build_condition_kernel_fatbin.py"))

    if candidates:
        print("Condition-kernel rebuild script candidates:")
        for path in candidates:
            print(f"  {path}")
        print("")
        print("Run the script from the active Genesis environment, for example:")
        print(f"  {sys.executable} {candidates[0]}")
    else:
        print("Could not find build_condition_kernel_fatbin.py in site-packages.")
        print("Upgrade Genesis/Quadrants to a build that supports sm_120, or install Genesis from source.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
