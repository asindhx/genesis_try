# Docker 运行方式

这个项目建议在 5060 机器上用 Docker 长期运行：

- 宿主机继续使用 Ubuntu 20.04。
- 宿主机只负责 NVIDIA 驱动、Docker 和 NVIDIA Container Toolkit。
- 容器内部使用 Ubuntu 22.04 + CUDA 12.8 + LLVM/Clang + Genesis/Quadrants。

## 1. 宿主机检查

宿主机上先确认 NVIDIA 驱动可用：

```bash
nvidia-smi
```

确认 Docker 可用：

```bash
docker --version
```

确认 Docker 能看到 GPU：

```bash
docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu22.04 nvidia-smi
```

如果这一步失败，先安装 NVIDIA Container Toolkit：

```bash
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey \
  | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg

curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list \
  | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' \
  | sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
```

然后再测试：

```bash
docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu22.04 nvidia-smi
```

## 2. 构建镜像

进入项目目录：

```bash
cd /home/wu/Documents/genesis_projectxizi/genesis_try/endoscope_genesis_sim
```

构建镜像：

```bash
docker build -t endoscope-genesis:cuda12.8-sm120 .
```

这个过程会从源码编译 Quadrants 和 Genesis，第一次会比较久。

默认使用 LLVM 22，因为 Quadrants 当前源码需要较新的 NVVM barrier reduction intrinsics。

如果需要显式指定 LLVM 22：

```bash
docker build --build-arg LLVM_VERSION=22 -t endoscope-genesis:cuda12.8-sm120-llvm22 .
```

## 3. 无窗口运行

```bash
docker run --rm --gpus all \
  -v "$PWD/outputs:/workspace/endoscope_genesis_sim/outputs" \
  endoscope-genesis:cuda12.8-sm120 \
  python main.py --backend gpu
```

生成训练数据：

```bash
docker run --rm --gpus all \
  -e PYOPENGL_PLATFORM=osmesa \
  -e NVIDIA_DRIVER_CAPABILITIES=all \
  -v "$PWD/outputs:/workspace/endoscope_genesis_sim/outputs" \
  endoscope-genesis:cuda12.8-sm120 \
  python main.py --backend gpu --record --video
```

输出会写到宿主机当前目录下的：

```text
outputs/endoscope_genesis_sim/trajectory.csv
```

## 4. GUI 运行

如果需要 `--viewer`，先允许本机 X11：

```bash
xhost +local:docker
```

然后运行：

```bash
docker run --rm --gpus all \
  -e DISPLAY=$DISPLAY \
  -e NVIDIA_DRIVER_CAPABILITIES=compute,utility,graphics \
  -v /tmp/.X11-unix:/tmp/.X11-unix \
  -v "$PWD/outputs:/workspace/endoscope_genesis_sim/outputs" \
  endoscope-genesis:cuda12.8-sm120 \
  python main.py --backend gpu --viewer
```

用完可以收回权限：

```bash
xhost -local:docker
```

## 5. Docker Compose

也可以用：

```bash
docker compose build
docker compose run --rm endoscope-genesis
```

## 6. 说明

如果宿主机 driver 太旧，即使容器里 CUDA 是 12.8，也可能无法运行 5060。宿主机驱动建议使用支持 CUDA 12.8/50 系的版本。
