# Docker 运行方式

## 1. 检查 GPU

```bash
docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu22.04 nvidia-smi
```

能看到 5060/5060 Ti 就继续。

## 2. 构建镜像

进入项目目录：

```bash
cd /home/wu/Documents/genesis_projectxizi/genesis_try_new/endoscope_genesis_sim
```

构建：

```bash
docker build -t endoscope-genesis:cuda12.8-sm120 .
```

第一次会很久，因为会从源码编译 Quadrants。

## 3. 跑物理仿真

推荐先用 `/tmp` 存输出，避免 `/home/wu` 和 `isaac_user` 的权限问题：

```bash
mkdir -p /tmp/endoscope_outputs && docker run --rm --gpus all -e PYOPENGL_PLATFORM=osmesa -e NVIDIA_DRIVER_CAPABILITIES=all -v /tmp/endoscope_outputs:/outputs endoscope-genesis:cuda12.8-sm120 python physical_main.py --backend gpu --record --video --output-dir /outputs/endoscope_genesis_physical
```

结果在：

```bash
ls /tmp/endoscope_outputs/endoscope_genesis_physical/episode_000000
```

主要看：

```text
render_frames/   Genesis 3D 渲染帧
video_3d.mp4     Genesis 3D 渲染视频
debug_frames/    俯视路线调试图
debug_route.mp4  俯视路线调试视频
annotations.json 标注
trajectory.csv   轨迹和路线状态
metadata.json    本集配置和路线目标
```

## 4. 只跑不导出视频

```bash
mkdir -p /tmp/endoscope_outputs && docker run --rm --gpus all -e PYOPENGL_PLATFORM=osmesa -e NVIDIA_DRIVER_CAPABILITIES=all -v /tmp/endoscope_outputs:/outputs endoscope-genesis:cuda12.8-sm120 python physical_main.py --backend gpu --record --output-dir /outputs/endoscope_genesis_physical
```

## 5. 查看接触力

```bash
python3 - <<'PY'
import csv
p = "/tmp/endoscope_outputs/endoscope_genesis_physical/episode_000000/trajectory.csv"
rows = list(csv.DictReader(open(p)))
print("steps:", len(rows))
print("max contact:", max(float(r["contact_force_norm"]) for r in rows))
print("last distance:", rows[-1]["distance_to_target"])
PY
```

`max contact` 明显大于 0 时，说明内窥镜和 solid blocks 或场景发生了物理接触。

## 6. Viewer

AnyDesk 远程时先不要强依赖 viewer。优先用无窗口跑数据，再看 `render_frames/`、`video_3d.mp4`、`trajectory.csv` 和 `metadata.json`。

如果本机真的有图形桌面并且 `echo $DISPLAY` 不是空，可以尝试：

```bash
xhost +local:docker
docker run --rm --gpus all -e DISPLAY=$DISPLAY -e NVIDIA_DRIVER_CAPABILITIES=all -v /tmp/.X11-unix:/tmp/.X11-unix -v /tmp/endoscope_outputs:/outputs endoscope-genesis:cuda12.8-sm120 python physical_main.py --backend gpu --viewer --record --output-dir /outputs/endoscope_genesis_physical
```

## 7. 记住

真实碰撞用：

```bash
python physical_main.py
```

不要再用 `main.py` 判断碰撞质量。
