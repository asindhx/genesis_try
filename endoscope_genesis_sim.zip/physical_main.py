import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import genesis as gs
import numpy as np

from config import (
    ACTIVE_TARGET_NAME,
    ENDOSCOPE,
    GUIDE_BLOCKS,
    PLANE_SIZE,
    START_CLAMPS,
    START_POSITION,
    TARGET_HEIGHT,
    TARGET_POSITION,
    TARGET_SIZE,
    TARGETS,
    USED_GUIDE_BLOCK_NAMES,
    active_target,
    experiment_level_label,
    experiment_level_value,
    used_guide_blocks,
)
from main import (
    add_box,
    add_cylinder,
    add_mesh,
    build_frame_annotation,
    draw_training_frame,
    guide_block_size_xy,
    horizontal_cylinder_quat,
    make_regular_polygon_obj,
    make_slotted_cylinder_obj,
    write_video,
)


@dataclass(frozen=True)
class PhysicalSegmentSpec:
    name: str
    material: str
    role: str
    length: float
    radius: float
    mass: float
    joint_kp: float
    joint_kv: float
    max_bend: float
    color: tuple[float, float, float, float]


@dataclass(frozen=True)
class RouteTarget:
    name: str
    kind: str
    shape: str
    block_position: tuple[float, float]
    target_position: tuple[float, float]
    reach_mode: str


@dataclass(frozen=True)
class MotionSegment:
    kind: str
    points: tuple[tuple[float, float], ...]
    steps: int = 0
    route_target: str = ""


@dataclass
class VisualEndoscopeSegment:
    entity: object
    length: float
    radius: float
    material: str


def expand_endoscope_sections() -> list[PhysicalSegmentSpec]:
    specs: list[PhysicalSegmentSpec] = []
    for section in ENDOSCOPE.sections:
        segment_length = section.length / section.segment_count
        for idx in range(section.segment_count):
            is_metal = section.material == "metal"
            if section.name == "front_rubber_bend":
                role = "active_bend"
            elif section.name in ("lens_metal_tip", "middle_metal_sleeve"):
                role = "rigid_front"
            else:
                role = "passive_body"
            specs.append(
                PhysicalSegmentSpec(
                    name=f"{section.name}_{idx}",
                    material=section.material,
                    role=role,
                    length=segment_length,
                    radius=section.radius,
                    mass=0.035 if is_metal else 0.012,
                    joint_kp=1600.0 if role == "rigid_front" else (420.0 if role == "passive_body" else 160.0),
                    joint_kv=42.0 if role == "rigid_front" else (18.0 if role == "passive_body" else 8.0),
                    max_bend=0.04 if role == "rigid_front" else (0.035 if role == "passive_body" else 0.42),
                    color=section.color,
                )
            )
    return specs


def inertia_cylinder_x_axis(mass: float, radius: float, length: float) -> tuple[float, float, float]:
    i_x = 0.5 * mass * radius * radius
    i_yz = (mass / 12.0) * (3.0 * radius * radius + length * length)
    return i_x, i_yz, i_yz


def write_physical_urdf(path: Path, specs: list[PhysicalSegmentSpec]) -> None:
    lines: list[str] = ['<?xml version="1.0"?>', '<robot name="physical_endoscope">']

    def material(name: str, color: tuple[float, float, float, float]) -> None:
        lines.extend(
            [
                f'  <material name="{name}">',
                f'    <color rgba="{color[0]} {color[1]} {color[2]} {color[3]}"/>',
                "  </material>",
            ]
        )

    material("metal", (0.68, 0.70, 0.72, 1.0))
    material("rubber", (0.02, 0.025, 0.03, 1.0))

    for name in ("world_base", "stage_x", "stage_y", "yaw_link"):
        lines.extend(
            [
                f'  <link name="{name}">',
                '    <inertial><origin xyz="0 0 0" rpy="0 0 0"/><mass value="0.001"/>',
                '      <inertia ixx="1e-6" ixy="0" ixz="0" iyy="1e-6" iyz="0" izz="1e-6"/>',
                "    </inertial>",
                "  </link>",
            ]
        )

    lines.extend(
        [
            '  <joint name="drive_x" type="prismatic">',
            '    <parent link="world_base"/><child link="stage_x"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="1 0 0"/>',
            '    <limit lower="-1.6" upper="1.6" effort="600" velocity="0.35"/>',
            '    <dynamics damping="60" friction="2"/>',
            "  </joint>",
            '  <joint name="drive_y" type="prismatic">',
            '    <parent link="stage_x"/><child link="stage_y"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="0 1 0"/>',
            '    <limit lower="-1.0" upper="1.0" effort="600" velocity="0.35"/>',
            '    <dynamics damping="60" friction="2"/>',
            "  </joint>",
            '  <joint name="drive_yaw" type="revolute">',
            '    <parent link="stage_y"/><child link="yaw_link"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="0 0 1"/>',
            '    <limit lower="-3.14" upper="3.14" effort="500" velocity="1.5"/>',
            '    <dynamics damping="30" friction="1"/>',
            "  </joint>",
        ]
    )

    for i, spec in enumerate(specs):
        ixx, iyy, izz = inertia_cylinder_x_axis(spec.mass, spec.radius, spec.length)
        mat_name = "metal" if spec.material == "metal" else "rubber"
        lines.extend(
            [
                f'  <link name="seg_{i}">',
                f'    <inertial><origin xyz="{spec.length / 2.0} 0 0" rpy="0 0 0"/><mass value="{spec.mass}"/>',
                f'      <inertia ixx="{ixx}" ixy="0" ixz="0" iyy="{iyy}" iyz="0" izz="{izz}"/>',
                "    </inertial>",
                '    <visual>',
                f'      <origin xyz="{spec.length / 2.0} 0 0" rpy="0 1.57079632679 0"/>',
                f'      <geometry><cylinder radius="{spec.radius}" length="{spec.length}"/></geometry>',
                f'      <material name="{mat_name}"/>',
                "    </visual>",
                '    <collision>',
                f'      <origin xyz="{spec.length / 2.0} 0 0" rpy="0 1.57079632679 0"/>',
                f'      <geometry><cylinder radius="{spec.radius}" length="{spec.length}"/></geometry>',
                "    </collision>",
                "  </link>",
            ]
        )

        if i == 0:
            parent = "yaw_link"
            origin = "0 0 0"
            joint_type = "fixed"
            extra = ""
        else:
            parent = f"seg_{i - 1}"
            origin = f"{specs[i - 1].length} 0 0"
            joint_type = "revolute"
            prev = specs[i - 1]
            lower = -prev.max_bend
            upper = prev.max_bend
            extra = (
                '    <axis xyz="0 0 1"/>\n'
                f'    <limit lower="{lower}" upper="{upper}" effort="80" velocity="2.0"/>\n'
                f'    <dynamics damping="{prev.joint_kv}" friction="0.02"/>'
            )

        lines.append(f'  <joint name="joint_{i}" type="{joint_type}">')
        lines.append(f'    <parent link="{parent}"/><child link="seg_{i}"/>')
        lines.append(f'    <origin xyz="{origin}" rpy="0 0 0"/>')
        if extra:
            lines.append(extra)
        lines.append("  </joint>")

    lines.append("</robot>")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def add_static_scene(scene, output_dir: Path):
    add_box(scene, (0.0, 0.0, -0.018), (PLANE_SIZE[0], PLANE_SIZE[1], 0.024), (0.82, 0.84, 0.80, 1.0))

    for clamp in START_CLAMPS:
        add_box(
            scene,
            (clamp.position[0], clamp.position[1], clamp.height / 2.0),
            (clamp.size[0], clamp.size[1], clamp.height),
            clamp.color,
            collision=True,
        )

    block_entities = []
    intended_blocks = list(used_guide_blocks())
    route_lookup = {block.name: idx for idx, block in enumerate(intended_blocks)}
    for block in GUIDE_BLOCKS:
        x, y = block.position
        z = block.height / 2.0
        collision = block.kind == "solid"
        if block.kind == "insertable":
            size_x, size_y = guide_block_size_xy(block)
            channel_h = max(max(section.radius for section in ENDOSCOPE.sections) * 2.7, size_y * 0.42)
            wall_h = max(0.01, (size_y - channel_h) * 0.5)
            ent = None
            for sign in (-1.0, 1.0):
                ent = add_box(
                    scene,
                    (x, y + sign * (channel_h * 0.5 + wall_h * 0.5), z),
                    (size_x, wall_h, block.height),
                    block.color,
                    collision=False,
                )
            if block.name in route_lookup:
                idx = route_lookup[block.name]
                prev_xy = np.array(START_POSITION if idx == 0 else intended_blocks[idx - 1].position, dtype=np.float32)
                next_xy = np.array(
                    active_target().position if idx == len(intended_blocks) - 1 else intended_blocks[idx + 1].position,
                    dtype=np.float32,
                )
                direction = next_xy - prev_xy
                heading = math.atan2(float(direction[1]), float(direction[0]))
                try:
                    ent.set_quat((math.cos(heading / 2.0), 0.0, 0.0, math.sin(heading / 2.0)))
                except Exception:
                    pass
        elif block.shape == "circle":
            ent = add_cylinder(scene, (x, y, z), block.size, block.height, block.color, collision=collision)
        elif block.shape in ("square", "rectangle"):
            size_x, size_y = guide_block_size_xy(block)
            ent = add_box(scene, (x, y, z), (size_x, size_y, block.height), block.color, collision=collision)
        else:
            raise ValueError(f"Unsupported guide shape: {block.shape}")
        block_entities.append((block, ent))

    for target in TARGETS:
        target_mesh = output_dir / f"{target.name}_pentagon.obj"
        make_regular_polygon_obj(target_mesh, sides=5, radius=target.size, height=target.height)
        add_mesh(
            scene,
            target_mesh,
            pos=(target.position[0], target.position[1], target.height / 2.0),
            color=target.color,
        )
    return block_entities


def create_visual_endoscope(scene, specs: list[PhysicalSegmentSpec]) -> list[VisualEndoscopeSegment]:
    visual_segments: list[VisualEndoscopeSegment] = []
    tail_x, tail_y, z = ENDOSCOPE.base_position
    cursor_x = tail_x

    for spec in reversed(specs):
        entity = add_cylinder(
            scene,
            pos=(cursor_x, tail_y, z),
            radius=spec.radius,
            height=spec.length,
            color=spec.color,
            fixed=True,
            collision=False,
        )
        visual_segments.append(
            VisualEndoscopeSegment(
                entity=entity,
                length=spec.length,
                radius=spec.radius,
                material=spec.material,
            )
        )
        cursor_x += spec.length

    return visual_segments


def build_physical_scene(args, output_dir: Path):
    backend_map = {"cpu": gs.cpu, "gpu": gs.gpu}
    gs.init(backend=backend_map[args.backend])

    scene_kwargs = dict(
        sim_options=gs.options.SimOptions(dt=args.dt, substeps=args.substeps),
        viewer_options=gs.options.ViewerOptions(
            camera_pos=(1.9, -2.0, 1.55),
            camera_lookat=(0.0, 0.0, 0.0),
            camera_fov=45,
        ),
        show_viewer=args.viewer,
    )
    if hasattr(gs, "renderers") and hasattr(gs.renderers, "Rasterizer"):
        scene_kwargs["renderer"] = gs.renderers.Rasterizer()
    try:
        scene = gs.Scene(**scene_kwargs)
    except TypeError:
        scene_kwargs.pop("renderer", None)
        scene = gs.Scene(**scene_kwargs)
    add_static_scene(scene, output_dir)

    specs = expand_endoscope_sections()
    visual_segments = create_visual_endoscope(scene, specs)

    camera = None
    tip_camera = None
    if args.record_3d:
        try:
            camera = scene.add_camera(
                res=(args.frame_width, args.frame_height),
                pos=(0.0, 0.0, args.camera_height),
                lookat=(0.0, 0.0, 0.0),
                fov=args.camera_fov,
                GUI=False,
            )
        except Exception as exc:
            print(f"3D camera disabled: {exc}")
    if args.record_tip:
        try:
            tip_camera = scene.add_camera(
                res=(args.frame_width, args.frame_height),
                pos=(START_POSITION[0] - 0.05, START_POSITION[1], args.tip_camera_height),
                lookat=(START_POSITION[0] + 0.35, START_POSITION[1], args.tip_camera_height * 0.75),
                fov=args.tip_camera_fov,
                GUI=False,
            )
        except Exception as exc:
            print(f"Tip camera disabled: {exc}")

    scene.build()

    return scene, visual_segments, specs, camera, tip_camera


def path_target(step, path_points, speed, dt):
    distance_budget = step * speed * dt
    current = np.array(path_points[0], dtype=np.float32)
    for target_tuple in path_points[1:]:
        target = np.array(target_tuple, dtype=np.float32)
        delta = target - current
        dist = float(np.linalg.norm(delta))
        if dist < 1e-6:
            current = target
            continue
        if distance_budget <= dist:
            return current + delta / dist * distance_budget
        distance_budget -= dist
        current = target
    return current


def clamp_to_plane(point: np.ndarray) -> np.ndarray:
    half_x = PLANE_SIZE[0] / 2.0 - 0.10
    half_y = PLANE_SIZE[1] / 2.0 - 0.10
    return np.array(
        [
            float(np.clip(point[0], -half_x, half_x)),
            float(np.clip(point[1], -half_y, half_y)),
        ],
        dtype=np.float32,
    )


def point_on_solid_block_boundary(previous: np.ndarray, block, clearance: float) -> np.ndarray:
    block_xy = np.array(block.position, dtype=np.float32)
    direction = block_xy - previous
    norm = float(np.linalg.norm(direction))
    if norm < 1e-6:
        direction = np.array([1.0, 0.0], dtype=np.float32)
    else:
        direction /= norm
    radius = solid_block_radius(block) + max(section.radius for section in ENDOSCOPE.sections) + clearance
    return clamp_to_plane(block_xy - direction * radius)


def point_on_solid_block_grazing(
    previous: np.ndarray,
    block,
    next_goal: np.ndarray,
    clearance: float,
) -> np.ndarray:
    block_xy = np.array(block.position, dtype=np.float32)
    route_direction = next_goal - previous
    route_norm = float(np.linalg.norm(route_direction))
    if route_norm < 1e-6:
        return point_on_solid_block_boundary(previous, block, clearance)

    route_direction /= route_norm
    normal = np.array([-route_direction[1], route_direction[0]], dtype=np.float32)
    radius = solid_block_radius(block) + max(section.radius for section in ENDOSCOPE.sections) + clearance
    candidates = [
        clamp_to_plane(block_xy + normal * radius),
        clamp_to_plane(block_xy - normal * radius),
    ]

    def candidate_cost(candidate: np.ndarray) -> float:
        incoming = candidate - previous
        outgoing = next_goal - candidate
        length_cost = float(np.linalg.norm(incoming) + np.linalg.norm(outgoing))
        n1 = float(np.linalg.norm(incoming))
        n2 = float(np.linalg.norm(outgoing))
        if n1 < 1e-6 or n2 < 1e-6:
            return length_cost
        turn_cos = float(np.clip(np.dot(incoming, outgoing) / (n1 * n2), -1.0, 1.0))
        turn_cost = math.acos(turn_cos) * 0.25
        return length_cost + turn_cost

    return min(candidates, key=candidate_cost)


def make_guided_route(clearance: float = 0.025) -> tuple[list[tuple[float, float]], list[RouteTarget]]:
    points: list[tuple[float, float]] = [START_POSITION]
    targets: list[RouteTarget] = []
    blocks = list(used_guide_blocks())
    previous = np.array(START_POSITION, dtype=np.float32)

    for idx, block in enumerate(blocks):
        block_xy = np.array(block.position, dtype=np.float32)
        next_goal = np.array(
            active_target().position if idx == len(blocks) - 1 else blocks[idx + 1].position,
            dtype=np.float32,
        )

        if block.kind == "insertable":
            target_xy = block_xy
            reach_mode = "through_center"
            points.append((float(target_xy[0]), float(target_xy[1])))
            previous = block_xy
        else:
            target_xy = point_on_solid_block_grazing(previous, block, next_goal, clearance)
            reach_mode = "graze_boundary"
            points.append((float(target_xy[0]), float(target_xy[1])))
            previous = target_xy

        targets.append(
            RouteTarget(
                name=block.name,
                kind=block.kind,
                shape=block.shape,
                block_position=block.position,
                target_position=(float(target_xy[0]), float(target_xy[1])),
                reach_mode=reach_mode,
            )
        )

    current_target = active_target()
    points.append(current_target.position)
    targets.append(
        RouteTarget(
            name=current_target.name,
            kind="target",
            shape=current_target.shape,
            block_position=current_target.position,
            target_position=current_target.position,
            reach_mode="reach_target",
        )
    )
    return points, targets


def angle_normalize(angle: float) -> float:
    while angle <= -math.pi:
        angle += 2.0 * math.pi
    while angle > math.pi:
        angle -= 2.0 * math.pi
    return angle


def make_solid_turn_arc(
    block,
    current: np.ndarray,
    next_goal: np.ndarray,
    clearance: float,
    side: str,
    samples: int,
    min_turn_radius: float,
) -> list[tuple[float, float]]:
    center = np.array(block.position, dtype=np.float32)
    obstacle_radius = solid_block_radius(block) + max(section.radius for section in ENDOSCOPE.sections) + clearance
    route_direction = center - current
    route_norm = float(np.linalg.norm(route_direction))
    if route_norm < 1e-6:
        route_direction = np.array([1.0, 0.0], dtype=np.float32)
    else:
        route_direction /= route_norm
    side_sign = 1.0 if side == "left" else -1.0
    normal = np.array([-route_direction[1], route_direction[0]], dtype=np.float32) * side_sign

    exit_direction = next_goal - center
    exit_norm = float(np.linalg.norm(exit_direction))
    if exit_norm < 1e-6:
        exit_direction = route_direction
    else:
        exit_direction /= exit_norm

    approach_distance = max(obstacle_radius * 1.45, min_turn_radius * 0.35)
    entry_point = center - route_direction * obstacle_radius
    side_point = center + normal * obstacle_radius
    exit_point = center + exit_direction * obstacle_radius
    control_1 = current + route_direction * min(approach_distance, max(0.05, float(np.linalg.norm(entry_point - current)) * 0.65))
    control_2 = side_point - route_direction * min_turn_radius * 0.22

    points: list[tuple[float, float]] = []
    for i in range(1, max(3, samples // 2) + 1):
        t = i / max(3, samples // 2)
        point = (
            (1.0 - t) ** 3 * current
            + 3.0 * (1.0 - t) ** 2 * t * control_1
            + 3.0 * (1.0 - t) * t**2 * control_2
            + t**3 * side_point
        )
        point = clamp_to_plane(point.astype(np.float32))
        if not points or np.linalg.norm(np.array(points[-1], dtype=np.float32) - point) > 1e-5:
            points.append((float(point[0]), float(point[1])))

    start_angle = math.atan2(float(side_point[1] - center[1]), float(side_point[0] - center[0]))
    end_angle = math.atan2(float(exit_point[1] - center[1]), float(exit_point[0] - center[0]))
    delta = angle_normalize(end_angle - start_angle)
    if side == "left" and delta < 0:
        delta += 2.0 * math.pi
    elif side == "right" and delta > 0:
        delta -= 2.0 * math.pi

    for i in range(1, max(3, samples // 2) + 1):
        t = i / max(3, samples // 2)
        angle = start_angle + delta * t
        point = center + np.array([math.cos(angle), math.sin(angle)], dtype=np.float32) * obstacle_radius
        point = clamp_to_plane(point)
        if not points or np.linalg.norm(np.array(points[-1], dtype=np.float32) - point) > 1e-5:
            points.append((float(point[0]), float(point[1])))
    return points


def controlled_front_length() -> float:
    # The operator actively steers the front assembly: metal tip, front bending
    # section, and the second metal sleeve. Rear rubber tube is passive.
    return sum(section.length for section in ENDOSCOPE.sections[:3])


def minimum_turn_radius(max_steer_angle_deg: float) -> float:
    angle = math.radians(max(5.0, max_steer_angle_deg))
    return controlled_front_length() / angle


def make_motion_plan(
    clearance: float,
    turn_side: str,
    turn_samples: int,
    steer_pause_steps: int,
    max_steer_angle_deg: float,
) -> tuple[list[MotionSegment], list[RouteTarget]]:
    route_points, route_targets = make_guided_route(clearance)
    blocks = list(used_guide_blocks())
    segments: list[MotionSegment] = []
    current = np.array(route_points[0], dtype=np.float32)
    min_radius = minimum_turn_radius(max_steer_angle_deg)

    for idx, block in enumerate(blocks):
        target = route_targets[idx]
        target_xy = np.array(target.target_position, dtype=np.float32)
        if block.kind == "solid":
            next_goal_tuple = route_targets[idx + 1].target_position if idx + 1 < len(blocks) else TARGET_POSITION
            next_goal = np.array(next_goal_tuple, dtype=np.float32)
            arc = make_solid_turn_arc(block, current, next_goal, clearance, turn_side, turn_samples, min_radius)
            if arc:
                pause_point = arc[0]
                segments.append(
                    MotionSegment(
                        "move",
                        ((float(current[0]), float(current[1])), pause_point),
                        route_target=target.name,
                    )
                )
                segments.append(MotionSegment("pause", (pause_point,), steps=steer_pause_steps, route_target=target.name))
                if len(arc) > 1:
                    segments.append(MotionSegment("move", tuple([pause_point, *arc[1:]]), route_target=target.name))
                current = np.array(arc[-1], dtype=np.float32)
            else:
                current = target_xy
        else:
            segments.append(MotionSegment("move", ((float(current[0]), float(current[1])), target.target_position), route_target=target.name))
            current = target_xy

    segments.append(MotionSegment("move", ((float(current[0]), float(current[1])), TARGET_POSITION), route_target="target"))
    return segments, route_targets


def motion_position_at(step: int, motion_segments: list[MotionSegment], speed: float, dt: float) -> tuple[np.ndarray, str]:
    distance_budget = step * speed * dt
    elapsed_pause_steps = 0
    current = np.array(START_POSITION, dtype=np.float32)
    current_target = motion_segments[0].route_target if motion_segments else "target"

    for segment in motion_segments:
        current_target = segment.route_target or current_target
        if segment.kind == "pause":
            pause_distance = segment.steps * speed * dt
            if distance_budget <= pause_distance:
                return np.array(segment.points[0], dtype=np.float32), current_target
            distance_budget -= pause_distance
            elapsed_pause_steps += segment.steps
            current = np.array(segment.points[-1], dtype=np.float32)
            continue

        points = [np.array(point, dtype=np.float32) for point in segment.points]
        current = points[0]
        for target in points[1:]:
            delta = target - current
            dist = float(np.linalg.norm(delta))
            if dist < 1e-6:
                current = target
                continue
            if distance_budget <= dist:
                return current + delta / dist * distance_budget, current_target
            distance_budget -= dist
            current = target

    return current, "target"


def make_forward_route_nodes(clearance: float) -> tuple[list[tuple[float, float]], list[RouteTarget]]:
    nodes, route_targets = make_guided_route(clearance)
    return nodes, route_targets


def rounded_forward_path(
    nodes: list[tuple[float, float]],
    route_targets: list[RouteTarget],
    corner_cut: float,
    samples_per_corner: int,
) -> list[tuple[float, float]]:
    if len(nodes) <= 2:
        return nodes

    path: list[tuple[float, float]] = [nodes[0]]
    target_by_node = {idx + 1: target for idx, target in enumerate(route_targets[:-1])}

    for i in range(1, len(nodes) - 1):
        prev_point = np.array(nodes[i - 1], dtype=np.float32)
        point = np.array(nodes[i], dtype=np.float32)
        next_point = np.array(nodes[i + 1], dtype=np.float32)
        target = target_by_node.get(i)

        incoming = point - prev_point
        outgoing = next_point - point
        in_len = float(np.linalg.norm(incoming))
        out_len = float(np.linalg.norm(outgoing))
        if in_len < 1e-6 or out_len < 1e-6:
            path.append((float(point[0]), float(point[1])))
            continue

        turn_cos = float(np.clip(np.dot(incoming, outgoing) / (in_len * out_len), -1.0, 1.0))
        turn_angle = math.degrees(math.acos(turn_cos))

        if target or turn_angle < 28.0:
            path.append((float(point[0]), float(point[1])))
            continue

        cut = min(corner_cut, in_len * 0.38, out_len * 0.38)
        entry = point - incoming / in_len * cut
        exit_point = point + outgoing / out_len * cut
        if float(np.linalg.norm(np.array(path[-1], dtype=np.float32) - entry)) > 1e-6:
            path.append((float(entry[0]), float(entry[1])))

        count = max(3, samples_per_corner)
        for sample_idx in range(1, count + 1):
            t = sample_idx / count
            curve = (1.0 - t) ** 2 * entry + 2.0 * (1.0 - t) * t * point + t**2 * exit_point
            curve = clamp_to_plane(curve.astype(np.float32))
            if float(np.linalg.norm(np.array(path[-1], dtype=np.float32) - curve)) > 1e-6:
                path.append((float(curve[0]), float(curve[1])))

    if float(np.linalg.norm(np.array(path[-1], dtype=np.float32) - np.array(nodes[-1], dtype=np.float32))) > 1e-6:
        path.append(nodes[-1])
    return path


def clamp_centerline_y() -> float:
    if not START_CLAMPS:
        return float(START_POSITION[1])
    return float(sum(clamp.position[1] for clamp in START_CLAMPS) / len(START_CLAMPS))


def clamp_gap_half_width() -> float:
    if len(START_CLAMPS) < 2:
        return 0.08
    ys = sorted(clamp.position[1] for clamp in START_CLAMPS)
    upper = START_CLAMPS[0]
    lower = START_CLAMPS[1]
    gap = abs(ys[-1] - ys[0]) - (upper.size[1] + lower.size[1]) * 0.5
    return max(0.02, gap * 0.5)


def clamped_tail_anchor() -> np.ndarray:
    if not START_CLAMPS:
        return np.array([START_POSITION[0] - 0.18, START_POSITION[1]], dtype=np.float32)
    x = float(sum(clamp.position[0] for clamp in START_CLAMPS) / len(START_CLAMPS))
    return np.array([x, clamp_centerline_y()], dtype=np.float32)


def sample_polyline_points(points: list[tuple[float, float]], spacing: float = 0.025) -> list[np.ndarray]:
    samples: list[np.ndarray] = []
    for a_tuple, b_tuple in zip(points[:-1], points[1:]):
        a = np.array(a_tuple, dtype=np.float32)
        b = np.array(b_tuple, dtype=np.float32)
        length = float(np.linalg.norm(b - a))
        count = max(1, int(math.ceil(length / spacing)))
        for idx in range(count):
            t = idx / count
            samples.append((a * (1.0 - t) + b * t).astype(np.float32))
    if points:
        samples.append(np.array(points[-1], dtype=np.float32))
    return samples


def preflight_planned_path(
    path_points: list[tuple[float, float]],
    route_targets: list[RouteTarget],
    endoscope_radius: float,
) -> dict:
    issues: list[str] = []
    warnings: list[str] = []
    target_xy = np.array(active_target().position, dtype=np.float32)
    tail_anchor_xy = clamped_tail_anchor()

    if not path_points:
        issues.append("path_empty")
    else:
        start = np.array(path_points[0], dtype=np.float32)
        if float(np.linalg.norm(start - np.array(START_POSITION, dtype=np.float32))) > 1e-5:
            issues.append("path_does_not_start_at_start_position")
        if abs(float(start[1]) - clamp_centerline_y()) > clamp_gap_half_width():
            issues.append("start_position_outside_clamp_gap")
        if len(path_points) > 1 and path_points[1][0] < path_points[0][0] - 1e-5:
            issues.append("initial_motion_goes_backward")

    if abs(float(tail_anchor_xy[1]) - clamp_centerline_y()) > clamp_gap_half_width():
        issues.append("tail_anchor_outside_clamp_gap")

    if path_points and float(np.linalg.norm(np.array(path_points[-1], dtype=np.float32) - target_xy)) > 1e-5:
        issues.append("path_does_not_end_at_target")

    max_turn_deg = 0.0
    for a_tuple, b_tuple, c_tuple in zip(path_points[:-2], path_points[1:-1], path_points[2:]):
        a = np.array(a_tuple, dtype=np.float32)
        b = np.array(b_tuple, dtype=np.float32)
        c = np.array(c_tuple, dtype=np.float32)
        v1 = b - a
        v2 = c - b
        n1 = float(np.linalg.norm(v1))
        n2 = float(np.linalg.norm(v2))
        if n1 < 1e-6 or n2 < 1e-6:
            continue
        cos_angle = float(np.clip(np.dot(v1, v2) / (n1 * n2), -1.0, 1.0))
        angle = math.degrees(math.acos(cos_angle))
        max_turn_deg = max(max_turn_deg, angle)
        if angle > 150.0:
            issues.append(f"sharp_or_reversing_turn_at_{float(b[0]):.3f}_{float(b[1]):.3f}_{angle:.1f}deg")

    samples = sample_polyline_points(path_points)
    for block in GUIDE_BLOCKS:
        if block.kind != "solid":
            continue
        min_allowed = solid_block_radius(block) + endoscope_radius * 0.8
        min_dist = min(float(np.linalg.norm(sample - np.array(block.position, dtype=np.float32))) for sample in samples)
        if min_dist < min_allowed:
            warnings.append(f"solid_clearance_low:{block.name}:{min_dist:.3f}")

    target_names = [target.name for target in route_targets]
    for block_name in USED_GUIDE_BLOCK_NAMES:
        if block_name not in target_names:
            issues.append(f"used_block_missing_from_route:{block_name}")

    return {
        "ok": not issues,
        "issues": issues,
        "warnings": warnings,
        "max_turn_deg": max_turn_deg,
        "path_length": polyline_length(path_points),
        "clamp_centerline_y": clamp_centerline_y(),
        "clamp_gap_half_width": clamp_gap_half_width(),
        "tail_anchor": [float(tail_anchor_xy[0]), float(tail_anchor_xy[1])],
        "tail_anchor_inside_clamp_gap": abs(float(tail_anchor_xy[1]) - clamp_centerline_y()) <= clamp_gap_half_width(),
    }


def build_validated_path(
    route_nodes: list[tuple[float, float]],
    route_targets: list[RouteTarget],
    endoscope_radius: float,
    corner_cut: float,
    samples_per_corner: int,
) -> tuple[list[tuple[float, float]], dict]:
    attempts: list[dict] = []
    candidates: list[tuple[list[tuple[float, float]], dict]] = []
    for scale in (1.0, 0.75, 0.55, 0.35):
        candidate = rounded_forward_path(
            route_nodes,
            route_targets,
            corner_cut=corner_cut * scale,
            samples_per_corner=samples_per_corner,
        )
        report = preflight_planned_path(candidate, route_targets, endoscope_radius)
        report["corner_cut"] = corner_cut * scale
        report["candidate_index"] = len(candidates)
        attempts.append(dict(report))
        candidates.append((candidate, dict(report)))

    valid_candidates = [(candidate, report) for candidate, report in candidates if report["ok"]]
    if valid_candidates:
        selected_candidate, selected_report = min(valid_candidates, key=lambda item: item[1]["path_length"])
    else:
        selected_candidate, selected_report = min(
            candidates,
            key=lambda item: (len(item[1]["issues"]), item[1]["path_length"]),
        )
    final_report = dict(selected_report)
    final_report["attempts"] = [dict(attempt) for attempt in attempts]
    final_report["selection_rule"] = "shortest_valid_candidate"
    return selected_candidate, final_report


def polyline_length(points: list[tuple[float, float]]) -> float:
    total = 0.0
    for a, b in zip(points[:-1], points[1:]):
        total += float(np.linalg.norm(np.array(b, dtype=np.float32) - np.array(a, dtype=np.float32)))
    return total


def polyline_position_at_distance(
    points: list[tuple[float, float]],
    distance: float,
    route_targets: list[RouteTarget],
) -> tuple[np.ndarray, str]:
    if not points:
        return np.array(START_POSITION, dtype=np.float32), ""
    current = np.array(points[0], dtype=np.float32)
    remaining = float(distance)

    active_target = route_targets[0].name if route_targets else "target"
    for point_idx, target_tuple in enumerate(points[1:], start=1):
        target_point = np.array(target_tuple, dtype=np.float32)
        segment = target_point - current
        segment_len = float(np.linalg.norm(segment))
        if segment_len < 1e-6:
            current = target_point
            continue
        if remaining <= segment_len:
            pos = current + segment / segment_len * remaining
            for route_target in route_targets:
                target_xy = np.array(
                    route_target.block_position if route_target.kind != "target" else route_target.target_position,
                    dtype=np.float32,
                )
                threshold = 0.12 if route_target.kind != "target" else 0.08
                if float(np.linalg.norm(pos - target_xy)) > threshold:
                    active_target = route_target.name
                    break
            return pos.astype(np.float32), active_target
        remaining -= segment_len
        current = target_point

    return np.array(points[-1], dtype=np.float32), route_targets[-1].name if route_targets else ACTIVE_TARGET_NAME


def tensor_to_numpy(value):
    if hasattr(value, "detach"):
        return value.detach().cpu().numpy()
    return np.asarray(value)


def solid_block_radius(block) -> float:
    if block.shape == "circle":
        return block.size
    size_x, size_y = guide_block_size_xy(block)
    return math.sqrt(size_x * size_x + size_y * size_y) * 0.5


def resolve_solid_block_overlap(point: np.ndarray, endoscope_radius: float) -> tuple[np.ndarray, float]:
    corrected = point.astype(np.float32).copy()
    contact = 0.0
    for block in GUIDE_BLOCKS:
        if block.kind != "solid":
            continue
        center = np.array(block.position, dtype=np.float32)
        delta = corrected - center
        dist = float(np.linalg.norm(delta))
        min_dist = solid_block_radius(block) + endoscope_radius
        if dist >= min_dist:
            continue
        if dist < 1e-6:
            delta = np.array([1.0, 0.0], dtype=np.float32)
            dist = 1.0
        penetration = min_dist - dist
        corrected = corrected + delta / dist * penetration
        contact += penetration * 12000.0
    return corrected, contact


def append_path_history(history: list[np.ndarray], point: np.ndarray, min_spacing: float) -> None:
    if not history:
        history.append(point.astype(np.float32).copy())
        return
    if float(np.linalg.norm(point - history[-1])) >= min_spacing:
        history.append(point.astype(np.float32).copy())


def initial_infinite_tail_history(tail_length: float) -> list[np.ndarray]:
    start = np.array(START_POSITION, dtype=np.float32)
    anchor = clamped_tail_anchor()
    y = float(anchor[1])
    left_x = float(anchor[0] - max(0.5, tail_length))
    mid_x = float(anchor[0] - 0.35)
    return [
        np.array([left_x, y], dtype=np.float32),
        np.array([mid_x, y], dtype=np.float32),
        anchor.astype(np.float32).copy(),
        start,
    ]


def path_polyline_to_tip(history: list[np.ndarray], tip_xy: np.ndarray) -> list[np.ndarray]:
    points: list[np.ndarray] = []
    for point in history:
        if not points or float(np.linalg.norm(point - points[-1])) >= 1e-6:
            points.append(point.astype(np.float32).copy())
    if not points or float(np.linalg.norm(tip_xy - points[-1])) >= 1e-6:
        points.append(tip_xy.astype(np.float32).copy())
    return points


def smooth_polyline(points: list[np.ndarray], passes: int, strength: float) -> list[np.ndarray]:
    if len(points) <= 2 or passes <= 0 or strength <= 0.0:
        return points
    smoothed = [point.copy() for point in points]
    for _ in range(passes):
        updated = [smoothed[0].copy()]
        for prev_point, point, next_point in zip(smoothed[:-2], smoothed[1:-1], smoothed[2:]):
            if point[0] <= START_POSITION[0] + 0.02 and abs(float(point[1]) - clamp_centerline_y()) <= clamp_gap_half_width():
                updated.append(point.copy())
                continue
            averaged = (prev_point + next_point) * 0.5
            updated.append((point * (1.0 - strength) + averaged * strength).astype(np.float32))
        updated.append(smoothed[-1].copy())
        smoothed = updated
    return smoothed


def point_back_from_tip(points_tail_to_tip: list[np.ndarray], distance_from_tip: float) -> np.ndarray:
    if not points_tail_to_tip:
        return np.array(START_POSITION, dtype=np.float32)

    remaining = float(distance_from_tip)
    cursor = points_tail_to_tip[-1].copy()
    for idx in range(len(points_tail_to_tip) - 1, 0, -1):
        tip_side = points_tail_to_tip[idx]
        tail_side = points_tail_to_tip[idx - 1]
        delta = tail_side - tip_side
        dist = float(np.linalg.norm(delta))
        if dist < 1e-6:
            continue
        if remaining <= dist:
            return (tip_side + delta / dist * remaining).astype(np.float32)
        remaining -= dist
        cursor = tail_side.copy()

    if len(points_tail_to_tip) >= 2:
        first_direction = points_tail_to_tip[0] - points_tail_to_tip[1]
        norm = float(np.linalg.norm(first_direction))
        if norm > 1e-6:
            return (points_tail_to_tip[0] + first_direction / norm * remaining).astype(np.float32)
    return cursor.astype(np.float32)


def role_at_distance_from_tip(specs: list[PhysicalSegmentSpec], distance_from_tip: float) -> str:
    cursor = 0.0
    for spec in specs:
        cursor += spec.length
        if distance_from_tip <= cursor + 1e-6:
            return spec.role
    return specs[-1].role if specs else "passive_body"


def active_bend_segment_count(specs: list[PhysicalSegmentSpec]) -> int:
    return max(1, sum(1 for spec in specs if spec.role == "active_bend"))


def constrain_centerline_bending(
    raw_tip_to_tail: list[np.ndarray],
    distances_from_tip: list[float],
    specs: list[PhysicalSegmentSpec],
) -> list[np.ndarray]:
    if len(raw_tip_to_tail) <= 2:
        return raw_tip_to_tail

    active_limit = math.radians(90.0)
    passive_joint_limit = math.radians(0.45)
    rigid_joint_limit = math.radians(1.5)
    active_segment_count = active_bend_segment_count(specs)

    tail_to_tip_raw = list(reversed(raw_tip_to_tail))
    tail_distances = list(reversed(distances_from_tip))
    constrained_tail_to_tip = [tail_to_tip_raw[0].copy()]

    previous_heading = None
    active_delta_used = 0.0
    total_length = max(distances_from_tip[-1], 1e-6)

    for idx in range(1, len(tail_to_tip_raw)):
        previous_point = constrained_tail_to_tip[-1]
        raw_delta = tail_to_tip_raw[idx] - tail_to_tip_raw[idx - 1]
        segment_length = float(np.linalg.norm(raw_delta))
        if segment_length < 1e-6:
            constrained_tail_to_tip.append(previous_point.copy())
            continue

        raw_heading = math.atan2(float(raw_delta[1]), float(raw_delta[0]))
        distance_from_tip = float(tail_distances[idx])
        role = role_at_distance_from_tip(specs, distance_from_tip)

        if role == "rigid_front":
            joint_limit = rigid_joint_limit
            remaining_active = 0.0
        elif role == "active_bend":
            active_remaining = max(0.0, active_limit - active_delta_used)
            joint_limit = min(math.radians(28.0), active_remaining / active_segment_count + math.radians(2.0))
            remaining_active = active_remaining
        else:
            joint_limit = passive_joint_limit
            remaining_active = 0.0

        if previous_heading is None:
            heading = raw_heading
        else:
            delta_heading = angle_normalize(raw_heading - previous_heading)
            clipped_delta = float(np.clip(delta_heading, -joint_limit, joint_limit))
            heading = previous_heading + clipped_delta
            if remaining_active > 0.0:
                active_delta_used += abs(clipped_delta)

        next_point = previous_point + np.array(
            [math.cos(heading) * segment_length, math.sin(heading) * segment_length],
            dtype=np.float32,
        )
        constrained_tail_to_tip.append(next_point.astype(np.float32))
        previous_heading = heading

    return list(reversed(constrained_tail_to_tip))


def straighten_passive_body(
    tip_to_tail: list[np.ndarray],
    distances_from_tip: list[float],
    specs: list[PhysicalSegmentSpec],
    straightness: float,
) -> list[np.ndarray]:
    if len(tip_to_tail) <= 2:
        return tip_to_tail

    passive_indices = [
        idx
        for idx, distance in enumerate(distances_from_tip)
        if role_at_distance_from_tip(specs, float(distance)) == "passive_body"
    ]
    if len(passive_indices) < 2:
        return tip_to_tail

    first_passive = passive_indices[0]
    neck = tip_to_tail[first_passive].copy()
    anchor = clamped_tail_anchor()
    tail_distance = max(distances_from_tip[-1] - distances_from_tip[first_passive], 1e-6)

    straightened = [point.copy() for point in tip_to_tail]
    for idx in passive_indices:
        t = float((distances_from_tip[idx] - distances_from_tip[first_passive]) / tail_distance)
        desired = neck * (1.0 - t) + anchor * t
        straightened[idx] = (tip_to_tail[idx] * (1.0 - straightness) + desired * straightness).astype(np.float32)
    return straightened


def centerline_from_history(
    history: list[np.ndarray],
    specs: list[PhysicalSegmentSpec],
    endoscope_radius: float,
    visible_length: float,
) -> tuple[list[tuple[float, float]], float]:
    if not history:
        return [START_POSITION], 0.0

    tip_xy = history[-1]
    polyline = smooth_polyline(path_polyline_to_tip(history, tip_xy), passes=0, strength=0.0)
    distances = [0.0]
    total = 0.0
    for spec in specs:
        total += spec.length
        if total > visible_length:
            break
        distances.append(total)
    center_samples = [point_back_from_tip(polyline, distance) for distance in distances]
    center_samples = constrain_centerline_bending(center_samples, distances, specs)
    center_samples = straighten_passive_body(center_samples, distances, specs, straightness=0.98)
    centerline: list[tuple[float, float]] = []
    contact_total = 0.0

    for sample in center_samples:
        if sample[0] <= START_POSITION[0] + 0.02 and abs(float(sample[1]) - clamp_centerline_y()) <= clamp_gap_half_width():
            centerline.append((float(sample[0]), float(clamp_centerline_y())))
            continue
        _, contact = resolve_solid_block_overlap(sample, endoscope_radius)
        centerline.append((float(sample[0]), float(sample[1])))
        contact_total += contact

    return centerline, contact_total


def update_visual_endoscope_segments(
    visual_segments: list[VisualEndoscopeSegment],
    centerline: list[tuple[float, float]],
    hidden_segment_indices: set[int] | None = None,
) -> None:
    if len(centerline) < 2:
        return
    z = ENDOSCOPE.base_position[2]
    tip_to_tail = [np.array(point, dtype=np.float32) for point in centerline]
    tip_first_entities = list(reversed(visual_segments))
    segment_count = min(len(tip_first_entities), len(tip_to_tail) - 1)
    hidden_segment_indices = hidden_segment_indices or set()

    for idx in range(segment_count):
        segment = tip_first_entities[idx]
        if idx in hidden_segment_indices:
            segment.entity.set_pos((0.0, 0.0, -5.0))
            continue
        tip_side = tip_to_tail[idx]
        tail_side = tip_to_tail[idx + 1]
        a = tail_side
        b = tip_side
        midpoint = (a + b) * 0.5
        delta = b - a
        length = float(np.linalg.norm(delta))
        if length < 1e-6:
            continue
        heading = math.atan2(float(delta[1]), float(delta[0]))
        segment.entity.set_pos((float(midpoint[0]), float(midpoint[1]), z))
        segment.entity.set_quat(horizontal_cylinder_quat(heading))

    for segment in tip_first_entities[segment_count:]:
        segment.entity.set_pos((0.0, 0.0, -5.0))


def hidden_segments_inside_insertable(centerline: list[tuple[float, float]]) -> set[int]:
    hidden: set[int] = set()
    if len(centerline) < 2:
        return hidden
    tip_to_tail = [np.array(point, dtype=np.float32) for point in centerline]
    for idx, (tip_side, tail_side) in enumerate(zip(tip_to_tail[:-1], tip_to_tail[1:])):
        midpoint = (tip_side + tail_side) * 0.5
        for block in GUIDE_BLOCKS:
            if block.kind != "insertable":
                continue
            center = np.array(block.position, dtype=np.float32)
            if block.shape == "circle":
                inside = float(np.linalg.norm(midpoint - center)) <= solid_block_radius(block)
            else:
                size_x, size_y = guide_block_size_xy(block)
                rel = np.abs(midpoint - center)
                inside = bool(rel[0] <= size_x * 0.5 and rel[1] <= size_y * 0.5)
            if inside:
                hidden.add(idx)
                break
    return hidden


def heading_from_centerline(centerline: list[tuple[float, float]], fallback: float) -> float:
    if len(centerline) < 2:
        return fallback
    tip = np.array(centerline[0], dtype=np.float32)
    neck = np.array(centerline[1], dtype=np.float32)
    delta = tip - neck
    if float(np.linalg.norm(delta)) < 1e-6:
        return fallback
    return math.atan2(float(delta[1]), float(delta[0]))


def route_target_to_dict(target: RouteTarget) -> dict:
    return {
        "name": target.name,
        "kind": target.kind,
        "shape": target.shape,
        "block_position": [float(target.block_position[0]), float(target.block_position[1])],
        "target_position": [float(target.target_position[0]), float(target.target_position[1])],
        "reach_mode": target.reach_mode,
    }


def json_safe(value):
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return json_safe(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    return value


def save_3d_render_frame(camera, image_path: Path) -> bool:
    if camera is None:
        return False
    try:
        rendered = None
        errors = []
        for render_call in (
            lambda: camera.render(rgb=True, force_render=True),
            lambda: camera.render(rgb=True),
            lambda: camera.render(),
        ):
            try:
                rendered = render_call()
                break
            except Exception as exc:
                errors.append(repr(exc))
        if rendered is None:
            raise RuntimeError("; ".join(errors) or "camera.render returned None")

        if isinstance(rendered, dict):
            image = None
            for key in ("rgb", "color", "image"):
                if key in rendered and rendered[key] is not None:
                    image = rendered[key]
                    break
        elif isinstance(rendered, tuple):
            image = rendered[0]
        else:
            image = rendered

        if image is None:
            raise RuntimeError(f"camera.render returned no RGB image, keys={list(rendered.keys()) if isinstance(rendered, dict) else type(rendered)}")

        image = tensor_to_numpy(image)
        if image.ndim == 4:
            image = image[0]
        if image.dtype != np.uint8:
            if float(np.nanmax(image)) <= 1.0:
                image = np.clip(image * 255.0, 0, 255)
            image = image.astype(np.uint8)

        from PIL import Image

        Image.fromarray(image[..., :3]).save(image_path)
        return True
    except Exception as exc:
        print(f"3D render frame skipped: {repr(exc)}")
        return False


def update_tip_camera(camera, tip_xy: np.ndarray, yaw: float, height: float) -> bool:
    if camera is None:
        return False
    forward = np.array([math.cos(yaw), math.sin(yaw)], dtype=np.float32)
    pos_xy = tip_xy - forward * 0.045
    lookat_xy = tip_xy + forward * 0.34
    pos = (float(pos_xy[0]), float(pos_xy[1]), float(height))
    lookat = (float(lookat_xy[0]), float(lookat_xy[1]), float(height * 0.72))

    for call in (
        lambda: camera.set_pose(pos=pos, lookat=lookat),
        lambda: camera.set_pose(pos, lookat),
        lambda: camera.set_pos(pos),
    ):
        try:
            call()
            if hasattr(camera, "set_lookat"):
                camera.set_lookat(lookat)
            return True
        except Exception:
            continue
    return False


def bbox_pixel_to_normalized(bbox: list[int], image_size: list[int]) -> tuple[float, float, float, float]:
    width, height = float(image_size[0]), float(image_size[1])
    x0, y0, x1, y1 = [float(v) for v in bbox]
    return x0 / width, y0 / height, (x1 - x0) / width, (y1 - y0) / height


def point_pixel_to_normalized(point: list[int], image_size: list[int]) -> tuple[float, float]:
    width, height = float(image_size[0]), float(image_size[1])
    return float(point[0]) / width, float(point[1]) / height


def write_jpg_copy(src: Path, dst: Path) -> None:
    from PIL import Image

    dst.parent.mkdir(parents=True, exist_ok=True)
    Image.open(src).convert("RGB").save(dst, quality=92)


def export_vlca_live_episode(
    episode_dir: Path,
    annotations: list[dict],
    samples: list[dict],
    render_frame_paths: list[Path],
    tip_frame_paths: list[Path],
    route_targets: list[RouteTarget],
    level_label: str,
) -> None:
    if not annotations:
        return

    frame_count = min(len(annotations), len(render_frame_paths) if render_frame_paths else len(annotations))
    if tip_frame_paths:
        frame_count = min(frame_count, len(tip_frame_paths))
    if frame_count <= 0:
        return

    ev_dir = episode_dir / "frames" / "ev"
    ebv_dir = episode_dir / "frames" / "ebv"
    json_dir = episode_dir / "json"
    json_dir.mkdir(parents=True, exist_ok=True)

    prompts = [
        {"color": "#335c94", "name": "block"},
        {"color": "#f59e0b", "name": "robot tip"},
        {"name": "target", "color": "#b819d1", "subprompts": []},
    ]
    labels: dict[str, list[dict]] = {}
    tip_points: dict[str, dict] = {}
    frame_planning: dict[str, list[str]] = {}
    aligned_rows: list[dict] = []

    global_plan = [
        target.name if target.kind != "target" else "Target"
        for target in route_targets
    ]
    reference_blocks = []
    first = annotations[0]
    image_size = first.get("image_size", [1280, 848])
    for idx, block in enumerate(first.get("blocks", []), start=1):
        x, y, w, h = bbox_pixel_to_normalized(block["bbox_pixel"], image_size)
        reference_blocks.append(
            {
                "x": round(x, 6),
                "y": round(y, 6),
                "w": round(w, 6),
                "h": round(h, 6),
                "blockId": block["id"],
            }
        )

    for idx in range(frame_count):
        name = f"{idx + 1:04d}.jpg"
        annotation = annotations[idx]
        image_size = annotation.get("image_size", [1280, 848])
        if render_frame_paths:
            write_jpg_copy(render_frame_paths[idx], ev_dir / name)
        else:
            write_jpg_copy(Path(annotation["frame_path"]), ev_dir / name)
        if tip_frame_paths:
            write_jpg_copy(tip_frame_paths[idx], ebv_dir / name)
        elif render_frame_paths:
            write_jpg_copy(render_frame_paths[idx], ebv_dir / name)

        frame_labels: list[dict] = []
        for block in annotation.get("blocks", []):
            x, y, w, h = bbox_pixel_to_normalized(block["bbox_pixel"], image_size)
            frame_labels.append(
                {
                    "auto_labeled": True,
                    "confidence": 1.0,
                    "displayName": "block",
                    "prompt": "block",
                    "promptIndex": 0,
                    "x": round(x, 6),
                    "y": round(y, 6),
                    "w": round(w, 6),
                    "h": round(h, 6),
                    "blockId": block["id"],
                    "kind": block.get("kind"),
                    "used_for_path": block.get("used_for_path", False),
                }
            )

        active_target = annotation.get("target")
        if active_target and active_target.get("bbox_pixel"):
            x, y, w, h = bbox_pixel_to_normalized(active_target["bbox_pixel"], image_size)
            frame_labels.append(
                {
                    "auto_labeled": True,
                    "confidence": 1.0,
                    "displayName": "target",
                    "prompt": "target",
                    "promptIndex": 2,
                    "x": round(x, 6),
                    "y": round(y, 6),
                    "w": round(w, 6),
                    "h": round(h, 6),
                    "targetId": active_target.get("id", "Target"),
                }
            )

        tip_px = annotation.get("endoscope", {}).get("tip_pixel")
        if tip_px:
            tx, ty = point_pixel_to_normalized(tip_px, image_size)
            tip_entry = {
                "auto_labeled": True,
                "confidence": 1.0,
                "displayName": "robot tip",
                "h": 0,
                "isPoint": True,
                "prompt": "robot tip",
                "promptIndex": 1,
                "w": 0,
                "x": round(tx, 6),
                "y": round(ty, 6),
            }
            frame_labels.insert(0, tip_entry)
            tip_points[name] = {"x": round(tx, 6), "y": round(ty, 6), "confidence": 1.0}

        labels[name] = frame_labels
        frame_planning[name] = list(global_plan)

        sample = samples[min(idx, len(samples) - 1)] if samples else {}
        aligned_rows.append(
            {
                "episode_uid": f"{level_label}/episode_000000",
                "global_episode_id": f"{level_label}/episode_000000",
                "level_dir": level_label,
                "level_episode_id": "episode_000000",
                "episode_id": "episode_000000",
                "std_frame_idx": idx + 1,
                "raw_episode_relpath": f"{level_label}/episode_000000",
                "raw_row_idx": idx,
                "raw_frame_id": sample.get("step", idx),
                "raw_image_idx": idx + 1,
                "ev_image": f"frames/ev/{name}",
                "ebv_image": f"frames/ebv/{name}",
                "raw_ev_image": f"frames/ev/{name}",
                "raw_ebv_image": f"frames/ebv/{name}",
                "alignment_policy": "simulation_frame_stride",
                "alignment_quality": "sim_sync",
                "task_level": experiment_level_value(),
                "task_level_name": level_label,
                "insertion_needed": any(target.kind == "insertable" for target in route_targets),
                "frame_id": sample.get("step", idx),
                "t_mono": round(float(sample.get("step", idx)) * 0.01, 4),
                "joy_ud": "",
                "joy_lr": "",
                "m1_spd": "",
                "m2_spd": "",
                "m3_spd": "",
                "m4_spd": "",
                "m1_pos": "",
                "m2_pos": "",
                "m3_pos": "",
                "m4_pos": "",
                "pwm_duty": "",
                "em_valid": 1,
                "em_x": sample.get("tip_x", ""),
                "em_y": sample.get("tip_y", ""),
                "em_z": 0.0,
                "em_qw": "",
                "em_qx": "",
                "em_qy": "",
                "em_qz": "",
                "ebv_block_boxes_json": json.dumps([item for item in frame_labels if item.get("displayName") == "block"]),
                "ebv_tip_box_json": json.dumps(tip_points.get(name)) if name in tip_points else "null",
                "ev_block_boxes_json": json.dumps([item for item in frame_labels if item.get("displayName") == "block"]),
                "guiding_block_id": sample.get("active_route_target", ""),
                "waypoint_x": sample.get("drive_x", ""),
                "waypoint_y": sample.get("drive_y", ""),
            }
        )

    vlca = {
        "version": "1.0",
        "format": "vlca",
        "exportDate": "simulation",
        "coordSystem": "normalized_xywh",
        "prompts": prompts,
        "labels": labels,
        "tipPoints": tip_points,
        "negatives": [],
        "referenceBlocks": reference_blocks,
        "globalPlanningList": global_plan,
        "framePlanningLists": frame_planning,
        "guidingConfig": {"distanceMetric": "edge", "switchThreshold": 0.03},
        "stats": {
            "totalImages": frame_count,
            "labeledImages": frame_count,
            "negativeImages": 0,
            "totalBoxes": sum(len(v) for v in labels.values()),
            "tipPointFrames": len(tip_points),
        },
    }
    (json_dir / "vlca.json").write_text(json.dumps(vlca, indent=2), encoding="utf-8")
    (json_dir / "yolo_auto_gen.json").write_text(json.dumps(vlca, indent=2), encoding="utf-8")

    if aligned_rows:
        aligned_path = episode_dir / "aligned.csv"
        with aligned_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(aligned_rows[0].keys()))
            writer.writeheader()
            writer.writerows(aligned_rows)


def update_reached_targets(
    tip_xy: np.ndarray,
    route_targets: list[RouteTarget],
    reached: dict[str, int],
    step: int,
    radius: float,
) -> None:
    for target in route_targets:
        if target.name in reached:
            continue
        if target.kind == "target":
            target_xy = np.array(target.target_position, dtype=np.float32)
            threshold = radius
        else:
            target_xy = np.array(target.block_position, dtype=np.float32)
            block_radius = 0.0
            for block in GUIDE_BLOCKS:
                if block.name == target.name:
                    block_radius = solid_block_radius(block)
                    break
            threshold = block_radius + radius
        if float(np.linalg.norm(tip_xy - target_xy)) <= threshold:
            reached[target.name] = step


def current_route_target(route_targets: list[RouteTarget], reached: dict[str, int]) -> RouteTarget:
    for target in route_targets:
        if target.name not in reached:
            return target
    return route_targets[-1]


def run(args):
    output_dir = Path(args.output_dir)
    episode_dir = output_dir / f"episode_{args.episode_index:06d}" if args.record else output_dir
    render_frames_dir = episode_dir / "render_frames"
    tip_frames_dir = episode_dir / "tip_frames"
    debug_frames_dir = episode_dir / "debug_frames"
    episode_dir.mkdir(parents=True, exist_ok=True)
    if args.record:
        for directory in (render_frames_dir, tip_frames_dir, debug_frames_dir):
            directory.mkdir(parents=True, exist_ok=True)
            for old_frame in directory.glob("*.png"):
                old_frame.unlink()
        for old_video in ("video_3d.mp4", "video_tip.mp4", "debug_route.mp4"):
            old_video_path = episode_dir / old_video
            if old_video_path.exists():
                old_video_path.unlink()

    scene, visual_segments, specs, camera, tip_camera = build_physical_scene(args, episode_dir)
    level_label = experiment_level_label()
    selected_target = active_target()
    selected_target_xy = np.array(selected_target.position, dtype=np.float32)
    tail_anchor_xy = clamped_tail_anchor()
    route_nodes, route_targets = make_forward_route_nodes(args.solid_clearance)
    endoscope_radius = max(section.radius for section in ENDOSCOPE.sections)
    path_points, route_preflight = build_validated_path(
        route_nodes,
        route_targets,
        endoscope_radius=endoscope_radius,
        corner_cut=args.turn_corner_cut,
        samples_per_corner=args.turn_samples,
    )
    required_steps = int(math.ceil(polyline_length(path_points) / max(args.drive_speed * args.dt, 1e-6))) + 30
    simulation_steps = max(args.max_steps, required_steps)
    reached_targets: dict[str, int] = {}

    samples = []
    annotations = []
    render_frame_paths = []
    tip_frame_paths = []
    debug_frame_paths = []
    previous_drive_xy = np.array(START_POSITION, dtype=np.float32)
    path_history: list[np.ndarray] = initial_infinite_tail_history(args.tail_length)

    for step in range(simulation_steps):
        drive_xy, motion_target_name = polyline_position_at_distance(
            path_points,
            step * args.drive_speed * args.dt,
            route_targets,
        )
        drive_xy, head_contact = resolve_solid_block_overlap(drive_xy, endoscope_radius)
        append_path_history(path_history, drive_xy, args.history_spacing)

        delta = drive_xy - previous_drive_xy
        if float(np.linalg.norm(delta)) > 1e-6:
            yaw = math.atan2(float(delta[1]), float(delta[0]))
        else:
            yaw = 0.0

        centerline, proxy_contact = centerline_from_history(
            path_history,
            specs,
            endoscope_radius,
            args.visible_endoscope_length,
        )
        tip_xy = np.array(centerline[0], dtype=np.float32)
        yaw = heading_from_centerline(centerline, yaw)
        distance_to_target = float(np.linalg.norm(tip_xy - selected_target_xy))
        contact_norm = max(proxy_contact, head_contact)
        hidden_insertable_segments = hidden_segments_inside_insertable(centerline)
        insertable_occluded = bool(hidden_insertable_segments)
        update_visual_endoscope_segments(
            visual_segments,
            centerline,
            hidden_segment_indices=hidden_insertable_segments,
        )
        scene.step()
        update_reached_targets(tip_xy, route_targets, reached_targets, step, args.route_reach_radius)
        active_route_target = current_route_target(route_targets, reached_targets)

        samples.append(
            {
                "step": step,
                "level": level_label,
                "active_route_target": active_route_target.name,
                "motion_target": motion_target_name,
                "reached_route_targets": "|".join(reached_targets.keys()),
                "drive_x": float(drive_xy[0]),
                "drive_y": float(drive_xy[1]),
                "tip_x": float(tip_xy[0]),
                "tip_y": float(tip_xy[1]),
                "tail_anchor_x": float(tail_anchor_xy[0]),
                "tail_anchor_y": float(tail_anchor_xy[1]),
                "tail_anchor_inside_clamp_gap": int(
                    abs(float(tail_anchor_xy[1]) - clamp_centerline_y()) <= clamp_gap_half_width()
                ),
                "yaw": float(yaw),
                "distance_to_target": distance_to_target,
                "contact_force_norm": contact_norm,
                "insertable_occluded": int(insertable_occluded),
                "hidden_insertable_segments": "|".join(str(idx) for idx in sorted(hidden_insertable_segments)),
                "used_guide_blocks": "|".join(USED_GUIDE_BLOCK_NAMES),
            }
        )

        if args.record and step % args.frame_stride == 0:
            frame_idx = len(debug_frame_paths)
            debug_frame_path = debug_frames_dir / f"{frame_idx:06d}.png"
            draw_training_frame(
                debug_frame_path,
                tip_xy=tip_xy,
                heading=yaw,
                centerline=centerline,
                frame_idx=frame_idx,
                image_size=(args.frame_width, args.frame_height),
            )
            debug_frame_paths.append(debug_frame_path)
            render_frame_path = render_frames_dir / f"{frame_idx:06d}.png"
            if save_3d_render_frame(camera, render_frame_path):
                render_frame_paths.append(render_frame_path)
            tip_frame_path = tip_frames_dir / f"{frame_idx:06d}.png"
            if update_tip_camera(tip_camera, tip_xy, yaw, args.tip_camera_height) and save_3d_render_frame(tip_camera, tip_frame_path):
                tip_frame_paths.append(tip_frame_path)
            annotation = build_frame_annotation(
                frame_idx,
                tip_xy,
                yaw,
                centerline,
                image_size=(args.frame_width, args.frame_height),
            )
            annotation["route"] = {
                "targets": [route_target_to_dict(target) for target in route_targets],
                "active_target": route_target_to_dict(active_route_target),
                "reached_target_names": list(reached_targets.keys()),
            }
            annotation["physics"] = {"contact_force_norm": contact_norm}
            annotation["visibility"] = {
                "insertable_occluded": insertable_occluded,
                "hidden_insertable_segments": sorted(hidden_insertable_segments),
            }
            annotation["tail_constraint"] = {
                "model": "long_tail_clamped_at_start",
                "tail_length": args.tail_length,
                "anchor_world": [float(tail_anchor_xy[0]), float(tail_anchor_xy[1])],
                "anchor_inside_clamp_gap": abs(float(tail_anchor_xy[1]) - clamp_centerline_y()) <= clamp_gap_half_width(),
            }
            annotations.append(annotation)

        previous_drive_xy = drive_xy
        if distance_to_target <= args.success_radius:
            break

    csv_path = episode_dir / "trajectory.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "step",
                "level",
                "active_route_target",
                "motion_target",
                "reached_route_targets",
                "drive_x",
                "drive_y",
                "tip_x",
                "tip_y",
                "tail_anchor_x",
                "tail_anchor_y",
                "tail_anchor_inside_clamp_gap",
                "yaw",
                "distance_to_target",
                "contact_force_norm",
                "insertable_occluded",
                "hidden_insertable_segments",
                "used_guide_blocks",
            ],
        )
        writer.writeheader()
        writer.writerows(samples)

    if args.record:
        metadata = {
            "mode": "visible_tip_guided_block_route_endoscope",
            "episode_index": args.episode_index,
            "level": level_label,
            "tail_model": "long_tail_clamped_at_start",
            "tail_length": args.tail_length,
            "visible_endoscope_length": args.visible_endoscope_length,
            "infinite_tail_entry": {
                "constrained_by_start_clamps": True,
                "anchor_world": [float(tail_anchor_xy[0]), float(tail_anchor_xy[1])],
                "entry_y": clamp_centerline_y(),
                "gap_half_width": clamp_gap_half_width(),
            },
            "moving_end": "metal_lens_tip",
            "material_model": {
                "active_control_region": "front_rubber_bend_between_two_metal_sections",
                "active_bend_limit_deg": 90.0,
                "rigid_front_joint_limit_deg": 1.5,
                "passive_body_joint_limit_deg": 0.45,
                "rear_body_behavior": "stiff_passive_bending_only",
            },
            "used_guide_blocks": list(USED_GUIDE_BLOCK_NAMES),
            "start_clamps": [
                {
                    "name": clamp.name,
                    "position": list(clamp.position),
                    "size": list(clamp.size),
                    "height": clamp.height,
                }
                for clamp in START_CLAMPS
            ],
            "active_target_name": selected_target.name,
            "target_position": list(selected_target.position),
            "targets": [
                {
                    "name": target.name,
                    "shape": target.shape,
                    "position": list(target.position),
                    "size": target.size,
                    "height": target.height,
                    "active_for_episode": target.name == ACTIVE_TARGET_NAME,
                }
                for target in TARGETS
            ],
            "route_rule": "start clamp -> graze solid guide blocks / pass through insertable blocks -> active target",
            "route_targets": [route_target_to_dict(target) for target in route_targets],
            "path_points": [[float(x), float(y)] for x, y in path_points],
            "route_preflight": route_preflight,
            "motion": {
                "planner": "monotonic_forward_rounded_route",
                "route_nodes": [[float(x), float(y)] for x, y in route_nodes],
                "turn_samples": args.turn_samples,
                "turn_corner_cut": args.turn_corner_cut,
                "controlled_front_length": controlled_front_length(),
                "max_steer_angle_deg": args.max_steer_angle_deg,
                "minimum_turn_radius": minimum_turn_radius(args.max_steer_angle_deg),
                "required_steps": required_steps,
                "simulation_steps": simulation_steps,
            },
            "reached_route_targets": reached_targets,
            "success": bool(samples and samples[-1]["distance_to_target"] <= args.success_radius),
            "render_3d_available": bool(render_frame_paths),
            "render_frame_count": len(render_frame_paths),
            "tip_frame_count": len(tip_frame_paths),
            "debug_frame_count": len(debug_frame_paths),
            "frame_stride": args.frame_stride,
            "image_size": [args.frame_width, args.frame_height],
            "camera": {
                "view": "top_down_3d",
                "pos": [0.0, 0.0, args.camera_height],
                "lookat": [0.0, 0.0, 0.0],
                "fov": args.camera_fov,
            },
            "tip_camera": {
                "view": "endoscope_tip_forward",
                "height": args.tip_camera_height,
                "fov": args.tip_camera_fov,
                "frame_count": len(tip_frame_paths),
            },
            "endoscope_segments": len(specs),
            "control": {
                "drive_speed": args.drive_speed,
                "steering_gain": args.steering_gain,
                "bend_frequency": args.bend_frequency,
                "bend_lag": args.bend_lag,
                "history_spacing": args.history_spacing,
            },
        }
        (episode_dir / "metadata.json").write_text(json.dumps(json_safe(metadata), indent=2), encoding="utf-8")
        (episode_dir / "annotations.json").write_text(json.dumps(annotations, indent=2), encoding="utf-8")
        if args.export_vlca:
            export_vlca_live_episode(
                episode_dir,
                annotations,
                samples,
                render_frame_paths or debug_frame_paths,
                tip_frame_paths,
                route_targets,
                level_label,
            )
        if args.video:
            if render_frame_paths:
                write_video(render_frame_paths, episode_dir / "video_3d.mp4", fps=args.video_fps)
            if tip_frame_paths:
                write_video(tip_frame_paths, episode_dir / "video_tip.mp4", fps=args.video_fps)
            write_video(debug_frame_paths, episode_dir / "debug_route.mp4", fps=args.video_fps)

    print(f"Physical simulation level: {level_label}")
    print(f"Finished {len(samples)} steps.")
    print(f"Trajectory saved to: {csv_path}")
    if args.record:
        print(f"3D render frames saved to: {render_frames_dir}")
        print(f"Tip camera frames saved to: {tip_frames_dir}")
        print(f"Debug frames saved to: {debug_frames_dir}")
        print(f"Annotations saved to: {episode_dir / 'annotations.json'}")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--viewer", action="store_true")
    parser.add_argument("--backend", choices=("gpu", "cpu"), default="gpu")
    parser.add_argument("--output-dir", default="/outputs/endoscope_genesis_physical")
    parser.add_argument("--dt", type=float, default=0.01)
    parser.add_argument("--substeps", type=int, default=8)
    parser.add_argument("--max-steps", type=int, default=2500)
    parser.add_argument("--success-radius", type=float, default=0.10)
    parser.add_argument("--drive-speed", type=float, default=0.12)
    parser.add_argument("--steering-gain", type=float, default=0.0)
    parser.add_argument("--bend-frequency", type=float, default=4.2)
    parser.add_argument("--bend-lag", type=float, default=0.32)
    parser.add_argument("--endoscope-friction", type=float, default=1.2)
    parser.add_argument("--solid-clearance", type=float, default=0.10)
    parser.add_argument("--history-spacing", type=float, default=0.012)
    parser.add_argument("--visible-endoscope-length", type=float, default=4.5)
    parser.add_argument("--tail-length", type=float, default=5.5)
    parser.add_argument("--route-reach-radius", type=float, default=0.075)
    parser.add_argument("--turn-side", choices=("left", "right"), default="left")
    parser.add_argument("--turn-samples", type=int, default=8)
    parser.add_argument("--turn-corner-cut", type=float, default=0.22)
    parser.add_argument("--steer-pause-steps", type=int, default=55)
    parser.add_argument("--max-steer-angle-deg", type=float, default=18.0)
    parser.add_argument("--record-3d", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--record-tip", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--export-vlca", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--video", action="store_true")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--frame-stride", type=int, default=10)
    parser.add_argument("--frame-width", type=int, default=1280)
    parser.add_argument("--frame-height", type=int, default=848)
    parser.add_argument("--camera-height", type=float, default=3.0)
    parser.add_argument("--camera-fov", type=float, default=46.0)
    parser.add_argument("--tip-camera-height", type=float, default=0.085)
    parser.add_argument("--tip-camera-fov", type=float, default=82.0)
    parser.add_argument("--video-fps", type=int, default=24)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
