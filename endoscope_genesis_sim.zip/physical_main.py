import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import genesis as gs
import numpy as np

from config import (
    ENDOSCOPE,
    GUIDE_BLOCKS,
    PLANE_SIZE,
    START_POSITION,
    TARGET_HEIGHT,
    TARGET_POSITION,
    TARGET_SIZE,
    USED_GUIDE_BLOCK_NAMES,
    experiment_level_label,
    used_guide_blocks,
)
from main import (
    add_box,
    add_cylinder,
    add_mesh,
    build_frame_annotation,
    draw_training_frame,
    make_regular_polygon_obj,
    write_video,
)


@dataclass(frozen=True)
class PhysicalSegmentSpec:
    name: str
    material: str
    length: float
    radius: float
    mass: float
    joint_kp: float
    joint_kv: float
    max_bend: float
    color: tuple[float, float, float, float]


@dataclass(frozen=True)
class RouteTarget:
    name: str
    kind: str
    shape: str
    block_position: tuple[float, float]
    target_position: tuple[float, float]
    reach_mode: str


def expand_endoscope_sections() -> list[PhysicalSegmentSpec]:
    specs: list[PhysicalSegmentSpec] = []
    for section in ENDOSCOPE.sections:
        segment_length = section.length / section.segment_count
        for idx in range(section.segment_count):
            is_metal = section.material == "metal"
            specs.append(
                PhysicalSegmentSpec(
                    name=f"{section.name}_{idx}",
                    material=section.material,
                    length=segment_length,
                    radius=section.radius,
                    mass=0.035 if is_metal else 0.012,
                    joint_kp=1200.0 if is_metal else 90.0,
                    joint_kv=35.0 if is_metal else 7.0,
                    max_bend=0.12 if is_metal else 0.52,
                    color=section.color,
                )
            )
    return specs


def inertia_cylinder_x_axis(mass: float, radius: float, length: float) -> tuple[float, float, float]:
    i_x = 0.5 * mass * radius * radius
    i_yz = (mass / 12.0) * (3.0 * radius * radius + length * length)
    return i_x, i_yz, i_yz


def write_physical_urdf(path: Path, specs: list[PhysicalSegmentSpec]) -> None:
    lines: list[str] = ['<?xml version="1.0"?>', '<robot name="physical_endoscope">']

    def material(name: str, color: tuple[float, float, float, float]) -> None:
        lines.extend(
            [
                f'  <material name="{name}">',
                f'    <color rgba="{color[0]} {color[1]} {color[2]} {color[3]}"/>',
                "  </material>",
            ]
        )

    material("metal", (0.68, 0.70, 0.72, 1.0))
    material("rubber", (0.02, 0.025, 0.03, 1.0))

    for name in ("world_base", "stage_x", "stage_y", "yaw_link"):
        lines.extend(
            [
                f'  <link name="{name}">',
                '    <inertial><origin xyz="0 0 0" rpy="0 0 0"/><mass value="0.001"/>',
                '      <inertia ixx="1e-6" ixy="0" ixz="0" iyy="1e-6" iyz="0" izz="1e-6"/>',
                "    </inertial>",
                "  </link>",
            ]
        )

    lines.extend(
        [
            '  <joint name="drive_x" type="prismatic">',
            '    <parent link="world_base"/><child link="stage_x"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="1 0 0"/>',
            '    <limit lower="-1.6" upper="1.6" effort="600" velocity="0.35"/>',
            '    <dynamics damping="60" friction="2"/>',
            "  </joint>",
            '  <joint name="drive_y" type="prismatic">',
            '    <parent link="stage_x"/><child link="stage_y"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="0 1 0"/>',
            '    <limit lower="-1.0" upper="1.0" effort="600" velocity="0.35"/>',
            '    <dynamics damping="60" friction="2"/>',
            "  </joint>",
            '  <joint name="drive_yaw" type="revolute">',
            '    <parent link="stage_y"/><child link="yaw_link"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="0 0 1"/>',
            '    <limit lower="-3.14" upper="3.14" effort="500" velocity="1.5"/>',
            '    <dynamics damping="30" friction="1"/>',
            "  </joint>",
        ]
    )

    for i, spec in enumerate(specs):
        ixx, iyy, izz = inertia_cylinder_x_axis(spec.mass, spec.radius, spec.length)
        mat_name = "metal" if spec.material == "metal" else "rubber"
        lines.extend(
            [
                f'  <link name="seg_{i}">',
                f'    <inertial><origin xyz="{spec.length / 2.0} 0 0" rpy="0 0 0"/><mass value="{spec.mass}"/>',
                f'      <inertia ixx="{ixx}" ixy="0" ixz="0" iyy="{iyy}" iyz="0" izz="{izz}"/>',
                "    </inertial>",
                '    <visual>',
                f'      <origin xyz="{spec.length / 2.0} 0 0" rpy="0 1.57079632679 0"/>',
                f'      <geometry><cylinder radius="{spec.radius}" length="{spec.length}"/></geometry>',
                f'      <material name="{mat_name}"/>',
                "    </visual>",
                '    <collision>',
                f'      <origin xyz="{spec.length / 2.0} 0 0" rpy="0 1.57079632679 0"/>',
                f'      <geometry><cylinder radius="{spec.radius}" length="{spec.length}"/></geometry>',
                "    </collision>",
                "  </link>",
            ]
        )

        if i == 0:
            parent = "yaw_link"
            origin = "0 0 0"
            joint_type = "fixed"
            extra = ""
        else:
            parent = f"seg_{i - 1}"
            origin = f"{specs[i - 1].length} 0 0"
            joint_type = "revolute"
            prev = specs[i - 1]
            lower = -prev.max_bend
            upper = prev.max_bend
            extra = (
                '    <axis xyz="0 0 1"/>\n'
                f'    <limit lower="{lower}" upper="{upper}" effort="80" velocity="2.0"/>\n'
                f'    <dynamics damping="{prev.joint_kv}" friction="0.02"/>'
            )

        lines.append(f'  <joint name="joint_{i}" type="{joint_type}">')
        lines.append(f'    <parent link="{parent}"/><child link="seg_{i}"/>')
        lines.append(f'    <origin xyz="{origin}" rpy="0 0 0"/>')
        if extra:
            lines.append(extra)
        lines.append("  </joint>")

    lines.append("</robot>")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def add_static_scene(scene, output_dir: Path):
    scene.add_entity(gs.morphs.Plane())
    add_box(scene, (0.0, 0.0, -0.012), (PLANE_SIZE[0], PLANE_SIZE[1], 0.024), (0.82, 0.84, 0.80, 1.0))

    block_entities = []
    for block in GUIDE_BLOCKS:
        x, y = block.position
        z = block.height / 2.0
        collision = block.kind == "solid"
        if block.shape == "circle":
            ent = add_cylinder(scene, (x, y, z), block.size, block.height, block.color, collision=collision)
        elif block.shape == "square":
            ent = add_box(scene, (x, y, z), (block.size, block.size, block.height), block.color, collision=collision)
        else:
            raise ValueError(f"Unsupported guide shape: {block.shape}")
        block_entities.append((block, ent))

    target_mesh = output_dir / "target_pentagon.obj"
    make_regular_polygon_obj(target_mesh, sides=5, radius=TARGET_SIZE, height=TARGET_HEIGHT)
    add_mesh(
        scene,
        target_mesh,
        pos=(TARGET_POSITION[0], TARGET_POSITION[1], TARGET_HEIGHT / 2.0),
        color=(0.72, 0.10, 0.82, 1.0),
    )
    return block_entities


def build_physical_scene(args, output_dir: Path):
    backend_map = {"cpu": gs.cpu, "gpu": gs.gpu}
    gs.init(backend=backend_map[args.backend])

    scene = gs.Scene(
        sim_options=gs.options.SimOptions(dt=args.dt, substeps=args.substeps),
        viewer_options=gs.options.ViewerOptions(
            camera_pos=(1.9, -2.0, 1.55),
            camera_lookat=(0.0, 0.0, 0.0),
            camera_fov=45,
        ),
        show_viewer=args.viewer,
    )
    add_static_scene(scene, output_dir)

    specs = expand_endoscope_sections()
    urdf_path = output_dir / "physical_endoscope.urdf"
    write_physical_urdf(urdf_path, specs)

    z = ENDOSCOPE.base_position[2]
    urdf_kwargs = dict(
        file=str(urdf_path),
        pos=(START_POSITION[0], START_POSITION[1], z),
        fixed=True,
        merge_fixed_links=False,
        links_to_keep=tuple(f"seg_{i}" for i in range(len(specs))),
        default_armature=0.02,
    )
    try:
        urdf_morph = gs.morphs.URDF(**urdf_kwargs)
    except TypeError:
        for optional_key in ("links_to_keep", "default_armature", "merge_fixed_links"):
            urdf_kwargs.pop(optional_key, None)
        urdf_morph = gs.morphs.URDF(**urdf_kwargs)

    robot = scene.add_entity(
        morph=urdf_morph,
    )

    camera = None
    if args.record_3d:
        try:
            camera = scene.add_camera(
                res=(args.frame_width, args.frame_height),
                pos=(1.65, -1.75, 1.25),
                lookat=(0.05, 0.02, 0.02),
                fov=42,
            )
        except Exception as exc:
            print(f"3D camera disabled: {exc}")

    scene.build()

    n_dofs = robot.n_dofs
    joint_count = max(0, n_dofs - 3)
    kp = np.full(n_dofs, 80.0, dtype=np.float32)
    kv = np.full(n_dofs, 8.0, dtype=np.float32)
    kp[:3] = np.array([260.0, 260.0, 180.0], dtype=np.float32)
    kv[:3] = np.array([55.0, 55.0, 35.0], dtype=np.float32)
    for j in range(joint_count):
        spec = specs[min(j, len(specs) - 1)]
        kp[3 + j] = spec.joint_kp
        kv[3 + j] = spec.joint_kv

    if n_dofs > 0:
        robot.set_dofs_kp(kp)
        robot.set_dofs_kv(kv)
        robot.set_dofs_force_range(
            np.full(n_dofs, -120.0, dtype=np.float32),
            np.full(n_dofs, 120.0, dtype=np.float32),
        )
    if hasattr(robot, "set_friction"):
        robot.set_friction(args.endoscope_friction)

    return scene, robot, specs, camera


def path_target(step, path_points, speed, dt):
    distance_budget = step * speed * dt
    current = np.array(path_points[0], dtype=np.float32)
    for target_tuple in path_points[1:]:
        target = np.array(target_tuple, dtype=np.float32)
        delta = target - current
        dist = float(np.linalg.norm(delta))
        if dist < 1e-6:
            current = target
            continue
        if distance_budget <= dist:
            return current + delta / dist * distance_budget
        distance_budget -= dist
        current = target
    return current


def clamp_to_plane(point: np.ndarray) -> np.ndarray:
    half_x = PLANE_SIZE[0] / 2.0 - 0.10
    half_y = PLANE_SIZE[1] / 2.0 - 0.10
    return np.array(
        [
            float(np.clip(point[0], -half_x, half_x)),
            float(np.clip(point[1], -half_y, half_y)),
        ],
        dtype=np.float32,
    )


def point_on_solid_block_boundary(previous: np.ndarray, block, clearance: float) -> np.ndarray:
    block_xy = np.array(block.position, dtype=np.float32)
    direction = block_xy - previous
    norm = float(np.linalg.norm(direction))
    if norm < 1e-6:
        direction = np.array([1.0, 0.0], dtype=np.float32)
    else:
        direction /= norm
    radius = solid_block_radius(block) + max(section.radius for section in ENDOSCOPE.sections) + clearance
    return clamp_to_plane(block_xy - direction * radius)


def make_guided_route(clearance: float = 0.025) -> tuple[list[tuple[float, float]], list[RouteTarget]]:
    points: list[tuple[float, float]] = [START_POSITION]
    targets: list[RouteTarget] = []
    blocks = list(used_guide_blocks())
    previous = np.array(START_POSITION, dtype=np.float32)

    for block in blocks:
        block_xy = np.array(block.position, dtype=np.float32)

        if block.kind == "insertable":
            target_xy = block_xy
            reach_mode = "through_center"
            points.append((float(target_xy[0]), float(target_xy[1])))
            previous = block_xy
        else:
            target_xy = point_on_solid_block_boundary(previous, block, clearance)
            reach_mode = "touch_boundary"
            points.append((float(target_xy[0]), float(target_xy[1])))
            previous = target_xy

        targets.append(
            RouteTarget(
                name=block.name,
                kind=block.kind,
                shape=block.shape,
                block_position=block.position,
                target_position=(float(target_xy[0]), float(target_xy[1])),
                reach_mode=reach_mode,
            )
        )

    points.append(TARGET_POSITION)
    targets.append(
        RouteTarget(
            name="target",
            kind="target",
            shape="pentagon",
            block_position=TARGET_POSITION,
            target_position=TARGET_POSITION,
            reach_mode="reach_target",
        )
    )
    return points, targets


def tensor_to_numpy(value):
    if hasattr(value, "detach"):
        return value.detach().cpu().numpy()
    return np.asarray(value)


def get_centerline(robot, fallback_base_xy) -> list[tuple[float, float]]:
    try:
        positions = tensor_to_numpy(robot.get_links_pos())
        if positions.ndim == 3:
            positions = positions[0]
        # The first 4 links are world/stage/yaw helpers. The rest are endoscope segments.
        segment_positions = positions[4:]
        if len(segment_positions) > 0:
            return [(float(p[0]), float(p[1])) for p in segment_positions]
    except Exception:
        pass
    return [(float(fallback_base_xy[0]), float(fallback_base_xy[1]))]


def contact_magnitude(robot) -> float:
    try:
        forces = tensor_to_numpy(robot.get_links_net_contact_force())
        return float(np.linalg.norm(forces))
    except Exception:
        return 0.0


def solid_block_radius(block) -> float:
    if block.shape == "circle":
        return block.size
    return block.size * 0.707


def resolve_solid_block_overlap(point: np.ndarray, endoscope_radius: float) -> tuple[np.ndarray, float]:
    corrected = point.astype(np.float32).copy()
    contact = 0.0
    for block in GUIDE_BLOCKS:
        if block.kind != "solid":
            continue
        center = np.array(block.position, dtype=np.float32)
        delta = corrected - center
        dist = float(np.linalg.norm(delta))
        min_dist = solid_block_radius(block) + endoscope_radius
        if dist >= min_dist:
            continue
        if dist < 1e-6:
            delta = np.array([1.0, 0.0], dtype=np.float32)
            dist = 1.0
        penetration = min_dist - dist
        corrected = corrected + delta / dist * penetration
        contact += penetration * 12000.0
    return corrected, contact


def append_path_history(history: list[np.ndarray], point: np.ndarray, min_spacing: float) -> None:
    if not history:
        history.append(point.astype(np.float32).copy())
        return
    if float(np.linalg.norm(point - history[-1])) >= min_spacing:
        history.append(point.astype(np.float32).copy())


def centerline_from_history(
    history: list[np.ndarray],
    specs: list[PhysicalSegmentSpec],
    endoscope_radius: float,
) -> tuple[list[tuple[float, float]], float]:
    if not history:
        return [START_POSITION], 0.0

    segment_lengths = [spec.length for spec in specs]
    centerline: list[tuple[float, float]] = []
    contact_total = 0.0
    cursor = history[-1].copy()
    history_index = len(history) - 1

    corrected, contact = resolve_solid_block_overlap(cursor, endoscope_radius)
    centerline.append((float(corrected[0]), float(corrected[1])))
    contact_total += contact

    for segment_length in segment_lengths[1:]:
        remaining = segment_length
        while remaining > 1e-6 and history_index > 0:
            previous = history[history_index - 1]
            delta = cursor - previous
            dist = float(np.linalg.norm(delta))
            if dist < 1e-6:
                history_index -= 1
                continue
            if dist >= remaining:
                cursor = cursor - delta / dist * remaining
                remaining = 0.0
            else:
                cursor = previous.copy()
                history_index -= 1
                remaining -= dist

        corrected, contact = resolve_solid_block_overlap(cursor, endoscope_radius)
        centerline.append((float(corrected[0]), float(corrected[1])))
        contact_total += contact

    return centerline, contact_total


def heading_from_centerline(centerline: list[tuple[float, float]], fallback: float) -> float:
    if len(centerline) < 2:
        return fallback
    tip = np.array(centerline[0], dtype=np.float32)
    neck = np.array(centerline[1], dtype=np.float32)
    delta = tip - neck
    if float(np.linalg.norm(delta)) < 1e-6:
        return fallback
    return math.atan2(float(delta[1]), float(delta[0]))


def route_target_to_dict(target: RouteTarget) -> dict:
    return {
        "name": target.name,
        "kind": target.kind,
        "shape": target.shape,
        "block_position": [float(target.block_position[0]), float(target.block_position[1])],
        "target_position": [float(target.target_position[0]), float(target.target_position[1])],
        "reach_mode": target.reach_mode,
    }


def save_3d_render_frame(camera, image_path: Path) -> bool:
    if camera is None:
        return False
    try:
        rendered = camera.render(rgb=True)
        if isinstance(rendered, dict):
            image = rendered.get("rgb") or rendered.get("color") or rendered.get("image")
        elif isinstance(rendered, tuple):
            image = rendered[0]
        else:
            image = rendered

        image = tensor_to_numpy(image)
        if image.ndim == 4:
            image = image[0]
        if image.dtype != np.uint8:
            if float(np.nanmax(image)) <= 1.0:
                image = np.clip(image * 255.0, 0, 255)
            image = image.astype(np.uint8)

        from PIL import Image

        Image.fromarray(image[..., :3]).save(image_path)
        return True
    except Exception as exc:
        print(f"3D render frame skipped: {exc}")
        return False


def update_reached_targets(
    tip_xy: np.ndarray,
    route_targets: list[RouteTarget],
    reached: dict[str, int],
    step: int,
    radius: float,
) -> None:
    for target in route_targets:
        if target.name in reached:
            continue
        target_xy = np.array(target.target_position, dtype=np.float32)
        if float(np.linalg.norm(tip_xy - target_xy)) <= radius:
            reached[target.name] = step


def current_route_target(route_targets: list[RouteTarget], reached: dict[str, int]) -> RouteTarget:
    for target in route_targets:
        if target.name not in reached:
            return target
    return route_targets[-1]


def run(args):
    output_dir = Path(args.output_dir)
    episode_dir = output_dir / f"episode_{args.episode_index:06d}" if args.record else output_dir
    render_frames_dir = episode_dir / "render_frames"
    debug_frames_dir = episode_dir / "debug_frames"
    episode_dir.mkdir(parents=True, exist_ok=True)
    if args.record:
        for directory in (render_frames_dir, debug_frames_dir):
            directory.mkdir(parents=True, exist_ok=True)
            for old_frame in directory.glob("*.png"):
                old_frame.unlink()

    scene, robot, specs, camera = build_physical_scene(args, episode_dir)
    level_label = experiment_level_label()
    path_points, route_targets = make_guided_route(args.solid_clearance)
    reached_targets: dict[str, int] = {}

    samples = []
    annotations = []
    render_frame_paths = []
    debug_frame_paths = []
    q_target = np.zeros(robot.n_dofs, dtype=np.float32)
    previous_drive_xy = np.array(START_POSITION, dtype=np.float32)
    path_history: list[np.ndarray] = [np.array(START_POSITION, dtype=np.float32)]
    endoscope_radius = max(section.radius for section in ENDOSCOPE.sections)

    for step in range(args.max_steps):
        drive_xy = path_target(step, path_points, args.drive_speed, args.dt)
        drive_xy, head_contact = resolve_solid_block_overlap(drive_xy, endoscope_radius)
        append_path_history(path_history, drive_xy, args.history_spacing)

        delta = drive_xy - previous_drive_xy
        if float(np.linalg.norm(delta)) > 1e-6:
            yaw = math.atan2(float(delta[1]), float(delta[0]))
        else:
            yaw = q_target[2]

        q_target[0] = float(drive_xy[0] - START_POSITION[0])
        q_target[1] = float(drive_xy[1] - START_POSITION[1])
        q_target[2] = float(yaw)

        if robot.n_dofs > 3 and args.steering_gain > 0.0:
            bend_phase = step * args.dt * args.bend_frequency
            for j in range(robot.n_dofs - 3):
                spec = specs[min(j, len(specs) - 1)]
                q_target[3 + j] = (
                    args.steering_gain
                    * spec.max_bend
                    * math.sin(bend_phase - j * args.bend_lag)
                )

        robot.control_dofs_position(q_target)
        scene.step()

        centerline, proxy_contact = centerline_from_history(path_history, specs, endoscope_radius)
        tip_xy = np.array(centerline[0], dtype=np.float32)
        yaw = heading_from_centerline(centerline, yaw)
        distance_to_target = float(np.linalg.norm(tip_xy - np.array(TARGET_POSITION, dtype=np.float32)))
        contact_norm = max(contact_magnitude(robot), proxy_contact, head_contact)
        update_reached_targets(tip_xy, route_targets, reached_targets, step, args.route_reach_radius)
        active_target = current_route_target(route_targets, reached_targets)

        samples.append(
            {
                "step": step,
                "level": level_label,
                "active_route_target": active_target.name,
                "reached_route_targets": "|".join(reached_targets.keys()),
                "drive_x": float(drive_xy[0]),
                "drive_y": float(drive_xy[1]),
                "tip_x": float(tip_xy[0]),
                "tip_y": float(tip_xy[1]),
                "yaw": float(yaw),
                "distance_to_target": distance_to_target,
                "contact_force_norm": contact_norm,
                "used_guide_blocks": "|".join(USED_GUIDE_BLOCK_NAMES),
            }
        )

        if args.record and step % args.frame_stride == 0:
            frame_idx = len(debug_frame_paths)
            debug_frame_path = debug_frames_dir / f"{frame_idx:06d}.png"
            draw_training_frame(
                debug_frame_path,
                tip_xy=tip_xy,
                heading=yaw,
                centerline=centerline,
                frame_idx=frame_idx,
                image_size=(args.frame_width, args.frame_height),
            )
            debug_frame_paths.append(debug_frame_path)
            render_frame_path = render_frames_dir / f"{frame_idx:06d}.png"
            if save_3d_render_frame(camera, render_frame_path):
                render_frame_paths.append(render_frame_path)
            annotation = build_frame_annotation(frame_idx, tip_xy, yaw, centerline)
            annotation["route"] = {
                "targets": [route_target_to_dict(target) for target in route_targets],
                "active_target": route_target_to_dict(active_target),
                "reached_target_names": list(reached_targets.keys()),
            }
            annotation["physics"] = {"contact_force_norm": contact_norm}
            annotations.append(annotation)

        previous_drive_xy = drive_xy
        if distance_to_target <= args.success_radius:
            break

    csv_path = episode_dir / "trajectory.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "step",
                "level",
                "active_route_target",
                "reached_route_targets",
                "drive_x",
                "drive_y",
                "tip_x",
                "tip_y",
                "yaw",
                "distance_to_target",
                "contact_force_norm",
                "used_guide_blocks",
            ],
        )
        writer.writeheader()
        writer.writerows(samples)

    if args.record:
        metadata = {
            "mode": "guided_block_route_endoscope",
            "episode_index": args.episode_index,
            "level": level_label,
            "used_guide_blocks": list(USED_GUIDE_BLOCK_NAMES),
            "target_position": list(TARGET_POSITION),
            "route_rule": "start -> each USED_GUIDE_BLOCK_NAMES block in order -> target",
            "route_targets": [route_target_to_dict(target) for target in route_targets],
            "path_points": [[float(x), float(y)] for x, y in path_points],
            "reached_route_targets": reached_targets,
            "success": bool(samples and samples[-1]["distance_to_target"] <= args.success_radius),
            "render_3d_available": bool(render_frame_paths),
            "render_frame_count": len(render_frame_paths),
            "debug_frame_count": len(debug_frame_paths),
            "frame_stride": args.frame_stride,
            "image_size": [args.frame_width, args.frame_height],
            "endoscope_segments": len(specs),
            "control": {
                "drive_speed": args.drive_speed,
                "steering_gain": args.steering_gain,
                "bend_frequency": args.bend_frequency,
                "bend_lag": args.bend_lag,
                "history_spacing": args.history_spacing,
            },
        }
        (episode_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        (episode_dir / "annotations.json").write_text(json.dumps(annotations, indent=2), encoding="utf-8")
        if args.video:
            if render_frame_paths:
                write_video(render_frame_paths, episode_dir / "video_3d.mp4", fps=args.video_fps)
            write_video(debug_frame_paths, episode_dir / "debug_route.mp4", fps=args.video_fps)

    print(f"Physical simulation level: {level_label}")
    print(f"Finished {len(samples)} steps.")
    print(f"Trajectory saved to: {csv_path}")
    if args.record:
        print(f"3D render frames saved to: {render_frames_dir}")
        print(f"Debug frames saved to: {debug_frames_dir}")
        print(f"Annotations saved to: {episode_dir / 'annotations.json'}")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--viewer", action="store_true")
    parser.add_argument("--backend", choices=("gpu", "cpu"), default="gpu")
    parser.add_argument("--output-dir", default="/outputs/endoscope_genesis_physical")
    parser.add_argument("--dt", type=float, default=0.01)
    parser.add_argument("--substeps", type=int, default=8)
    parser.add_argument("--max-steps", type=int, default=2500)
    parser.add_argument("--success-radius", type=float, default=0.10)
    parser.add_argument("--drive-speed", type=float, default=0.12)
    parser.add_argument("--steering-gain", type=float, default=0.0)
    parser.add_argument("--bend-frequency", type=float, default=4.2)
    parser.add_argument("--bend-lag", type=float, default=0.32)
    parser.add_argument("--endoscope-friction", type=float, default=1.2)
    parser.add_argument("--solid-clearance", type=float, default=0.10)
    parser.add_argument("--history-spacing", type=float, default=0.012)
    parser.add_argument("--route-reach-radius", type=float, default=0.075)
    parser.add_argument("--record-3d", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--video", action="store_true")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--frame-stride", type=int, default=10)
    parser.add_argument("--frame-width", type=int, default=1280)
    parser.add_argument("--frame-height", type=int, default=848)
    parser.add_argument("--video-fps", type=int, default=24)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
