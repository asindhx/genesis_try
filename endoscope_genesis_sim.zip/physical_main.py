import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import genesis as gs
import numpy as np

from config import (
    ENDOSCOPE,
    GUIDE_BLOCKS,
    PLANE_SIZE,
    START_CLAMPS,
    START_POSITION,
    TARGET_HEIGHT,
    TARGET_POSITION,
    TARGET_SIZE,
    USED_GUIDE_BLOCK_NAMES,
    experiment_level_label,
    used_guide_blocks,
)
from main import (
    add_box,
    add_cylinder,
    add_mesh,
    build_frame_annotation,
    draw_training_frame,
    horizontal_cylinder_quat,
    make_regular_polygon_obj,
    write_video,
)


@dataclass(frozen=True)
class PhysicalSegmentSpec:
    name: str
    material: str
    length: float
    radius: float
    mass: float
    joint_kp: float
    joint_kv: float
    max_bend: float
    color: tuple[float, float, float, float]


@dataclass(frozen=True)
class RouteTarget:
    name: str
    kind: str
    shape: str
    block_position: tuple[float, float]
    target_position: tuple[float, float]
    reach_mode: str


@dataclass(frozen=True)
class MotionSegment:
    kind: str
    points: tuple[tuple[float, float], ...]
    steps: int = 0
    route_target: str = ""


@dataclass
class VisualEndoscopeSegment:
    entity: object
    length: float
    radius: float
    material: str


def expand_endoscope_sections() -> list[PhysicalSegmentSpec]:
    specs: list[PhysicalSegmentSpec] = []
    for section in ENDOSCOPE.sections:
        segment_length = section.length / section.segment_count
        for idx in range(section.segment_count):
            is_metal = section.material == "metal"
            specs.append(
                PhysicalSegmentSpec(
                    name=f"{section.name}_{idx}",
                    material=section.material,
                    length=segment_length,
                    radius=section.radius,
                    mass=0.035 if is_metal else 0.012,
                    joint_kp=1200.0 if is_metal else 90.0,
                    joint_kv=35.0 if is_metal else 7.0,
                    max_bend=0.12 if is_metal else 0.52,
                    color=section.color,
                )
            )
    return specs


def inertia_cylinder_x_axis(mass: float, radius: float, length: float) -> tuple[float, float, float]:
    i_x = 0.5 * mass * radius * radius
    i_yz = (mass / 12.0) * (3.0 * radius * radius + length * length)
    return i_x, i_yz, i_yz


def write_physical_urdf(path: Path, specs: list[PhysicalSegmentSpec]) -> None:
    lines: list[str] = ['<?xml version="1.0"?>', '<robot name="physical_endoscope">']

    def material(name: str, color: tuple[float, float, float, float]) -> None:
        lines.extend(
            [
                f'  <material name="{name}">',
                f'    <color rgba="{color[0]} {color[1]} {color[2]} {color[3]}"/>',
                "  </material>",
            ]
        )

    material("metal", (0.68, 0.70, 0.72, 1.0))
    material("rubber", (0.02, 0.025, 0.03, 1.0))

    for name in ("world_base", "stage_x", "stage_y", "yaw_link"):
        lines.extend(
            [
                f'  <link name="{name}">',
                '    <inertial><origin xyz="0 0 0" rpy="0 0 0"/><mass value="0.001"/>',
                '      <inertia ixx="1e-6" ixy="0" ixz="0" iyy="1e-6" iyz="0" izz="1e-6"/>',
                "    </inertial>",
                "  </link>",
            ]
        )

    lines.extend(
        [
            '  <joint name="drive_x" type="prismatic">',
            '    <parent link="world_base"/><child link="stage_x"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="1 0 0"/>',
            '    <limit lower="-1.6" upper="1.6" effort="600" velocity="0.35"/>',
            '    <dynamics damping="60" friction="2"/>',
            "  </joint>",
            '  <joint name="drive_y" type="prismatic">',
            '    <parent link="stage_x"/><child link="stage_y"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="0 1 0"/>',
            '    <limit lower="-1.0" upper="1.0" effort="600" velocity="0.35"/>',
            '    <dynamics damping="60" friction="2"/>',
            "  </joint>",
            '  <joint name="drive_yaw" type="revolute">',
            '    <parent link="stage_y"/><child link="yaw_link"/>',
            '    <origin xyz="0 0 0" rpy="0 0 0"/>',
            '    <axis xyz="0 0 1"/>',
            '    <limit lower="-3.14" upper="3.14" effort="500" velocity="1.5"/>',
            '    <dynamics damping="30" friction="1"/>',
            "  </joint>",
        ]
    )

    for i, spec in enumerate(specs):
        ixx, iyy, izz = inertia_cylinder_x_axis(spec.mass, spec.radius, spec.length)
        mat_name = "metal" if spec.material == "metal" else "rubber"
        lines.extend(
            [
                f'  <link name="seg_{i}">',
                f'    <inertial><origin xyz="{spec.length / 2.0} 0 0" rpy="0 0 0"/><mass value="{spec.mass}"/>',
                f'      <inertia ixx="{ixx}" ixy="0" ixz="0" iyy="{iyy}" iyz="0" izz="{izz}"/>',
                "    </inertial>",
                '    <visual>',
                f'      <origin xyz="{spec.length / 2.0} 0 0" rpy="0 1.57079632679 0"/>',
                f'      <geometry><cylinder radius="{spec.radius}" length="{spec.length}"/></geometry>',
                f'      <material name="{mat_name}"/>',
                "    </visual>",
                '    <collision>',
                f'      <origin xyz="{spec.length / 2.0} 0 0" rpy="0 1.57079632679 0"/>',
                f'      <geometry><cylinder radius="{spec.radius}" length="{spec.length}"/></geometry>',
                "    </collision>",
                "  </link>",
            ]
        )

        if i == 0:
            parent = "yaw_link"
            origin = "0 0 0"
            joint_type = "fixed"
            extra = ""
        else:
            parent = f"seg_{i - 1}"
            origin = f"{specs[i - 1].length} 0 0"
            joint_type = "revolute"
            prev = specs[i - 1]
            lower = -prev.max_bend
            upper = prev.max_bend
            extra = (
                '    <axis xyz="0 0 1"/>\n'
                f'    <limit lower="{lower}" upper="{upper}" effort="80" velocity="2.0"/>\n'
                f'    <dynamics damping="{prev.joint_kv}" friction="0.02"/>'
            )

        lines.append(f'  <joint name="joint_{i}" type="{joint_type}">')
        lines.append(f'    <parent link="{parent}"/><child link="seg_{i}"/>')
        lines.append(f'    <origin xyz="{origin}" rpy="0 0 0"/>')
        if extra:
            lines.append(extra)
        lines.append("  </joint>")

    lines.append("</robot>")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def add_static_scene(scene, output_dir: Path):
    scene.add_entity(gs.morphs.Plane())
    add_box(scene, (0.0, 0.0, -0.012), (PLANE_SIZE[0], PLANE_SIZE[1], 0.024), (0.82, 0.84, 0.80, 1.0))

    for clamp in START_CLAMPS:
        add_box(
            scene,
            (clamp.position[0], clamp.position[1], clamp.height / 2.0),
            (clamp.size[0], clamp.size[1], clamp.height),
            clamp.color,
            collision=True,
        )

    block_entities = []
    for block in GUIDE_BLOCKS:
        x, y = block.position
        z = block.height / 2.0
        collision = block.kind == "solid"
        if block.shape == "circle":
            ent = add_cylinder(scene, (x, y, z), block.size, block.height, block.color, collision=collision)
        elif block.shape == "square":
            ent = add_box(scene, (x, y, z), (block.size, block.size, block.height), block.color, collision=collision)
        else:
            raise ValueError(f"Unsupported guide shape: {block.shape}")
        block_entities.append((block, ent))

    target_mesh = output_dir / "target_pentagon.obj"
    make_regular_polygon_obj(target_mesh, sides=5, radius=TARGET_SIZE, height=TARGET_HEIGHT)
    add_mesh(
        scene,
        target_mesh,
        pos=(TARGET_POSITION[0], TARGET_POSITION[1], TARGET_HEIGHT / 2.0),
        color=(0.72, 0.10, 0.82, 1.0),
    )
    return block_entities


def create_visual_endoscope(scene, specs: list[PhysicalSegmentSpec]) -> list[VisualEndoscopeSegment]:
    visual_segments: list[VisualEndoscopeSegment] = []
    tail_x, tail_y, z = ENDOSCOPE.base_position
    cursor_x = tail_x

    for spec in reversed(specs):
        entity = add_cylinder(
            scene,
            pos=(cursor_x, tail_y, z),
            radius=spec.radius,
            height=spec.length,
            color=spec.color,
            fixed=True,
            collision=False,
        )
        visual_segments.append(
            VisualEndoscopeSegment(
                entity=entity,
                length=spec.length,
                radius=spec.radius,
                material=spec.material,
            )
        )
        cursor_x += spec.length

    return visual_segments


def build_physical_scene(args, output_dir: Path):
    backend_map = {"cpu": gs.cpu, "gpu": gs.gpu}
    gs.init(backend=backend_map[args.backend])

    scene_kwargs = dict(
        sim_options=gs.options.SimOptions(dt=args.dt, substeps=args.substeps),
        viewer_options=gs.options.ViewerOptions(
            camera_pos=(1.9, -2.0, 1.55),
            camera_lookat=(0.0, 0.0, 0.0),
            camera_fov=45,
        ),
        show_viewer=args.viewer,
    )
    if hasattr(gs, "renderers") and hasattr(gs.renderers, "Rasterizer"):
        scene_kwargs["renderer"] = gs.renderers.Rasterizer()
    try:
        scene = gs.Scene(**scene_kwargs)
    except TypeError:
        scene_kwargs.pop("renderer", None)
        scene = gs.Scene(**scene_kwargs)
    add_static_scene(scene, output_dir)

    specs = expand_endoscope_sections()
    visual_segments = create_visual_endoscope(scene, specs)

    camera = None
    if args.record_3d:
        try:
            camera = scene.add_camera(
                res=(args.frame_width, args.frame_height),
                pos=(0.0, 0.0, args.camera_height),
                lookat=(0.0, 0.0, 0.0),
                fov=args.camera_fov,
                GUI=False,
            )
        except Exception as exc:
            print(f"3D camera disabled: {exc}")

    scene.build()

    return scene, visual_segments, specs, camera


def path_target(step, path_points, speed, dt):
    distance_budget = step * speed * dt
    current = np.array(path_points[0], dtype=np.float32)
    for target_tuple in path_points[1:]:
        target = np.array(target_tuple, dtype=np.float32)
        delta = target - current
        dist = float(np.linalg.norm(delta))
        if dist < 1e-6:
            current = target
            continue
        if distance_budget <= dist:
            return current + delta / dist * distance_budget
        distance_budget -= dist
        current = target
    return current


def clamp_to_plane(point: np.ndarray) -> np.ndarray:
    half_x = PLANE_SIZE[0] / 2.0 - 0.10
    half_y = PLANE_SIZE[1] / 2.0 - 0.10
    return np.array(
        [
            float(np.clip(point[0], -half_x, half_x)),
            float(np.clip(point[1], -half_y, half_y)),
        ],
        dtype=np.float32,
    )


def point_on_solid_block_boundary(previous: np.ndarray, block, clearance: float) -> np.ndarray:
    block_xy = np.array(block.position, dtype=np.float32)
    direction = block_xy - previous
    norm = float(np.linalg.norm(direction))
    if norm < 1e-6:
        direction = np.array([1.0, 0.0], dtype=np.float32)
    else:
        direction /= norm
    radius = solid_block_radius(block) + max(section.radius for section in ENDOSCOPE.sections) + clearance
    return clamp_to_plane(block_xy - direction * radius)


def make_guided_route(clearance: float = 0.025) -> tuple[list[tuple[float, float]], list[RouteTarget]]:
    points: list[tuple[float, float]] = [START_POSITION]
    targets: list[RouteTarget] = []
    blocks = list(used_guide_blocks())
    previous = np.array(START_POSITION, dtype=np.float32)

    for block in blocks:
        block_xy = np.array(block.position, dtype=np.float32)

        if block.kind == "insertable":
            target_xy = block_xy
            reach_mode = "through_center"
            points.append((float(target_xy[0]), float(target_xy[1])))
            previous = block_xy
        else:
            target_xy = point_on_solid_block_boundary(previous, block, clearance)
            reach_mode = "touch_boundary"
            points.append((float(target_xy[0]), float(target_xy[1])))
            previous = target_xy

        targets.append(
            RouteTarget(
                name=block.name,
                kind=block.kind,
                shape=block.shape,
                block_position=block.position,
                target_position=(float(target_xy[0]), float(target_xy[1])),
                reach_mode=reach_mode,
            )
        )

    points.append(TARGET_POSITION)
    targets.append(
        RouteTarget(
            name="target",
            kind="target",
            shape="pentagon",
            block_position=TARGET_POSITION,
            target_position=TARGET_POSITION,
            reach_mode="reach_target",
        )
    )
    return points, targets


def angle_normalize(angle: float) -> float:
    while angle <= -math.pi:
        angle += 2.0 * math.pi
    while angle > math.pi:
        angle -= 2.0 * math.pi
    return angle


def make_solid_turn_arc(
    block,
    current: np.ndarray,
    next_goal: np.ndarray,
    clearance: float,
    side: str,
    samples: int,
    min_turn_radius: float,
) -> list[tuple[float, float]]:
    center = np.array(block.position, dtype=np.float32)
    obstacle_radius = solid_block_radius(block) + max(section.radius for section in ENDOSCOPE.sections) + clearance
    route_direction = center - current
    route_norm = float(np.linalg.norm(route_direction))
    if route_norm < 1e-6:
        route_direction = np.array([1.0, 0.0], dtype=np.float32)
    else:
        route_direction /= route_norm
    side_sign = 1.0 if side == "left" else -1.0
    normal = np.array([-route_direction[1], route_direction[0]], dtype=np.float32) * side_sign

    exit_direction = next_goal - center
    exit_norm = float(np.linalg.norm(exit_direction))
    if exit_norm < 1e-6:
        exit_direction = route_direction
    else:
        exit_direction /= exit_norm

    approach_distance = max(obstacle_radius * 1.45, min_turn_radius * 0.35)
    entry_point = center - route_direction * obstacle_radius
    side_point = center + normal * obstacle_radius
    exit_point = center + exit_direction * obstacle_radius
    control_1 = current + route_direction * min(approach_distance, max(0.05, float(np.linalg.norm(entry_point - current)) * 0.65))
    control_2 = side_point - route_direction * min_turn_radius * 0.22

    points: list[tuple[float, float]] = []
    for i in range(1, max(3, samples // 2) + 1):
        t = i / max(3, samples // 2)
        point = (
            (1.0 - t) ** 3 * current
            + 3.0 * (1.0 - t) ** 2 * t * control_1
            + 3.0 * (1.0 - t) * t**2 * control_2
            + t**3 * side_point
        )
        point = clamp_to_plane(point.astype(np.float32))
        if not points or np.linalg.norm(np.array(points[-1], dtype=np.float32) - point) > 1e-5:
            points.append((float(point[0]), float(point[1])))

    start_angle = math.atan2(float(side_point[1] - center[1]), float(side_point[0] - center[0]))
    end_angle = math.atan2(float(exit_point[1] - center[1]), float(exit_point[0] - center[0]))
    delta = angle_normalize(end_angle - start_angle)
    if side == "left" and delta < 0:
        delta += 2.0 * math.pi
    elif side == "right" and delta > 0:
        delta -= 2.0 * math.pi

    for i in range(1, max(3, samples // 2) + 1):
        t = i / max(3, samples // 2)
        angle = start_angle + delta * t
        point = center + np.array([math.cos(angle), math.sin(angle)], dtype=np.float32) * obstacle_radius
        point = clamp_to_plane(point)
        if not points or np.linalg.norm(np.array(points[-1], dtype=np.float32) - point) > 1e-5:
            points.append((float(point[0]), float(point[1])))
    return points


def controlled_front_length() -> float:
    # The operator actively steers the front assembly: metal tip, front bending
    # section, and the second metal sleeve. Rear rubber tube is passive.
    return sum(section.length for section in ENDOSCOPE.sections[:3])


def minimum_turn_radius(max_steer_angle_deg: float) -> float:
    angle = math.radians(max(5.0, max_steer_angle_deg))
    return controlled_front_length() / angle


def make_motion_plan(
    clearance: float,
    turn_side: str,
    turn_samples: int,
    steer_pause_steps: int,
    max_steer_angle_deg: float,
) -> tuple[list[MotionSegment], list[RouteTarget]]:
    route_points, route_targets = make_guided_route(clearance)
    blocks = list(used_guide_blocks())
    segments: list[MotionSegment] = []
    current = np.array(route_points[0], dtype=np.float32)
    min_radius = minimum_turn_radius(max_steer_angle_deg)

    for idx, block in enumerate(blocks):
        target = route_targets[idx]
        target_xy = np.array(target.target_position, dtype=np.float32)
        if block.kind == "solid":
            next_goal_tuple = route_targets[idx + 1].target_position if idx + 1 < len(blocks) else TARGET_POSITION
            next_goal = np.array(next_goal_tuple, dtype=np.float32)
            arc = make_solid_turn_arc(block, current, next_goal, clearance, turn_side, turn_samples, min_radius)
            if arc:
                pause_point = arc[0]
                segments.append(
                    MotionSegment(
                        "move",
                        ((float(current[0]), float(current[1])), pause_point),
                        route_target=target.name,
                    )
                )
                segments.append(MotionSegment("pause", (pause_point,), steps=steer_pause_steps, route_target=target.name))
                if len(arc) > 1:
                    segments.append(MotionSegment("move", tuple([pause_point, *arc[1:]]), route_target=target.name))
                current = np.array(arc[-1], dtype=np.float32)
            else:
                current = target_xy
        else:
            segments.append(MotionSegment("move", ((float(current[0]), float(current[1])), target.target_position), route_target=target.name))
            current = target_xy

    segments.append(MotionSegment("move", ((float(current[0]), float(current[1])), TARGET_POSITION), route_target="target"))
    return segments, route_targets


def motion_position_at(step: int, motion_segments: list[MotionSegment], speed: float, dt: float) -> tuple[np.ndarray, str]:
    distance_budget = step * speed * dt
    elapsed_pause_steps = 0
    current = np.array(START_POSITION, dtype=np.float32)
    current_target = motion_segments[0].route_target if motion_segments else "target"

    for segment in motion_segments:
        current_target = segment.route_target or current_target
        if segment.kind == "pause":
            pause_distance = segment.steps * speed * dt
            if distance_budget <= pause_distance:
                return np.array(segment.points[0], dtype=np.float32), current_target
            distance_budget -= pause_distance
            elapsed_pause_steps += segment.steps
            current = np.array(segment.points[-1], dtype=np.float32)
            continue

        points = [np.array(point, dtype=np.float32) for point in segment.points]
        current = points[0]
        for target in points[1:]:
            delta = target - current
            dist = float(np.linalg.norm(delta))
            if dist < 1e-6:
                current = target
                continue
            if distance_budget <= dist:
                return current + delta / dist * distance_budget, current_target
            distance_budget -= dist
            current = target

    return current, "target"


def tensor_to_numpy(value):
    if hasattr(value, "detach"):
        return value.detach().cpu().numpy()
    return np.asarray(value)


def solid_block_radius(block) -> float:
    if block.shape == "circle":
        return block.size
    return block.size * 0.707


def resolve_solid_block_overlap(point: np.ndarray, endoscope_radius: float) -> tuple[np.ndarray, float]:
    corrected = point.astype(np.float32).copy()
    contact = 0.0
    for block in GUIDE_BLOCKS:
        if block.kind != "solid":
            continue
        center = np.array(block.position, dtype=np.float32)
        delta = corrected - center
        dist = float(np.linalg.norm(delta))
        min_dist = solid_block_radius(block) + endoscope_radius
        if dist >= min_dist:
            continue
        if dist < 1e-6:
            delta = np.array([1.0, 0.0], dtype=np.float32)
            dist = 1.0
        penetration = min_dist - dist
        corrected = corrected + delta / dist * penetration
        contact += penetration * 12000.0
    return corrected, contact


def append_path_history(history: list[np.ndarray], point: np.ndarray, min_spacing: float) -> None:
    if not history:
        history.append(point.astype(np.float32).copy())
        return
    if float(np.linalg.norm(point - history[-1])) >= min_spacing:
        history.append(point.astype(np.float32).copy())


def path_polyline_to_tip(history: list[np.ndarray], tip_xy: np.ndarray) -> list[np.ndarray]:
    points: list[np.ndarray] = []
    for point in history:
        if not points or float(np.linalg.norm(point - points[-1])) >= 1e-6:
            points.append(point.astype(np.float32).copy())
    if not points or float(np.linalg.norm(tip_xy - points[-1])) >= 1e-6:
        points.append(tip_xy.astype(np.float32).copy())
    return points


def smooth_polyline(points: list[np.ndarray], passes: int, strength: float) -> list[np.ndarray]:
    if len(points) <= 2 or passes <= 0 or strength <= 0.0:
        return points
    smoothed = [point.copy() for point in points]
    for _ in range(passes):
        updated = [smoothed[0].copy()]
        for prev_point, point, next_point in zip(smoothed[:-2], smoothed[1:-1], smoothed[2:]):
            averaged = (prev_point + next_point) * 0.5
            updated.append((point * (1.0 - strength) + averaged * strength).astype(np.float32))
        updated.append(smoothed[-1].copy())
        smoothed = updated
    return smoothed


def point_back_from_tip(points_tail_to_tip: list[np.ndarray], distance_from_tip: float) -> np.ndarray:
    if not points_tail_to_tip:
        return np.array(START_POSITION, dtype=np.float32)

    remaining = float(distance_from_tip)
    cursor = points_tail_to_tip[-1].copy()
    for idx in range(len(points_tail_to_tip) - 1, 0, -1):
        tip_side = points_tail_to_tip[idx]
        tail_side = points_tail_to_tip[idx - 1]
        delta = tail_side - tip_side
        dist = float(np.linalg.norm(delta))
        if dist < 1e-6:
            continue
        if remaining <= dist:
            return (tip_side + delta / dist * remaining).astype(np.float32)
        remaining -= dist
        cursor = tail_side.copy()

    if len(points_tail_to_tip) >= 2:
        first_direction = points_tail_to_tip[0] - points_tail_to_tip[1]
        norm = float(np.linalg.norm(first_direction))
        if norm > 1e-6:
            return (points_tail_to_tip[0] + first_direction / norm * remaining).astype(np.float32)
    return cursor.astype(np.float32)


def centerline_from_history(
    history: list[np.ndarray],
    specs: list[PhysicalSegmentSpec],
    endoscope_radius: float,
    visible_length: float,
) -> tuple[list[tuple[float, float]], float]:
    if not history:
        return [START_POSITION], 0.0

    tip_xy = history[-1]
    polyline = smooth_polyline(path_polyline_to_tip(history, tip_xy), passes=3, strength=0.22)
    distances = [0.0]
    total = 0.0
    for spec in specs:
        total += spec.length
        if total > visible_length:
            break
        distances.append(total)
    center_samples = [point_back_from_tip(polyline, distance) for distance in distances]
    centerline: list[tuple[float, float]] = []
    contact_total = 0.0

    for sample in center_samples:
        corrected, contact = resolve_solid_block_overlap(sample, endoscope_radius)
        centerline.append((float(corrected[0]), float(corrected[1])))
        contact_total += contact

    return centerline, contact_total


def update_visual_endoscope_segments(
    visual_segments: list[VisualEndoscopeSegment],
    centerline: list[tuple[float, float]],
    hidden_segment_indices: set[int] | None = None,
) -> None:
    if len(centerline) < 2:
        return
    z = ENDOSCOPE.base_position[2]
    tip_to_tail = [np.array(point, dtype=np.float32) for point in centerline]
    tip_first_entities = list(reversed(visual_segments))
    segment_count = min(len(tip_first_entities), len(tip_to_tail) - 1)
    hidden_segment_indices = hidden_segment_indices or set()

    for idx in range(segment_count):
        segment = tip_first_entities[idx]
        if idx in hidden_segment_indices:
            segment.entity.set_pos((0.0, 0.0, -5.0))
            continue
        tip_side = tip_to_tail[idx]
        tail_side = tip_to_tail[idx + 1]
        a = tail_side
        b = tip_side
        midpoint = (a + b) * 0.5
        delta = b - a
        length = float(np.linalg.norm(delta))
        if length < 1e-6:
            continue
        heading = math.atan2(float(delta[1]), float(delta[0]))
        segment.entity.set_pos((float(midpoint[0]), float(midpoint[1]), z))
        segment.entity.set_quat(horizontal_cylinder_quat(heading))

    for segment in tip_first_entities[segment_count:]:
        segment.entity.set_pos((0.0, 0.0, -5.0))


def hidden_segments_inside_insertable(centerline: list[tuple[float, float]]) -> set[int]:
    hidden: set[int] = set()
    if len(centerline) < 2:
        return hidden
    tip_to_tail = [np.array(point, dtype=np.float32) for point in centerline]
    for idx, (tip_side, tail_side) in enumerate(zip(tip_to_tail[:-1], tip_to_tail[1:])):
        midpoint = (tip_side + tail_side) * 0.5
        for block in GUIDE_BLOCKS:
            if block.kind != "insertable":
                continue
            center = np.array(block.position, dtype=np.float32)
            radius = solid_block_radius(block)
            if float(np.linalg.norm(midpoint - center)) <= radius:
                hidden.add(idx)
                break
    return hidden


def heading_from_centerline(centerline: list[tuple[float, float]], fallback: float) -> float:
    if len(centerline) < 2:
        return fallback
    tip = np.array(centerline[0], dtype=np.float32)
    neck = np.array(centerline[1], dtype=np.float32)
    delta = tip - neck
    if float(np.linalg.norm(delta)) < 1e-6:
        return fallback
    return math.atan2(float(delta[1]), float(delta[0]))


def route_target_to_dict(target: RouteTarget) -> dict:
    return {
        "name": target.name,
        "kind": target.kind,
        "shape": target.shape,
        "block_position": [float(target.block_position[0]), float(target.block_position[1])],
        "target_position": [float(target.target_position[0]), float(target.target_position[1])],
        "reach_mode": target.reach_mode,
    }


def save_3d_render_frame(camera, image_path: Path) -> bool:
    if camera is None:
        return False
    try:
        rendered = None
        errors = []
        for render_call in (
            lambda: camera.render(rgb=True, force_render=True),
            lambda: camera.render(rgb=True),
            lambda: camera.render(),
        ):
            try:
                rendered = render_call()
                break
            except Exception as exc:
                errors.append(repr(exc))
        if rendered is None:
            raise RuntimeError("; ".join(errors) or "camera.render returned None")

        if isinstance(rendered, dict):
            image = None
            for key in ("rgb", "color", "image"):
                if key in rendered and rendered[key] is not None:
                    image = rendered[key]
                    break
        elif isinstance(rendered, tuple):
            image = rendered[0]
        else:
            image = rendered

        if image is None:
            raise RuntimeError(f"camera.render returned no RGB image, keys={list(rendered.keys()) if isinstance(rendered, dict) else type(rendered)}")

        image = tensor_to_numpy(image)
        if image.ndim == 4:
            image = image[0]
        if image.dtype != np.uint8:
            if float(np.nanmax(image)) <= 1.0:
                image = np.clip(image * 255.0, 0, 255)
            image = image.astype(np.uint8)

        from PIL import Image

        Image.fromarray(image[..., :3]).save(image_path)
        return True
    except Exception as exc:
        print(f"3D render frame skipped: {repr(exc)}")
        return False


def update_reached_targets(
    tip_xy: np.ndarray,
    route_targets: list[RouteTarget],
    reached: dict[str, int],
    step: int,
    radius: float,
) -> None:
    for target in route_targets:
        if target.name in reached:
            continue
        if target.kind == "target":
            target_xy = np.array(target.target_position, dtype=np.float32)
            threshold = radius
        else:
            target_xy = np.array(target.block_position, dtype=np.float32)
            block_radius = 0.0
            for block in GUIDE_BLOCKS:
                if block.name == target.name:
                    block_radius = solid_block_radius(block)
                    break
            threshold = block_radius + radius
        if float(np.linalg.norm(tip_xy - target_xy)) <= threshold:
            reached[target.name] = step


def current_route_target(route_targets: list[RouteTarget], reached: dict[str, int]) -> RouteTarget:
    for target in route_targets:
        if target.name not in reached:
            return target
    return route_targets[-1]


def run(args):
    output_dir = Path(args.output_dir)
    episode_dir = output_dir / f"episode_{args.episode_index:06d}" if args.record else output_dir
    render_frames_dir = episode_dir / "render_frames"
    debug_frames_dir = episode_dir / "debug_frames"
    episode_dir.mkdir(parents=True, exist_ok=True)
    if args.record:
        for directory in (render_frames_dir, debug_frames_dir):
            directory.mkdir(parents=True, exist_ok=True)
            for old_frame in directory.glob("*.png"):
                old_frame.unlink()
        for old_video in ("video_3d.mp4", "debug_route.mp4"):
            old_video_path = episode_dir / old_video
            if old_video_path.exists():
                old_video_path.unlink()

    scene, visual_segments, specs, camera = build_physical_scene(args, episode_dir)
    level_label = experiment_level_label()
    motion_segments, route_targets = make_motion_plan(
        args.solid_clearance,
        args.turn_side,
        args.turn_samples,
        args.steer_pause_steps,
        args.max_steer_angle_deg,
    )
    path_points = [point for segment in motion_segments for point in segment.points]
    reached_targets: dict[str, int] = {}

    samples = []
    annotations = []
    render_frame_paths = []
    debug_frame_paths = []
    previous_drive_xy = np.array(START_POSITION, dtype=np.float32)
    path_history: list[np.ndarray] = [np.array(START_POSITION, dtype=np.float32)]
    endoscope_radius = max(section.radius for section in ENDOSCOPE.sections)

    for step in range(args.max_steps):
        drive_xy, motion_target_name = motion_position_at(step, motion_segments, args.drive_speed, args.dt)
        drive_xy, head_contact = resolve_solid_block_overlap(drive_xy, endoscope_radius)
        append_path_history(path_history, drive_xy, args.history_spacing)

        delta = drive_xy - previous_drive_xy
        if float(np.linalg.norm(delta)) > 1e-6:
            yaw = math.atan2(float(delta[1]), float(delta[0]))
        else:
            yaw = 0.0

        centerline, proxy_contact = centerline_from_history(
            path_history,
            specs,
            endoscope_radius,
            args.visible_endoscope_length,
        )
        tip_xy = np.array(centerline[0], dtype=np.float32)
        yaw = heading_from_centerline(centerline, yaw)
        distance_to_target = float(np.linalg.norm(tip_xy - np.array(TARGET_POSITION, dtype=np.float32)))
        contact_norm = max(proxy_contact, head_contact)
        hidden_insertable_segments = hidden_segments_inside_insertable(centerline)
        insertable_occluded = bool(hidden_insertable_segments)
        update_visual_endoscope_segments(
            visual_segments,
            centerline,
            hidden_segment_indices=hidden_insertable_segments,
        )
        scene.step()
        update_reached_targets(tip_xy, route_targets, reached_targets, step, args.route_reach_radius)
        active_target = current_route_target(route_targets, reached_targets)

        samples.append(
            {
                "step": step,
                "level": level_label,
                "active_route_target": active_target.name,
                "motion_target": motion_target_name,
                "reached_route_targets": "|".join(reached_targets.keys()),
                "drive_x": float(drive_xy[0]),
                "drive_y": float(drive_xy[1]),
                "tip_x": float(tip_xy[0]),
                "tip_y": float(tip_xy[1]),
                "yaw": float(yaw),
                "distance_to_target": distance_to_target,
                "contact_force_norm": contact_norm,
                "insertable_occluded": int(insertable_occluded),
                "hidden_insertable_segments": "|".join(str(idx) for idx in sorted(hidden_insertable_segments)),
                "used_guide_blocks": "|".join(USED_GUIDE_BLOCK_NAMES),
            }
        )

        if args.record and step % args.frame_stride == 0:
            frame_idx = len(debug_frame_paths)
            debug_frame_path = debug_frames_dir / f"{frame_idx:06d}.png"
            draw_training_frame(
                debug_frame_path,
                tip_xy=tip_xy,
                heading=yaw,
                centerline=centerline,
                frame_idx=frame_idx,
                image_size=(args.frame_width, args.frame_height),
            )
            debug_frame_paths.append(debug_frame_path)
            render_frame_path = render_frames_dir / f"{frame_idx:06d}.png"
            if save_3d_render_frame(camera, render_frame_path):
                render_frame_paths.append(render_frame_path)
            annotation = build_frame_annotation(frame_idx, tip_xy, yaw, centerline)
            annotation["route"] = {
                "targets": [route_target_to_dict(target) for target in route_targets],
                "active_target": route_target_to_dict(active_target),
                "reached_target_names": list(reached_targets.keys()),
            }
            annotation["physics"] = {"contact_force_norm": contact_norm}
            annotation["visibility"] = {
                "insertable_occluded": insertable_occluded,
                "hidden_insertable_segments": sorted(hidden_insertable_segments),
            }
            annotations.append(annotation)

        previous_drive_xy = drive_xy
        if distance_to_target <= args.success_radius:
            break

    csv_path = episode_dir / "trajectory.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "step",
                "level",
                "active_route_target",
                "motion_target",
                "reached_route_targets",
                "drive_x",
                "drive_y",
                "tip_x",
                "tip_y",
                "yaw",
                "distance_to_target",
                "contact_force_norm",
                "insertable_occluded",
                "hidden_insertable_segments",
                "used_guide_blocks",
            ],
        )
        writer.writeheader()
        writer.writerows(samples)

    if args.record:
        metadata = {
            "mode": "visible_tip_guided_block_route_endoscope",
            "episode_index": args.episode_index,
            "level": level_label,
            "tail_model": "infinite_not_rendered",
            "visible_endoscope_length": args.visible_endoscope_length,
            "moving_end": "metal_lens_tip",
            "used_guide_blocks": list(USED_GUIDE_BLOCK_NAMES),
            "start_clamps": [
                {
                    "name": clamp.name,
                    "position": list(clamp.position),
                    "size": list(clamp.size),
                    "height": clamp.height,
                }
                for clamp in START_CLAMPS
            ],
            "target_position": list(TARGET_POSITION),
            "route_rule": "start -> each USED_GUIDE_BLOCK_NAMES block in order -> target",
            "route_targets": [route_target_to_dict(target) for target in route_targets],
            "path_points": [[float(x), float(y)] for x, y in path_points],
            "motion": {
                "turn_side": args.turn_side,
                "turn_samples": args.turn_samples,
                "steer_pause_steps": args.steer_pause_steps,
                "controlled_front_length": controlled_front_length(),
                "max_steer_angle_deg": args.max_steer_angle_deg,
                "minimum_turn_radius": minimum_turn_radius(args.max_steer_angle_deg),
            },
            "reached_route_targets": reached_targets,
            "success": bool(samples and samples[-1]["distance_to_target"] <= args.success_radius),
            "render_3d_available": bool(render_frame_paths),
            "render_frame_count": len(render_frame_paths),
            "debug_frame_count": len(debug_frame_paths),
            "frame_stride": args.frame_stride,
            "image_size": [args.frame_width, args.frame_height],
            "camera": {
                "view": "top_down_3d",
                "pos": [0.0, 0.0, args.camera_height],
                "lookat": [0.0, 0.0, 0.0],
                "fov": args.camera_fov,
            },
            "endoscope_segments": len(specs),
            "control": {
                "drive_speed": args.drive_speed,
                "steering_gain": args.steering_gain,
                "bend_frequency": args.bend_frequency,
                "bend_lag": args.bend_lag,
                "history_spacing": args.history_spacing,
            },
        }
        (episode_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        (episode_dir / "annotations.json").write_text(json.dumps(annotations, indent=2), encoding="utf-8")
        if args.video:
            if render_frame_paths:
                write_video(render_frame_paths, episode_dir / "video_3d.mp4", fps=args.video_fps)
            write_video(debug_frame_paths, episode_dir / "debug_route.mp4", fps=args.video_fps)

    print(f"Physical simulation level: {level_label}")
    print(f"Finished {len(samples)} steps.")
    print(f"Trajectory saved to: {csv_path}")
    if args.record:
        print(f"3D render frames saved to: {render_frames_dir}")
        print(f"Debug frames saved to: {debug_frames_dir}")
        print(f"Annotations saved to: {episode_dir / 'annotations.json'}")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--viewer", action="store_true")
    parser.add_argument("--backend", choices=("gpu", "cpu"), default="gpu")
    parser.add_argument("--output-dir", default="/outputs/endoscope_genesis_physical")
    parser.add_argument("--dt", type=float, default=0.01)
    parser.add_argument("--substeps", type=int, default=8)
    parser.add_argument("--max-steps", type=int, default=2500)
    parser.add_argument("--success-radius", type=float, default=0.10)
    parser.add_argument("--drive-speed", type=float, default=0.12)
    parser.add_argument("--steering-gain", type=float, default=0.0)
    parser.add_argument("--bend-frequency", type=float, default=4.2)
    parser.add_argument("--bend-lag", type=float, default=0.32)
    parser.add_argument("--endoscope-friction", type=float, default=1.2)
    parser.add_argument("--solid-clearance", type=float, default=0.10)
    parser.add_argument("--history-spacing", type=float, default=0.012)
    parser.add_argument("--visible-endoscope-length", type=float, default=0.95)
    parser.add_argument("--route-reach-radius", type=float, default=0.075)
    parser.add_argument("--turn-side", choices=("left", "right"), default="left")
    parser.add_argument("--turn-samples", type=int, default=18)
    parser.add_argument("--steer-pause-steps", type=int, default=55)
    parser.add_argument("--max-steer-angle-deg", type=float, default=18.0)
    parser.add_argument("--record-3d", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--video", action="store_true")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--frame-stride", type=int, default=10)
    parser.add_argument("--frame-width", type=int, default=1280)
    parser.add_argument("--frame-height", type=int, default=848)
    parser.add_argument("--camera-height", type=float, default=3.0)
    parser.add_argument("--camera-fov", type=float, default=46.0)
    parser.add_argument("--video-fps", type=int, default=24)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
