import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


def safe_name(name: str) -> str:
    cleaned = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in name.strip())
    return cleaned or "setup"


def load_setups(setups_path: Path | None, layouts_dir: Path | None) -> list[dict]:
    setups: list[dict] = []

    if setups_path:
        data = json.loads(setups_path.read_text(encoding="utf-8"))
        raw_setups = data.get("setups", data) if isinstance(data, dict) else data
        if not isinstance(raw_setups, list):
            raise ValueError("batch setup file must contain a list or a {'setups': [...]} object")
        for idx, item in enumerate(raw_setups, start=1):
            if not isinstance(item, dict):
                raise ValueError(f"setup #{idx} must be an object")
            layout = item.get("layout", item)
            name = item.get("name") or layout.get("name") or f"setup_{idx:03d}"
            setups.append({"name": safe_name(str(name)), "layout": layout})

    if layouts_dir:
        for path in sorted(layouts_dir.glob("*.json")):
            layout = json.loads(path.read_text(encoding="utf-8"))
            setups.append({"name": safe_name(path.stem), "layout": layout})

    if not setups:
        raise ValueError("no setups found; pass --setups batch_setups.json or --layouts-dir layouts")

    return setups


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--setups", type=Path, help="JSON file containing multiple setups")
    parser.add_argument("--layouts-dir", type=Path, help="Directory containing one layout JSON per setup")
    parser.add_argument("--output-dir", type=Path, default=Path("/outputs/endoscope_batch"))
    parser.add_argument("--backend", choices=("gpu", "cpu"), default="gpu")
    parser.add_argument("--start-index", type=int, default=0)
    parser.add_argument("--record", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--video", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--stop-on-error", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--python", default=sys.executable)
    args, passthrough = parser.parse_known_args()

    script_dir = Path(__file__).resolve().parent
    setups = load_setups(args.setups, args.layouts_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    layout_dir = args.output_dir / "_batch_layouts"
    layout_dir.mkdir(parents=True, exist_ok=True)

    summary = {
        "output_dir": str(args.output_dir),
        "setup_count": len(setups),
        "results": [],
    }

    for offset, setup in enumerate(setups):
        episode_index = args.start_index + offset
        setup_name = setup["name"]
        setup_output_dir = args.output_dir / setup_name
        setup_output_dir.mkdir(parents=True, exist_ok=True)

        layout_path = layout_dir / f"{episode_index:06d}_{setup_name}.json"
        layout_path.write_text(json.dumps(setup["layout"], indent=2), encoding="utf-8")

        cmd = [
            args.python,
            str(script_dir / "physical_main.py"),
            "--backend",
            args.backend,
            "--output-dir",
            str(setup_output_dir),
            "--episode-index",
            "0",
        ]
        if args.record:
            cmd.append("--record")
        else:
            cmd.append("--no-record")
        if args.video:
            cmd.append("--video")
        cmd.extend(passthrough)

        env = os.environ.copy()
        env["ENDOSCOPE_LAYOUT_PATH"] = str(layout_path)

        print(f"\n=== Running setup {offset + 1}/{len(setups)}: {setup_name} ===", flush=True)
        result = subprocess.run(cmd, cwd=script_dir, env=env)

        episode_dir = setup_output_dir / "episode_000000" if args.record else setup_output_dir
        item = {
            "name": setup_name,
            "returncode": result.returncode,
            "layout_path": str(layout_path),
            "output_dir": str(episode_dir),
            "annotations": str(episode_dir / "annotations.json"),
            "metadata": str(episode_dir / "metadata.json"),
            "ev_frames": str(episode_dir / "frames" / "ev"),
            "ebv_frames": str(episode_dir / "frames" / "ebv"),
        }
        summary["results"].append(item)
        (args.output_dir / "batch_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

        if result.returncode != 0 and args.stop_on_error:
            print(f"Stopped because setup failed: {setup_name}", flush=True)
            return result.returncode

    print(f"\nBatch summary saved to: {args.output_dir / 'batch_summary.json'}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
