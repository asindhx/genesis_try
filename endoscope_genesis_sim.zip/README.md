# Genesis endoscope guide-block simulation

这个项目用于在 Genesis 里模拟一个内窥镜实验装置：

- 平面实验台
- 圆形/方形指引块
- 五边形 target
- 实心块不可穿过
- 可插入块允许穿过
- 其他块可以作为干扰项摆在场景里
- level 只由本次路径真正使用到的指引块决定

## 重要入口

请优先运行：

```bash
python physical_main.py --backend gpu --record --video
```

`physical_main.py` 是物理版本：内窥镜是多段刚体关节链，solid blocks 开启碰撞，insertable blocks 不开启碰撞，并输出接触力数据。

`main.py` 只是早期的快速标注/示意图生成版本，不适合作为碰撞仿真结果使用。

## Level 规则

在 `config.py` 里：

- `GUIDE_BLOCKS` 是场景里摆放的所有块，包括干扰项。
- `USED_GUIDE_BLOCK_NAMES` 是本次实验路径真正用到的块。
- 只有 `USED_GUIDE_BLOCK_NAMES` 里的块会计入 level。

计分：

```text
solid       +1
insertable +1.5
```

例子：

```text
1 个 solid = L1
1 个 insertable = L1.5
1 个 solid + 1 个 insertable = L2.5
```

## 内窥镜结构

内窥镜在 `ENDOSCOPE.sections` 里配置，目前为：

```text
镜头金属硬质段
前端橡胶软段
中间金属硬质段
后端橡胶软管
```

物理版会把这些 section 展开成多段圆柱刚体：

- 金属段：质量更大、关节刚度更高、弯曲角更小。
- 橡胶段：质量更小、关节刚度更低、弯曲角更大。

## Docker 运行

在装了 Docker 的 5060 机器上，进入项目目录后构建镜像：

```bash
docker build -t endoscope-genesis:cuda12.8-sm120 .
```

无窗口生成物理仿真数据：

```bash
mkdir -p /tmp/endoscope_outputs && docker run --rm --gpus all -e PYOPENGL_PLATFORM=osmesa -e NVIDIA_DRIVER_CAPABILITIES=all -v /tmp/endoscope_outputs:/outputs endoscope-genesis:cuda12.8-sm120 python physical_main.py --backend gpu --record --video --output-dir /outputs/endoscope_genesis_physical
```

输出位置：

```text
/tmp/endoscope_outputs/endoscope_genesis_physical/episode_000000/
  render_frames/
  debug_frames/
  video_3d.mp4
  debug_route.mp4
  trajectory.csv
  annotations.json
  metadata.json
  physical_endoscope.urdf
```

其中：

- `render_frames/` 是 Genesis 3D camera 渲染帧，用作主视频数据。
- `video_3d.mp4` 是 Genesis 3D 渲染视频。
- `debug_frames/` 是俯视路线调试图，不是最终仿真画面。
- `debug_route.mp4` 是路线调试视频。
- `trajectory.csv` 每一步包含 tip 坐标、目标距离、当前路线目标、已到达路线节点、接触力 `contact_force_norm`。
- `annotations.json` 每帧包含 block、target、内窥镜 centerline/tip、路线目标标注。
- `metadata.json` 包含 level、使用到的指引块、路线目标 `route_targets` 和路径点 `path_points`。
- `physical_endoscope.urdf` 是本次运行生成的内窥镜物理模型。

## 修改实验

主要改 `config.py`：

- `GUIDE_BLOCKS`：增加、删除、移动指引块或干扰块。
- `USED_GUIDE_BLOCK_NAMES`：决定本次路径实际用到哪些块，也决定 level。
- `TARGET_POSITION`：修改 target 位置。
- `ENDOSCOPE.sections`：修改金属段/橡胶段长度、半径、分段数。

## RTX 50 系列说明

Dockerfile 已经针对 RTX 5060/50 系列处理了 `sm_120`：

- CUDA 12.8
- LLVM 22
- 从源码安装 Genesis/Quadrants
- 在安装 Quadrants 前生成 `graph_do_while_cond_fatbin.h`
- fatbin 目标为 `compute_120/sm_120`

如果仍然看到：

```text
SM (120) may not be included in the fatbin
```

说明当前运行的不是这个新镜像，或者镜像没有重新 build。
