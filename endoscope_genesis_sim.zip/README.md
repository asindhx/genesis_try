# Genesis 内窥镜指引块仿真

这是一个用于 Genesis 的实验装置仿真原型：

- 平面实验台
- 圆形/方形指引块
- 五边形 target
- 可配置干扰项
- 根据实际使用的指引块自动计算 level
- 分段式内窥镜结构
- 实心块与内窥镜碰撞，可插入块允许通过

## 核心规则

场景中可以放很多指引块，但并不是所有指引块都会计入 level。

在 `config.py` 中：

- `GUIDE_BLOCKS` 表示场景里所有摆放的指引块，包括干扰项。
- `USED_GUIDE_BLOCK_NAMES` 表示本次实验路径真正用到的指引块。
- 只有 `USED_GUIDE_BLOCK_NAMES` 中列出的块会计入 level。

level 规则：

```text
solid       实心不可穿过指引块：+1
insertable 允许插入/穿过指引块：+1.5
```

例子：

```text
1 个 solid = L1
1 个 insertable = L1.5
1 个 solid + 1 个 insertable = L2.5
2 个 solid + 1 个 insertable = L3.5
```

## 内窥镜结构

内窥镜在 `ENDOSCOPE.sections` 中配置，当前分为：

```text
镜头金属硬质段
前端橡胶软段
中间金属硬质段
后端橡胶软管
```

当前模型采用“多段圆柱 + 弯曲顺应性”的工程近似：

- 金属段：更硬，弯曲顺应性小。
- 橡胶段：更软，用更多短节近似弯曲。

## 运行

```powershell
cd C:\Users\asindhx\Documents\Codex\2026-06-01\5060-genesis-genesis\work\endoscope_genesis_sim
python main.py --viewer
```

无窗口运行并导出轨迹数据：

```powershell
python main.py
```

如果 50 系显卡出现：

```text
SM (120) may not be included in the fatbin
```

这不是本项目场景代码的问题，而是当前 Genesis/Quadrants 的 CUDA fatbin 没有包含 RTX 50 系显卡需要的 `sm_120` 内核。

长期运行建议修复 Genesis GPU 环境，而不是长期使用 CPU。先运行检查脚本：

```bash
conda activate genesis
cd /home/wu/Documents/genesis_projectxizi/genesis_try/endoscope_genesis_sim
python scripts/check_genesis_gpu.py
```

检查脚本会输出：

- 当前 Python 环境
- Genesis 安装路径
- CUDA/nvcc 版本
- PyTorch CUDA capability
- `build_condition_kernel_fatbin.py` 的实际路径

如果找到了 `build_condition_kernel_fatbin.py`，按输出提示运行，例如：

```bash
python /home/wu/miniconda3/envs/genesis/lib/python3.10/site-packages/genesis/scripts/build_condition_kernel_fatbin.py
```

实际路径以检查脚本输出为准。

如果找不到这个脚本，说明当前 wheel 包里没有带重建脚本。长期方案是从源码安装/升级 Quadrants 和 Genesis，并确保编译目标包含 `sm_120`。可以参考：

```bash
bash scripts/setup_sm120_notes.sh
```

注意：这个脚本只是打印操作步骤，避免直接改坏环境。按它输出的命令逐步执行。

RTX 50 系建议使用 CUDA Toolkit 12.8 或更新版本，并确保重建时包含 `sm_120`。

CPU 后端只建议用于排查项目逻辑：

```powershell
python main.py --backend cpu
```

输出文件：

```text
C:\Users\asindhx\Documents\Codex\2026-06-01\5060-genesis-genesis\outputs\endoscope_genesis_sim\trajectory.csv
```

## 修改实验

主要修改 `config.py`：

- `GUIDE_BLOCKS`：添加/删除/移动指引块或干扰项。
- `USED_GUIDE_BLOCK_NAMES`：决定本次路径用到哪些指引块，从而决定 level。
- `TARGET_POSITION`：修改 target 位置。
- `ENDOSCOPE.sections`：修改内窥镜金属段/橡胶段长度、半径、分段数和柔软程度。

## 注意

这是第一版工程仿真代码。它已经表达了实验规则和内窥镜分段结构，但还不是高精度连续体软体模型。后续可以继续升级为：

- 关节弹簧链模型
- cable-driven 弯曲控制
- 视觉识别指引块颜色/形状
- 强化学习导航策略
