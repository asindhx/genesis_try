import argparse
import csv
import importlib
import json
import math
import os
import shutil
import sys
import types
from pathlib import Path


sys.modules["genesis"] = types.SimpleNamespace(cpu="cpu", gpu="gpu")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from PIL import Image

import physical_main as pm
from main import build_frame_annotation, guide_block_size_xy, make_slotted_box_obj


OUT = ROOT / "outputs" / "selfcheck_no_genesis"


def reset_output() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)


def route_summary(label: str) -> dict:
    radius = max(section.radius for section in pm.ENDOSCOPE.sections)
    nodes, targets = pm.make_forward_route_nodes(0.10)
    path, report = pm.build_validated_path(nodes, targets, radius, 0.22, 8)
    length = pm.polyline_length(path)
    if not report.get("ok"):
        raise AssertionError(f"{label}: route preflight failed: {report.get('issues')}")
    if length < 0.45:
        raise AssertionError(f"{label}: route too short: {length:.3f}")
    if not targets or targets[-1].kind != "target":
        raise AssertionError(f"{label}: final route target is not active target")

    positions = [
        pm.polyline_position_at_distance(path, length * idx / 39, targets)[0]
        for idx in range(40)
    ]
    sampled_length = sum(
        float(pm.np.linalg.norm(b - a))
        for a, b in zip(positions[:-1], positions[1:])
    )
    if sampled_length < length * 0.85:
        raise AssertionError(f"{label}: sampled motion too short: {sampled_length:.3f} < {length:.3f}")

    final = pm.np.array(path[-1], dtype=pm.np.float32)
    target = pm.np.array(pm.active_target().position, dtype=pm.np.float32)
    if float(pm.np.linalg.norm(final - target)) > 1e-5:
        raise AssertionError(f"{label}: route does not end at active target")

    level_value, level_label, contributions = pm.navigation_level_from_path(targets, path, 8)
    if label == "default_layout" and abs(level_value - 2.5) > 1e-6:
        raise AssertionError(f"{label}: expected L2.5, got {level_label}: {contributions}")

    return {
        "label": label,
        "used_guide_blocks": list(pm.USED_GUIDE_BLOCK_NAMES),
        "route_targets": [target.name for target in targets],
        "level": level_label,
        "level_contributions": contributions,
        "path_points": len(path),
        "route_length": round(length, 3),
        "warnings": report.get("warnings", []),
    }


def check_default_counterfactual_first_block_changes_path() -> dict:
    radius = max(section.radius for section in pm.ENDOSCOPE.sections)
    nodes, targets = pm.make_forward_route_nodes(0.10)
    path, report = pm.build_validated_path(nodes, targets, radius, 0.22, 8)
    if not report.get("ok"):
        raise AssertionError(f"counterfactual: default route failed before comparison: {report.get('issues')}")

    level_value, level_label, contributions = pm.navigation_level_from_path(targets, path, 8)
    if abs(level_value - 2.5) > 1e-6:
        raise AssertionError(f"counterfactual: default route is not L2.5: {level_label}, {contributions}")

    start = pm.np.array(pm.START_POSITION, dtype=pm.np.float32)
    active = pm.np.array(pm.active_target().position, dtype=pm.np.float32)
    direct_samples = pm.sample_polyline_points(
        [(float(start[0]), float(start[1])), (float(active[0]), float(active[1]))],
        spacing=0.012,
    )
    blocked_by = []
    for point in direct_samples:
        for block in pm.GUIDE_BLOCKS:
            if block.kind != "insertable":
                continue
            center = pm.np.array(block.position, dtype=pm.np.float32)
            rel = point - center
            size_x, size_y = pm.guide_block_size_xy(block)
            inflated_x = size_x * 0.5 + radius + 0.10 * 0.20
            inflated_y = size_y * 0.5 + radius + 0.10 * 0.20
            if abs(float(rel[0])) > inflated_x or abs(float(rel[1])) > inflated_y:
                continue
            through_axis, side_axis, half_through, _ = pm.insertable_channel_axes(block)
            through_coord = abs(float(pm.np.dot(rel, through_axis)))
            side_coord = abs(float(pm.np.dot(rel, side_axis)))
            channel_half_width = radius + 0.025
            if side_coord > channel_half_width and through_coord <= half_through + radius + 0.10:
                blocked_by.append(
                    {
                        "block": block.name,
                        "sample": [round(float(point[0]), 4), round(float(point[1]), 4)],
                        "side_offset_from_slot": round(side_coord, 4),
                        "slot_half_width": round(channel_half_width, 4),
                    }
                )
                break
        if blocked_by:
            break
    if not blocked_by:
        raise AssertionError(
            "counterfactual: direct no-guide route can still pass the insertion block; "
            "the first solid guide is not necessary enough"
        )

    return {
        "first_guide_block": pm.USED_GUIDE_BLOCK_NAMES[0],
        "level": level_label,
        "physical_effect": (
            "with the first solid guide, the route reaches the insertion long-side slot and active target; "
            "without that guide, the natural straight-to-target path hits the solid part of the insertion block"
        ),
        "no_guide_direct_path_blocked_by": blocked_by[0],
        "with_block_path_length": round(pm.polyline_length(path), 4),
    }


def check_all_layout_routes(include_batch: bool = False) -> list[dict]:
    results = []
    os.environ.pop("ENDOSCOPE_LAYOUT_PATH", None)
    import config

    importlib.reload(config)
    importlib.reload(pm)
    results.append(route_summary("default_layout"))

    batch_path = ROOT / "batch_setups_L4_L4_5.json"
    if include_batch and batch_path.exists():
        data = json.loads(batch_path.read_text(encoding="utf-8"))
        raw_setups = data.get("setups", data if isinstance(data, list) else [])
        layout_dir = OUT / "layouts"
        layout_dir.mkdir(parents=True, exist_ok=True)
        for idx, item in enumerate(raw_setups):
            layout = item.get("layout", item)
            name = item.get("name") or layout.get("name") or f"setup_{idx:03d}"
            layout_path = layout_dir / f"{idx:03d}_{name}.json"
            layout_path.write_text(json.dumps(layout, indent=2), encoding="utf-8")
            os.environ["ENDOSCOPE_LAYOUT_PATH"] = str(layout_path)
            importlib.reload(config)
            importlib.reload(pm)
            results.append(route_summary(f"batch_{idx}_{name}"))

    os.environ.pop("ENDOSCOPE_LAYOUT_PATH", None)
    importlib.reload(config)
    importlib.reload(pm)
    return results


def check_export_labels() -> dict:
    out = OUT / "export"
    out.mkdir(parents=True, exist_ok=True)
    render_paths = []
    tip_paths = []
    annotations = []
    samples = []
    for idx in range(3):
        ebv = out / f"ebv_{idx}.png"
        ev = out / f"ev_{idx}.png"
        Image.new("RGB", (1280, 848), (30 + idx * 20, 80, 120)).save(ebv)
        Image.new("RGB", (1280, 848), (120, 60 + idx * 20, 30)).save(ev)
        render_paths.append(ebv)
        tip_paths.append(ev)
        tip = pm.np.array([-1.36 + idx * 0.1, 0.0], dtype=pm.np.float32)
        annotations.append(build_frame_annotation(idx, tip, 0.0, [(float(tip[0]), 0.0), (-1.5, 0.0)], image_size=(1280, 848)))
        samples.append({"step": idx * 10, "tip_x": float(tip[0]), "tip_y": 0.0, "drive_x": float(tip[0]), "drive_y": 0.0, "active_route_target": "guide"})

    _, route_targets = pm.make_forward_route_nodes(0.10)
    pm.export_vlca_live_episode(out, annotations, samples, render_paths, tip_paths, route_targets, "L2.5", 2.5)
    vlca = json.loads((out / "json" / "vlca.json").read_text(encoding="utf-8"))
    labels = vlca["labels"]["0001.jpg"]
    blocks = [item for item in labels if item.get("displayName") == "block"]
    targets = [item for item in labels if item.get("displayName") == "target"]
    tips = [item for item in labels if item.get("displayName") == "robot tip"]
    if len(tips) != 1:
        raise AssertionError("export: expected one robot tip label")
    if len(targets) != 1:
        raise AssertionError("export: expected one active target label")
    has_inactive_targets = any(target.name != pm.ACTIVE_TARGET_NAME for target in pm.TARGETS)
    if has_inactive_targets and not any(item.get("kind") == "inactive_target_as_block" for item in blocks):
        raise AssertionError("export: inactive target was not labeled as block")
    if not (out / "frames" / "ev" / "0001.jpg").exists():
        raise AssertionError("export: EV frame missing")
    if not (out / "frames" / "ebv" / "0001.jpg").exists():
        raise AssertionError("export: EBV frame missing")
    return {"labels": len(labels), "blocks": len(blocks), "targets": len(targets), "tips": len(tips)}


def check_render_fallback() -> dict:
    class BadCamera:
        def render(self, *args, **kwargs):
            raise AssertionError()

    out = OUT / "render_fallback"
    out.mkdir(parents=True, exist_ok=True)
    debug = out / "debug.png"
    render = out / "render.png"
    Image.new("RGB", (64, 48), (10, 20, 30)).save(debug)
    native_ok = pm.save_3d_render_frame(BadCamera(), render)
    fallback_ok = pm.copy_debug_render_fallback(debug, render)
    if native_ok or not fallback_ok or not render.exists():
        raise AssertionError("render fallback failed")
    return {"native_ok": native_ok, "fallback_ok": fallback_ok, "render_exists": render.exists()}


def check_slotted_insertable_mesh() -> dict:
    block = next(block for block in pm.GUIDE_BLOCKS if block.kind == "insertable")
    size_x, size_y = guide_block_size_xy(block)
    channel_half_width = max(pm.ENDOSCOPE.sections[0].radius * 0.95, min(size_x, size_y) * 0.12)
    mesh_path = OUT / "mesh" / f"{block.name}_slotted_box.obj"
    mesh_path.parent.mkdir(parents=True, exist_ok=True)
    make_slotted_box_obj(mesh_path, size_x, size_y, channel_half_width, block.height)

    vertices = []
    faces = 0
    for line in mesh_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("v "):
            _, x, y, z = line.split()
            vertices.append((float(x), float(y), float(z)))
        elif line.startswith("f "):
            faces += 1
    if len(vertices) != 24 or faces != 18:
        raise AssertionError(f"mesh: expected side walls plus top cover, got vertices={len(vertices)} faces={faces}")
    if size_x >= size_y:
        low_vertices = [(x, y, z) for x, y, z in vertices if z < -block.height * 0.20]
        if any(abs(x) < channel_half_width * 0.99 for x, _, _ in low_vertices):
            raise AssertionError("mesh: long-side opening is not clear at low/mid height")
    else:
        low_vertices = [(x, y, z) for x, y, z in vertices if z < -block.height * 0.20]
        if any(abs(y) < channel_half_width * 0.99 for _, y, _ in low_vertices):
            raise AssertionError("mesh: long-side opening is not clear at low/mid height")
    return {"mesh": str(mesh_path.relative_to(ROOT)), "vertices": len(vertices), "faces": faces}


def default_physical_args(output_dir: Path):
    saved_argv = sys.argv[:]
    try:
        sys.argv = [saved_argv[0]]
        args = pm.parse_args()
    finally:
        sys.argv = saved_argv
    args.record = False
    args.video = False
    args.viewer = False
    args.output_dir = str(output_dir)
    args.backend = "cpu"
    args.fail_on_quality_issue = True
    return args


def check_full_fem_dry_run() -> dict:
    out = OUT / "full_fem"
    args = default_physical_args(out)
    pm.run(args)
    metadata = json.loads((out / "metadata.json").read_text(encoding="utf-8"))
    rows = list(csv.DictReader((out / "trajectory.csv").open(newline="", encoding="utf-8")))
    control_rows = list(csv.DictReader((out / "control_commands.csv").open(newline="", encoding="utf-8")))
    if metadata.get("code_version") != pm.SIM_CODE_VERSION:
        raise AssertionError(f"full_fem: wrong code version: {metadata.get('code_version')}")
    if metadata.get("motion", {}).get("physics_model") != "finite_element_rod":
        raise AssertionError(f"full_fem: wrong physics model: {metadata.get('motion', {}).get('physics_model')}")
    if not metadata.get("success"):
        raise AssertionError("full_fem: run did not reach target")
    if not metadata.get("route_finished"):
        raise AssertionError("full_fem: route was not completed before success")
    if not metadata.get("quality", {}).get("passed"):
        raise AssertionError(f"full_fem: quality failed: {metadata.get('quality', {}).get('issues')}")
    if not rows:
        raise AssertionError("full_fem: trajectory is empty")
    if len(control_rows) != len(rows):
        raise AssertionError(f"full_fem: control csv row mismatch: {len(control_rows)} != {len(rows)}")
    for key in ("forward_velocity_mps", "linear_velocity_mps", "angular_velocity_radps", "cumulative_insertion_m"):
        if key not in control_rows[0]:
            raise AssertionError(f"full_fem: missing control csv field {key}")

    def f(row, key):
        return float(row[key])

    tip_path = sum(
        math.hypot(f(b, "tip_x") - f(a, "tip_x"), f(b, "tip_y") - f(a, "tip_y"))
        for a, b in zip(rows[:-1], rows[1:])
    )
    drive_path = sum(
        math.hypot(f(b, "drive_x") - f(a, "drive_x"), f(b, "drive_y") - f(a, "drive_y"))
        for a, b in zip(rows[:-1], rows[1:])
    )
    max_step = max(
        [math.hypot(f(b, "tip_x") - f(a, "tip_x"), f(b, "tip_y") - f(a, "tip_y")) for a, b in zip(rows[:-1], rows[1:])]
        or [0.0]
    )
    max_strain = max(float(row["max_segment_strain"]) for row in rows)
    max_centerline_penetration = max(float(row.get("centerline_solid_penetration", 0.0)) for row in rows)
    clipped_steps = sum(int(row.get("drive_motion_clipped", 0)) for row in rows)
    max_control_linear_velocity = max(float(row["linear_velocity_mps"]) for row in control_rows)
    max_control_angular_velocity = max(abs(float(row["angular_velocity_radps"])) for row in control_rows)
    final_cumulative_insertion = float(control_rows[-1]["cumulative_insertion_m"])
    reached = rows[-1]["reached_route_targets"]
    if not reached.endswith(pm.ACTIVE_TARGET_NAME):
        raise AssertionError(f"full_fem: final target not reached in order: {reached}")
    if float(rows[-1]["distance_to_target"]) > float(metadata["target_finish_radius"]):
        raise AssertionError("full_fem: final tip did not reach target_finish_radius")
    if tip_path < 2.0 or drive_path < 2.0:
        raise AssertionError(f"full_fem: path too short: tip={tip_path:.3f}, drive={drive_path:.3f}")
    if max_step > 0.02:
        raise AssertionError(f"full_fem: tip jumps too far: {max_step:.4f}")
    if max_strain > 0.12:
        raise AssertionError(f"full_fem: rod strain too high: {max_strain:.3f}")
    if max_centerline_penetration > 0.003:
        raise AssertionError(f"full_fem: centerline intersects solid block: {max_centerline_penetration:.4f}")
    return {
        "code_version": metadata.get("code_version"),
        "steps": len(rows),
        "success": metadata["success"],
        "quality_passed": metadata["quality"]["passed"],
        "final_distance": float(rows[-1]["distance_to_target"]),
        "reached": reached,
        "tip_path": round(tip_path, 3),
        "drive_path": round(drive_path, 3),
        "max_tip_step": round(max_step, 5),
        "max_segment_strain": round(max_strain, 4),
        "max_centerline_solid_penetration": round(max_centerline_penetration, 5),
        "drive_motion_clipped_steps": clipped_steps,
        "control_csv_rows": len(control_rows),
        "max_control_linear_velocity_mps": round(max_control_linear_velocity, 4),
        "max_control_angular_velocity_radps": round(max_control_angular_velocity, 4),
        "final_cumulative_insertion_m": round(final_cumulative_insertion, 3),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--full-fem", action="store_true", help="also run the slow no-render FEM rod dry-run")
    parser.add_argument("--full-pbd", action="store_true", help="deprecated alias for --full-fem")
    parser.add_argument("--include-batch-layouts", action="store_true", help="also check optional batch layouts")
    args = parser.parse_args()

    reset_output()
    report = {
        "routes": check_all_layout_routes(include_batch=args.include_batch_layouts),
        "counterfactual_first_block_changes_path": check_default_counterfactual_first_block_changes_path(),
        "export": check_export_labels(),
        "render_fallback": check_render_fallback(),
        "slotted_insertable_mesh": check_slotted_insertable_mesh(),
    }
    if args.full_fem or args.full_pbd:
        report["full_fem"] = check_full_fem_dry_run()
    (OUT / "selfcheck_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print("SELF_CHECK_NO_GENESIS_PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
