from dataclasses import dataclass
from typing import Literal


ShapeName = Literal["circle", "square", "pentagon"]
GuideKind = Literal["solid", "insertable"]
EndoscopeMaterial = Literal["metal", "rubber"]


@dataclass(frozen=True)
class GuideBlock:
    name: str
    kind: GuideKind
    shape: ShapeName
    position: tuple[float, float]
    size: float
    height: float
    color: tuple[float, float, float, float]


@dataclass(frozen=True)
class ClampBlock:
    name: str
    position: tuple[float, float]
    size: tuple[float, float]
    height: float
    color: tuple[float, float, float, float]


@dataclass(frozen=True)
class Target:
    name: str
    shape: ShapeName
    position: tuple[float, float]
    size: float
    height: float
    color: tuple[float, float, float, float]
    active: bool = False


@dataclass(frozen=True)
class EndoscopeSection:
    name: str
    material: EndoscopeMaterial
    length: float
    radius: float
    segment_count: int
    color: tuple[float, float, float, float]
    bend_compliance: float


@dataclass(frozen=True)
class EndoscopeConfig:
    base_position: tuple[float, float, float] = (-1.54, 0.0, 0.08)
    sections: tuple[EndoscopeSection, ...] = (
        EndoscopeSection(
            name="lens_metal_tip",
            material="metal",
            length=0.09,
            radius=0.036,
            segment_count=1,
            color=(0.72, 0.75, 0.78, 1.0),
            bend_compliance=0.05,
        ),
        EndoscopeSection(
            name="front_rubber_bend",
            material="rubber",
            length=0.16,
            radius=0.034,
            segment_count=4,
            color=(0.04, 0.05, 0.055, 1.0),
            bend_compliance=1.0,
        ),
        EndoscopeSection(
            name="middle_metal_sleeve",
            material="metal",
            length=0.10,
            radius=0.035,
            segment_count=1,
            color=(0.58, 0.61, 0.64, 1.0),
            bend_compliance=0.08,
        ),
        EndoscopeSection(
            name="rear_rubber_tube",
            material="rubber",
            length=6.0,
            radius=0.033,
            segment_count=60,
            color=(0.02, 0.025, 0.03, 1.0),
            bend_compliance=0.06,
        ),
    )


PLANE_SIZE = (3.2, 2.1)
TARGET_POSITION = (1.25, 0.55)
TARGET_SIZE = 0.18
TARGET_HEIGHT = 0.055
ACTIVE_TARGET_NAME = "target_main"
TARGETS: tuple[Target, ...] = (
    Target(
        name="target_main",
        shape="pentagon",
        position=TARGET_POSITION,
        size=TARGET_SIZE,
        height=TARGET_HEIGHT,
        color=(0.72, 0.10, 0.82, 1.0),
        active=True,
    ),
    Target(
        name="target_alt",
        shape="pentagon",
        position=(1.18, -0.56),
        size=0.16,
        height=TARGET_HEIGHT,
        color=(0.55, 0.20, 0.78, 1.0),
        active=False,
    ),
)


GUIDE_BLOCKS: tuple[GuideBlock, ...] = (
    GuideBlock(
        name="guide_blue_circle_1",
        kind="solid",
        shape="circle",
        position=(-0.60, 0.32),
        size=0.13,
        height=0.075,
        color=(0.08, 0.35, 0.95, 1.0),
    ),
    GuideBlock(
        name="guide_green_square_1",
        kind="solid",
        shape="square",
        position=(-0.18, -0.42),
        size=0.18,
        height=0.09,
        color=(0.05, 0.62, 0.28, 1.0),
    ),
    GuideBlock(
        name="guide_yellow_circle_insertable",
        kind="insertable",
        shape="circle",
        position=(0.34, -0.26),
        size=0.105,
        height=0.07,
        color=(0.95, 0.74, 0.10, 1.0),
    ),
    GuideBlock(
        name="guide_red_square_2",
        kind="solid",
        shape="square",
        position=(0.70, 0.34),
        size=0.15,
        height=0.085,
        color=(0.84, 0.14, 0.12, 1.0),
    ),
    GuideBlock(
        name="guide_cyan_circle_3",
        kind="solid",
        shape="circle",
        position=(0.98, -0.48),
        size=0.10,
        height=0.065,
        color=(0.06, 0.72, 0.78, 1.0),
    ),
)


ENDOSCOPE = EndoscopeConfig()


START_POSITION = (-1.36, 0.0)


START_CLAMPS: tuple[ClampBlock, ...] = (
    ClampBlock(
        name="start_clamp_upper",
        position=(-1.48, 0.085),
        size=(0.18, 0.055),
        height=0.075,
        color=(0.18, 0.18, 0.20, 1.0),
    ),
    ClampBlock(
        name="start_clamp_lower",
        position=(-1.48, -0.085),
        size=(0.18, 0.055),
        height=0.075,
        color=(0.18, 0.18, 0.20, 1.0),
    ),
)


# Only these guide blocks are counted as the intended path. Other blocks in
# GUIDE_BLOCKS are distractors and do not affect the level.
USED_GUIDE_BLOCK_NAMES: tuple[str, ...] = (
    "guide_blue_circle_1",
    "guide_yellow_circle_insertable",
)

def guide_block_by_name(name: str) -> GuideBlock:
    for block in GUIDE_BLOCKS:
        if block.name == name:
            return block
    raise ValueError(f"Unknown guide block name: {name}")


def used_guide_blocks() -> tuple[GuideBlock, ...]:
    return tuple(guide_block_by_name(name) for name in USED_GUIDE_BLOCK_NAMES)


def target_by_name(name: str) -> Target:
    for target in TARGETS:
        if target.name == name:
            return target
    raise ValueError(f"Unknown target name: {name}")


def active_target() -> Target:
    return target_by_name(ACTIVE_TARGET_NAME)


def experiment_level_value() -> float:
    value = 0.0
    for block in used_guide_blocks():
        if block.kind == "solid":
            value += 1.0
        elif block.kind == "insertable":
            value += 1.5
        else:
            raise ValueError(f"Unsupported guide kind: {block.kind}")
    return value


def experiment_level_label() -> str:
    value = experiment_level_value()
    if value.is_integer():
        return f"L{int(value)}"
    return f"L{value:g}"


WAYPOINTS: tuple[tuple[float, float], ...] = (
    START_POSITION,
    *(block.position for block in used_guide_blocks()),
    active_target().position,
)
