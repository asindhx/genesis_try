import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal


ShapeName = Literal["circle", "square", "rectangle", "pentagon"]
GuideKind = Literal["solid", "insertable"]
EndoscopeMaterial = Literal["metal", "rubber"]
GUIDE_BLOCK_COLOR = (0.20, 0.36, 0.58, 1.0)


@dataclass(frozen=True)
class GuideBlock:
    name: str
    kind: GuideKind
    shape: ShapeName
    position: tuple[float, float]
    size: float
    height: float
    color: tuple[float, float, float, float]
    size_x: float | None = None
    size_y: float | None = None


@dataclass(frozen=True)
class ClampBlock:
    name: str
    position: tuple[float, float]
    size: tuple[float, float]
    height: float
    color: tuple[float, float, float, float]


@dataclass(frozen=True)
class Target:
    name: str
    shape: ShapeName
    position: tuple[float, float]
    size: float
    height: float
    color: tuple[float, float, float, float]
    active: bool = False
    rotation: float = 0.0
    entry_direction: tuple[float, float] | None = None


@dataclass(frozen=True)
class EndoscopeSection:
    name: str
    material: EndoscopeMaterial
    length: float
    radius: float
    segment_count: int
    color: tuple[float, float, float, float]
    bend_compliance: float


@dataclass(frozen=True)
class EndoscopeConfig:
    base_position: tuple[float, float, float] = (-1.54, 0.0, 0.08)
    sections: tuple[EndoscopeSection, ...] = (
        EndoscopeSection(
            name="lens_metal_tip",
            material="metal",
            length=0.09,
            radius=0.036,
            segment_count=1,
            color=(0.72, 0.75, 0.78, 1.0),
            bend_compliance=0.05,
        ),
        EndoscopeSection(
            name="front_rubber_bend",
            material="rubber",
            length=0.16,
            radius=0.034,
            segment_count=4,
            color=(0.04, 0.05, 0.055, 1.0),
            bend_compliance=1.0,
        ),
        EndoscopeSection(
            name="middle_metal_sleeve",
            material="metal",
            length=0.10,
            radius=0.035,
            segment_count=1,
            color=(0.58, 0.61, 0.64, 1.0),
            bend_compliance=0.08,
        ),
        EndoscopeSection(
            name="rear_rubber_tube",
            material="rubber",
            length=6.0,
            radius=0.033,
            segment_count=60,
            color=(0.02, 0.025, 0.03, 1.0),
            bend_compliance=0.06,
        ),
    )


PLANE_SIZE = (3.2, 2.1)
EXPLICIT_LEVEL_LABEL: str | None = None
TARGET_POSITION = (0.88, 0.34)
TARGET_SIZE = 0.18
TARGET_HEIGHT = 0.055
ACTIVE_TARGET_NAME = "target_main"
TARGETS: tuple[Target, ...] = (
    Target(
        name="target_main",
        shape="pentagon",
        position=TARGET_POSITION,
        size=TARGET_SIZE,
        height=TARGET_HEIGHT,
        color=(0.72, 0.10, 0.82, 1.0),
        active=True,
    ),
    Target(
        name="target_alt",
        shape="pentagon",
        position=(0.84, -0.34),
        size=0.16,
        height=TARGET_HEIGHT,
        color=(0.55, 0.20, 0.78, 1.0),
        active=False,
    ),
)


GUIDE_BLOCKS: tuple[GuideBlock, ...] = (
    GuideBlock(
        name="guide_solid_turn_block",
        kind="solid",
        shape="square",
        position=(-0.80, 0.02),
        size=0.24,
        height=0.09,
        color=GUIDE_BLOCK_COLOR,
    ),
    GuideBlock(
        name="guide_insertable_long_slot",
        kind="insertable",
        shape="rectangle",
        position=(-0.12, 0.10),
        size=0.14,
        height=0.08,
        color=GUIDE_BLOCK_COLOR,
        size_x=0.18,
        size_y=0.48,
    ),
)


ENDOSCOPE = EndoscopeConfig()


START_POSITION = (-1.36, 0.0)


START_CLAMPS: tuple[ClampBlock, ...] = (
    ClampBlock(
        name="start_clamp_upper",
        position=(-1.48, 0.085),
        size=(0.18, 0.055),
        height=0.075,
        color=(0.18, 0.18, 0.20, 1.0),
    ),
    ClampBlock(
        name="start_clamp_lower",
        position=(-1.48, -0.085),
        size=(0.18, 0.055),
        height=0.075,
        color=(0.18, 0.18, 0.20, 1.0),
    ),
)


# Only these guide blocks are counted as the intended path. Other blocks in
# GUIDE_BLOCKS are distractors and do not affect the level.
USED_GUIDE_BLOCK_NAMES: tuple[str, ...] = (
    "guide_solid_turn_block",
    "guide_insertable_long_slot",
)

def guide_block_by_name(name: str) -> GuideBlock:
    for block in GUIDE_BLOCKS:
        if block.name == name:
            return block
    raise ValueError(f"Unknown guide block name: {name}")


def used_guide_blocks() -> tuple[GuideBlock, ...]:
    return tuple(guide_block_by_name(name) for name in USED_GUIDE_BLOCK_NAMES)


def target_by_name(name: str) -> Target:
    for target in TARGETS:
        if target.name == name:
            return target
    raise ValueError(f"Unknown target name: {name}")


def active_target() -> Target:
    return target_by_name(ACTIVE_TARGET_NAME)


def _unit_vector(vec: tuple[float, float]) -> tuple[float, float]:
    length = math.hypot(vec[0], vec[1])
    if length <= 1e-8:
        return (1.0, 0.0)
    return (vec[0] / length, vec[1] / length)


def target_entry_direction(target: Target) -> tuple[float, float]:
    if target.entry_direction is not None:
        return _unit_vector(target.entry_direction)
    return (math.cos(target.rotation), math.sin(target.rotation))


def target_entry_radius(target: Target) -> float:
    return max(target.size * 0.16, 0.024)


def target_entry_point(target: Target) -> tuple[float, float]:
    direction = target_entry_direction(target)
    distance = target.size * 0.82
    return (
        float(target.position[0] + direction[0] * distance),
        float(target.position[1] + direction[1] * distance),
    )


def target_visual_rotation(target: Target) -> float:
    if target.shape != "pentagon":
        return target.rotation
    direction = target_entry_direction(target)
    entry_angle = math.atan2(direction[1], direction[0])
    return target.rotation or (entry_angle - math.pi / 2.0 - math.pi / 5.0)


def experiment_level_value() -> float:
    value = 0.0
    for block in used_guide_blocks():
        if block.kind == "solid":
            value += 1.0
        elif block.kind == "insertable":
            value += 1.5
        else:
            raise ValueError(f"Unsupported guide kind: {block.kind}")
    return value


def experiment_level_label() -> str:
    if EXPLICIT_LEVEL_LABEL:
        return EXPLICIT_LEVEL_LABEL
    value = experiment_level_value()
    if value.is_integer():
        return f"L{int(value)}"
    return f"L{value:g}"


WAYPOINTS: tuple[tuple[float, float], ...] = (
    START_POSITION,
    *(block.position for block in used_guide_blocks()),
    target_entry_point(active_target()),
)


def _rgba_from_layout(value, default):
    if not value:
        return default
    if isinstance(value, str) and value.startswith("#") and len(value) in (7, 9):
        r = int(value[1:3], 16) / 255.0
        g = int(value[3:5], 16) / 255.0
        b = int(value[5:7], 16) / 255.0
        a = int(value[7:9], 16) / 255.0 if len(value) == 9 else 1.0
        return (r, g, b, a)
    if isinstance(value, (list, tuple)) and len(value) in (3, 4):
        rgba = tuple(float(x) for x in value)
        return rgba if len(rgba) == 4 else (*rgba, 1.0)
    return default


def _load_layout_if_present() -> None:
    global GUIDE_BLOCKS, TARGETS, ACTIVE_TARGET_NAME, USED_GUIDE_BLOCK_NAMES, WAYPOINTS, PLANE_SIZE, EXPLICIT_LEVEL_LABEL
    layout_override = os.environ.get("ENDOSCOPE_LAYOUT_PATH")
    layout_path = Path(layout_override) if layout_override else Path(__file__).with_name("layout.json")
    if not layout_path.exists():
        return

    data = json.loads(layout_path.read_text(encoding="utf-8"))
    if data.get("plane_size"):
        PLANE_SIZE = (float(data["plane_size"][0]), float(data["plane_size"][1]))
    EXPLICIT_LEVEL_LABEL = str(data["level_label"]) if data.get("level_label") else None
    block_color = _rgba_from_layout(data.get("guide_block_color"), GUIDE_BLOCK_COLOR)

    blocks = []
    for idx, item in enumerate(data.get("guide_blocks", []), start=1):
        shape = item.get("shape", "circle")
        kind = item.get("kind", "solid")
        default_name = f"guide_{idx:02d}_{shape}_{kind}"
        blocks.append(
            GuideBlock(
                name=item.get("name") or default_name,
                kind=kind,
                shape=shape,
                position=(float(item["x"]), float(item["y"])),
                size=float(item.get("size", 0.13)),
                height=float(item.get("height", 0.075)),
                color=_rgba_from_layout(item.get("color"), block_color),
                size_x=float(item["size_x"]) if item.get("size_x") is not None else None,
                size_y=float(item["size_y"]) if item.get("size_y") is not None else None,
            )
        )
    if blocks:
        GUIDE_BLOCKS = tuple(blocks)

    targets = []
    for idx, item in enumerate(data.get("targets", []), start=1):
        default_name = "target_main" if idx == 1 else f"target_{idx}"
        targets.append(
            Target(
                name=item.get("name") or default_name,
                shape=item.get("shape", "pentagon"),
                position=(float(item["x"]), float(item["y"])),
                size=float(item.get("size", TARGET_SIZE)),
                height=float(item.get("height", TARGET_HEIGHT)),
                color=_rgba_from_layout(item.get("color"), (0.72, 0.10, 0.82, 1.0)),
                active=bool(item.get("active", idx == 1)),
                rotation=float(item.get("rotation", 0.0)),
                entry_direction=(
                    (float(item["entry_direction"][0]), float(item["entry_direction"][1]))
                    if item.get("entry_direction") is not None
                    else None
                ),
            )
        )
    if targets:
        TARGETS = tuple(targets)

    ACTIVE_TARGET_NAME = data.get("active_target_name") or next((target.name for target in TARGETS if target.active), TARGETS[0].name)
    if data.get("used_guide_block_names"):
        USED_GUIDE_BLOCK_NAMES = tuple(str(name) for name in data["used_guide_block_names"])
    elif blocks:
        USED_GUIDE_BLOCK_NAMES = tuple(block.name for block in blocks if block.kind in ("solid", "insertable"))

    WAYPOINTS = (
        START_POSITION,
        *(block.position for block in used_guide_blocks()),
        target_entry_point(active_target()),
    )


_load_layout_if_present()
